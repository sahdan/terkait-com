/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * Tilemap module
 *
 * (c) 2010-2017 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/tilemap.src.js';
