<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	require('header.php');
	if(!isset($_SESSION["user_id"])){
		// var_dump($_SESSION["user_id"]);
		header("Location: " . base_url('/CLogin/login'));
	}
?>
<style> 
	.custom-search:focus{
		border:none!important;
		box-shadow:none!important;
	}
	.bio{
		margin-top:0px;
		height:65px;
		padding-top:5px;
	}
	.bio #nama a{
		text-align:center;
		font-weight:600;
		font-size:24pt;
	}
	nav ul li.active{
		border-bottom:1px solid white;
	}
	.sidenav .collapsible-body>ul:not(.collapsible)>li.active, .sidenav.sidenav-fixed .collapsible-body>ul:not(.collapsible)>li.active {
		background-color: grey;
	}
	@media only screen and (max-width: 992px) {
		#idLogo{
			text-align:left;
		}
	}
	
	@media only screen and (max-width: 600px){

	}

</style>
<body>

	<div class="navbar-fixed">
		<nav class="blue darken-4">
            <div class="nav-wrapper container" style="width:80%">

                
                <!--  -->
				<a href="<?php echo base_url('CHome'); ?>" id="idLogo" class="brand-logo  hide-on-med-and-up"><b><span class="blue darken-1" style="padding: 0px 5px;border-radius:5px;margin-left:2px">Ter</span>kait</b></a>
                <!--  -->
                <a href="<?php echo base_url('CHome'); ?>" id="idLogo" class="left brand-logo hide-on-small-only"><b><span class="blue darken-1" style="padding: 0px 5px;border-radius:5px;margin-left:2px">Ter</span>kait</b></a>

                <!-- <form style="display:inline-block;position:relative;left:150px;hide-on-small-only">
                    <div class="input-field" style="margin:0;height:70%; top:50%;transform: translateY(-50%);">
                        <input style="height:100%;margin:0;padding-left:0.75rem; padding-right: 3rem;"type="search" id="search-field" name="edSearch">
                        <label style="top:50%;transform: translateY(-50%);margin:0;left:unset;right:0.75rem;float:right;"class="label-icon" for="search"><i style="font-size:18px;" class="material-icons">search</i></label>
                    </div>
                </form> -->

				<ul class="right hide-on-small-only">
					<form class="custom-search-form" autocomplete="off" style="float:left;">
					<!-- <form class="custom-search-form" autocomplete="off" style="float:left;position:absolute;"> -->
						<input type="hidden" id="custom-search-status" value="0"/>
						<div class="custom-search-container" style="">
							<div class="custom-search-div input-field" style="display:none;float:left;">
							<!-- <div class="custom-search-div input-field" style="display:none;float:right;"> -->
								<input id="custom-search" class="autocomplete" type="text" size="35" style="margin:unset;height:100%;width:90%;background-color:white!important;padding:0 10px;">
							</div>
							<li style="float:right;" class="custom-search-icon"><a><i class="material-icons">search</i></a></li>
							<!-- <li style="float:left;position:absolute;left:-60px;" class="custom-search-icon"><a><i class="material-icons">search</i></a></li> -->
						</div>							
					</form>
					<li <?php if($this->uri->segment(1) == 'CHome'){echo "class='active'";}?>><a href="<?php echo base_url('CHome'); ?>"><i class="material-icons">home</i></a></li>
					<li><a href="<?php echo base_url('logout'); ?>"><i class="material-icons">people</i></a></li>
					<li><a href="<?php echo base_url('logout'); ?>"><i class="material-icons">work</i></a></li>
					<li <?php if($this->uri->segment(1) == 'CMessages'){echo "class='active'";}?>><a href="<?php echo base_url('CMessages'); ?>"><i class="material-icons">message</i></a></li>
					<li <?php if($this->uri->segment(1) == 'CNotification'){echo "class='active'";}?>><a href="<?php echo base_url('CNotification'); ?>"><i class="material-icons">notifications</i></a></li>
					<li><a href="<?php echo base_url('CLogin/logout'); ?>"><i class="material-icons">exit_to_app</i></a></li>
 				</ul>
			</div>
		</nav>
	</div>
	<div class="navbar-fixed hide-on-med-and-up" style="position: fixed;bottom:0px;z-index: 10;">
		<nav class="blue darken-4">
			<div class="nav-wrapper container" style="width:80%">
				<ul class="right show-on-small" style="margin-right: calc(50% - 110px);">
					<li <?php if($this->uri->segment(1) == 'CHome'){echo "class='active'";}?>><a href="<?php echo base_url('CHome'); ?>"><i class="material-icons">home</i></a></li>
					<li><a href="<?php echo base_url('logout'); ?>"><i class="material-icons">people</i></a></li>
					<li><a href="<?php echo base_url('logout'); ?>"><i class="material-icons">work</i></a></li>
					<li <?php if($this->uri->segment(1) == 'CMessages'){echo "class='active'";}?>><a href="<?php echo base_url('CMessages'); ?>"><i class="material-icons">message</i></a></li>
					<li><a href="<?php echo base_url('CLogin/logout'); ?>"><i class="material-icons">exit_to_app</i></a></li>
				</ul>
			</div>
		</nav>
	</div>
	<script async>

		$(document).ready(function(){
			$('.sidenav').sidenav();
			$('.collapsible').collapsible();
			$(".dropdown-trigger").dropdown({
				coverTrigger: false,
				constrainWidth:false,
				alignment:"right"
			});
			$('#custom-search').autocomplete({
				limit: 4,
				onAutocomplete: function(value){
					$url = "<?php echo base_url('CSearch/redirectPage/'); ?>"+value;
					$url = encodeURI($url);
					window.location = $url;
				},
			});

			$('#custom-search').keyup(function(){
				var keyword = $(this).val();
				$.ajax({
					method: "post",
					url: '<?= base_url("CSearch/getSuggestion") ?>',
					data:{
						keyword: keyword
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					// alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					var array = {};
					for(var i=0; i < result[0].length; i++){
						array[result[0][i].suggestion] = null;
					}
					for(var i=0; i < result[1].length; i++){
						array[result[1][i].company_name] = null;
					}
					$('#custom-search').autocomplete('updateData', array);
				});
			});
			$('.custom-search-div').on('mousedown', 'li', function(){
				console.log("li");
				$("#custom-search-status").val("1");
				console.log($("#custom-search-status").val());
			});
			var searchShow = function(){
				$(".custom-search-div").animate({
					opacity: "toggle",
    				width: "toggle"
				}, 500, function(){
					$(".custom-search-icon").off('click');
					$(".custom-search-icon").on('mousedown', searchAction);
					$(".custom-search-container").on('focusout', searchHide);
					$('#custom-search').focus();
				});
			};
			var searchHide = function(){
				var status = $("#custom-search-status").val();
				status -= 1;
				if(status<0){
					$(".custom-search-div").animate({
						opacity: "toggle",
						width: "toggle"
					}, 500, function(){
						$(".custom-search-container").off('focusout');
						$(".custom-search-icon").off('mousedown');
						$(".custom-search-div ul li").off('mousedown');
						$(".custom-search-icon").on('click', searchShow);
					});
				}else{

				}
				$("#custom-search-status").val("0");
			};
			var searchAction = function(){
				$("#custom-search-status").val("1");
				if($('#custom-search').val().length >= 3){
					$url = "<?php echo base_url('CSearch/index/'); ?>"+$('#custom-search').val();
					$url = encodeURI($url);
					window.location = $url;
				}else{
				}
			}
			$(".custom-search-icon").on('click', searchShow);

			$('#custom-search').keypress(function (e) {
				var key = e.which;
				if(key == 13) //enter key
				{
					searchAction();
					return false;  
				}
			}); 
		});
	</script>