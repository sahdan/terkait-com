<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    height: auto !important;
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}
.jobs-card:hover{
	box-shadow: 0 0 0 1px rgba(0,0,0,.15), 0 2px 3px rgba(0,0,0,.2), 0 2px 3px rgba(0,0,0,.2);
	cursor: pointer;
}

</style>
	<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 m12 l12 ">
					<div class="card">
						<?php foreach($companies as $item){?>
						<div class="card-image <?php if($item->cover_url == ""){echo "blue"; }; ?> darken-4" style="height:90px;<?php if($item->cover_url != ""){echo "background:url(".$item->cover_url.");"; } ?>">
						</div>
						<div class="circle" style="position:absolute;height:100px;width:100px;background-color:white;top:40px;left:calc(50% - 50px)">
						<?php 
						if($item->logo_url != "") { ?>
								<img src="<?php echo $item->logo_url; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:5px">
						<?php } else { ?>
								<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:5px">
						<?php } ?>
						</div>
						<div class="card-content center" style="margin-top:12px">
							<div class="row" style="margin-bottom:10px !important;">
								<a href="http://localhost/bsd2/CProfile/index/<?php echo $company; ?>"><h5><b><?php
									//menampilkan nama
														// echo $_SESSION["user_first_name"];
														// if ($_SESSION["user_last_name"] != "") {
															// echo " " . $_SESSION["user_last_name"];
														// }
										// var_dump($item);
										echo $item->company_name;
									?>
									
									</b></h5>
								</a>
								<div class="divider"></div>
								<p style="color:gray; padding-top:10px;"><small><?php echo $item->company_description; ?></small></p>
								<?php
									}
														?>
							</div>
						</div>	
					</div>
				</div>
				<div class="col s12 m12 l12 post-container">
					<!-- Untuk unggah status -->
                    <div class="card">
						<div class="row card-content" style="min-height:150px">
						<span class="card-title">Tambah Pekerjaan Baru</span>
						<form class="regis" method="post" action="<?php if($mode == "add"){echo base_url('CJob/submitJob/').$company;}else{echo base_url('CJob/submitEditJob/').$job_id;}?>" enctype="multipart/form-data">
							<div>
								<?php if($mode == "add"){?>
								<div class="form-group">
									<div class="input-field col s12">
										<input id="industry" type="text" name="edIndustry" required oninvalid="this.setCustomValidity('Masukkan Bidang Pekerjaan')" oninput="setCustomValidity('')">
										<label for="industry" >Bidang Pekerjaan *</label>
										<div class="note">
                                            Contoh : Accounting/Auditing, Analyst, Information Technology, Advertising, dll
                                        </div>
									</div>
									<div class="input-field col s12">
										<select id="jobFunction" name="edJobFunction">
											<option value="Full-Time">Full-Time</option>
											<option value="Part-Time">Part-Time</option>
											<option value="Kontrak">Kontrak</option>
											<option value="Sementara">Sementara</option>
											<option value="Relawan">Relawan</option>
											<option value="Magang">Magang</option>
										</select>
										<label for="jobFunction" >Jenis Pekerjaan *</label>
									</div>
									<div class="input-field col s12">
										<input id="jobPosition" type="text" name="edJobPosition">
										<label for="jobPosition" >Jabatan Pekerjaan *</label>
										<div class="note">
                                            Contoh : Karyawan, Programmer, Marketing, Akuntan, HRD, Manajer
                                        </div>
									</div>
									<div class="input-field col s12">
										<input id="employmentType" type="text" name="edEmploymentType">
										<label for="employmentType" >Tipe Pekerjaan *</label>
										<div class="note">
                                            Contoh : Government, Hospitality, Airlines, Accounting, dll
                                        </div>
									</div>
									<div class="input-field col s12">
										<select id="seniorityLevel" name="edSeniorityLevel">
											<option value="Internship">Internship</option>
											<option value="Entry Level">Entry Level</option>
											<option value="Associate">Associate</option>
											<option value="Mid-Senior Level">Mid-Senior Level</option>
											<option value="Director">Director</option>
											<option value="Executive">Executive</option>
										</select>
										<label for="seniorityLevel" >Tingkat Senioritas *</label>
									</div>
									<div class="input-field col s12">
										<select id="skill" name="edSkill[]" multiple>
											<?php foreach($skills as $item){?>
											<option value="<?php echo $item->skill_id;?>"><?php echo $item->skill_name;?></option>
											<?php }?>
										</select>
										<label for="skill" >Ketrampilan *</label>
									</div>
									<div class="input-field col s12">
										<input id="picker-expired" name="edExpired" class="datepicker" type="text">
										<label for="picker-expired">Tanggal Berakhir</label>
									</div>
									<div class="input-field col s12">
										<input id="minSalary" name="edMinSalary" min=0 step="1000" type="number">
										<label for="minSalary">Gaji Minimum</label>
									</div>
									<div class="input-field col s12">
										<input id="maxSalary" name="edMaxSalary" min=0 step="1000" type="number">
										<label for="maxSalary">Gaji Maksimum</label>
									</div>
									<div class="input-field col s12">
										<label for="description" >Deskripsi Pekerjaan</label>
										<textarea id="description" name='edDescription' class="materialize-textarea" placeholder="Masukkan Deskripsi Pekerjaan..." style="margin-top: 10px;"></textarea>
									</div>
								</div>
								<?php }else{
								foreach($job as $data){?>
								<div class="form-group">
									<div class="input-field col s12">
										<input id="industry" type="text" name="edIndustry" required oninvalid="this.setCustomValidity('Masukkan Bidang Pekerjaan')" oninput="setCustomValidity('')" value="<?php echo $data->industry; ?>">
										<label for="industry" >Bidang Pekerjaan *</label>
										<div class="note">
                                            Contoh : Accounting/Auditing, Analyst, Information Technology, Advertising, dll
                                        </div>
									</div>
									<div class="input-field col s12">
										<select id="jobFunction" name="edJobFunction">
											<option value="Full-Time">Full-Time</option>
											<option value="Part-Time">Part-Time</option>
											<option value="Kontrak">Kontrak</option>
											<option value="Sementara">Sementara</option>
											<option value="Relawan">Relawan</option>
											<option value="Magang">Magang</option>
										</select>
										<label for="jobFunction" >Jenis Pekerjaan *</label>
									</div>
									<div class="input-field col s12">
										<input id="jobPosition" type="text" name="edJobPosition" value="<?php echo $data->job_position; ?>>
										<label for="jobPosition" >Jabatan Pekerjaan *</label>
										<div class="note">
                                            Contoh : Karyawan, Programmer, Marketing, Akuntan, HRD, Manajer
                                        </div>
									</div>
									<div class="input-field col s12">
										<input id="employmentType" type="text" name="edEmploymentType" value="<?php echo $data->employment_type; ?>">
										<label for="employmentType" >Tipe Pekerjaan *</label>
										<div class="note">
                                            Contoh : Government, Hospitality, Airlines, Accounting, dll
                                        </div>
									</div>
									<div class="input-field col s12">
										<select id="seniorityLevel" name="edSeniorityLevel">
											<option value="Internship">Internship</option>
											<option value="Entry Level">Entry Level</option>
											<option value="Associate">Associate</option>
											<option value="Mid-Senior Level">Mid-Senior Level</option>
											<option value="Director">Director</option>
											<option value="Executive">Executive</option>
										</select>
										<label for="seniorityLevel" >Tingkat Senioritas *</label>
									</div>
									<div class="input-field col s12">
										<select id="skill" name="edSkill[]" multiple>
											<?php foreach($skills as $item){?>
											<option value="<?php echo $item->skill_id;?>"><?php echo $item->skill_name;?></option>
											<?php }?>
										</select>
										<label for="skill" >Ketrampilan *</label>
									</div>
									<div class="input-field col s12">
										<input id="minSalary" name="edMinSalary" min=0 step="1000" type="number" value="<?php echo $data->min_gaji; ?>">
										<label for="minSalary">Gaji Minimum</label>
									</div>
									<div class="input-field col s12">
										<input id="maxSalary" name="edMaxSalary" min=0 step="1000" type="number" value="<?php echo $data->max_gaji; ?>">
										<label for="maxSalary">Gaji Maksimum</label>
									</div>
									<div class="input-field col s12">
										<input id="picker-expired" name="edExpired" class="datepicker" type="text" value="<?php 
										$date = explode(" ",$data->expired_at);
										echo $date[0];
										?>">
										<label for="picker-expired">Tanggal Berakhir</label>
									</div>
									<div class="input-field col s12">
										<textarea id="description" name='edDescription' class="materialize-textarea" placeholder="Masukkan Deskripsi Pekerjaan..." ><?php echo $data->job_description;?></textarea>
									</div>
								</div>
								<?php 
									$jobFunction = $data->job_functions;
									$seniorityLevel = $data->seniority_level;
									}
								}?>
								<span style="margin-left:2%">* Harus diisi</span>
								<div style="padding-bottom: 20px; padding-right: 5%;">
									<button class="btn waves-effect waves-light right" type="submit" name="action"><?php if($mode == "add"){echo "Buat Pekerjaan";}else{echo "Simpan Perubahan";}?>
										<i class="material-icons right">send</i>
									</button>
								</div>
							</div>
						</form>
						</div>
					</div>
				</div>
				<div class="preloader-wrapper big active" style="margin-left: -43%; display:none; position: fixed;">
					<div class="spinner-layer spinner-blue-only">
						<div class="circle-clipper left">
							<div class="circle">
							</div>
						</div>
						<div class="gap-patch">
							<div class="circle">
							</div>
						</div>
						<div class="circle-clipper right">
							<div class="circle">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script>
	$(document).ready(function() {
		<?php if($mode == "edit"){
			?>
			$("#jobFunction").val('<?php echo $jobFunction; ?>');
			$("#seniorityLevel").val('<?php echo $seniorityLevel; ?>');
			<?php
			$skillReq = array();
			foreach($skill as $item){
				array_push($skillReq, $item->skill_id);
			}
			$jsonSkill = json_encode($skillReq);
			?>
			$("#skill").val(<?php echo $jsonSkill; ?>);
			M.textareaAutoResize($('#description'));
			<?php
		}?>
		M.updateTextFields();
		$('#picker-expired').datepicker({
					container: 'body',
					format: 'yyyy-mm-dd',
				});
		$('select').formSelect();
	});
	</script>

</body>
</html>