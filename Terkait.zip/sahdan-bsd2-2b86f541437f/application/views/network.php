<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    height: auto !important;
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}
.btn-small:hover{
	background-color:#2bbbad47 !important;
}

.suggest-card{
	margin:.5rem 0 0 0 !important;
}

</style>
	<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 m4 l3 ">
					<div class="card">
						<div class="card-content center" style="margin-top:12px">
							<div class="row" style="margin-bottom:10px !important;">
								<h4 style="color:gray"><?php echo  $_SESSION["user_jum_koneksi"];?></h4>
								<p>Koneksi</p>
								<p><a href="<?php echo base_url("CNetwork/NetworkList/")?>" class="center">Lihat semua koneksi</a></p>
							</div>
						</div>	
					</div>
				</div>
				<div class="col s12 m8 l9 post-container">
				<ul class="collection with-header">
						<li class="collection-header"><h6><b>Daftar Request Koneksi</b></h6></li>
						<?php 
						//tampilkan List Koneksi
						// $connections dapat dari CNetwork $data['connections']
						foreach ($pending as $item) {
						?>
                        <li class="collection-item avatar">
                            <div class="circle" style="height:60px;width:60px;background-color:yellow;">
							<?php if($item->photo_url != "") { ?>
								<img src="<?php echo $item->photo_url; ?>" class="circle" style="width:100%;height:100%;margin-left:-15px">
							<?php } else { ?>
								<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle" style="width:100%;height:100%;margin-left:-15px">
							<?php } ?>
								
							</div>
                            <p style="margin-left:5px; font-weight: bold;"><?php echo $item->name?><br>
                                <span style="color: gray;"><?php echo $item->headline ?></span>
							</p>
							<a href="<?php echo base_url('CProfile/index/') . $item->user_id; ?>"  class="waves-effect waves-light btn-flat btn-small right" style="border:1px solid #1565C0;color:#1565C0;margin-top:-30px"><b>Lihat Profil</b></a>
                            <!-- <a href="#!" class="dropdown-trigger secondary-content" data-target='dropdown1'><i class="material-icons">more_vert</i></a> -->
						</li>
						<?php } ?>
						<?php 
						if (empty($pending)) {
							echo "<p style='text-align:center;'>Tidak ada request koneksi untuk saat ini</p>";
						}
						?>
				</ul>
					<div class="card">
						<div class="row card-content">
							<span class="card-title">
								Orang yang mungkin anda kenal
							</span>
							<div class="divider"></div>
							<?php foreach($sugestion as $item){
							//tampilkan suggest
							?>
								<div class="col s12 m6 l3" style="padding:0 .30rem">
									<div class="card suggest-card">
										<div class="card-content center" style="padding:10px">
											<span class="card-title">
											<?php if($item->photo_url != "") { ?>
												<img src="<?php echo $item->photo_url; ?>" style="height:100px">
											<?php } else { ?>
												<img src="<?php echo base_url('assets/images/avatar.png'); ?>" style="height:100px">
											<?php } ?>
												<!-- <a href="#!" class="dropdown-trigger secondary-content" data-target='option-suggest'><i class="material-icons">more_vert</i></a>-->
											</span>
											<b><?php echo $item->name; ?> </b><br>
											<span style="font-size: small;color: darkgrey;"><?php echo $item->headline; ?></span><br>
											<span style="font-size: small;color: darkgrey;"><?php echo $item->ctr; ?> koneksi yang sama</span><br>
											<a href="<?php echo base_url('CProfile/index/') . $item->user_id; ?>"  class="waves-effect waves-light btn-flat btn-small" style="border:1px solid #1565C0;color:#1565C0"><b>Lihat Profil</b></a>
										</div>
									</div>
								</div>
							<?php }?>
						</div>	
					</div>
				</div>
				<!-- <div class="col s12 m12 l3">
					<div class="card">
						<div class="card-content">
						</div>	
					</div>
				</div> -->
				<div class="preloader-wrapper big active" style="margin-left: -43%; display:none; position: fixed;">
					<div class="spinner-layer spinner-blue-only">
						<div class="circle-clipper left">
							<div class="circle">
							</div>
						</div>
						<div class="gap-patch">
							<div class="circle">
							</div>
						</div>
						<div class="circle-clipper right">
							<div class="circle">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script>
	$(document).ready(function() {
		$('.modal').modal();
		//deklarasi dropify
		$('.dropify').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		
		//ganti text nya dropify
		$('.post .dropify-message p').text("Unggah gambar disini");
		
		//untuk deteksi scroll
		window.onscroll = function(ev) {
			
			//kalau sudah sampai dibawah
			if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
				
				//nanti di isi ajax buat post
				$.ajax({
					method: "post",
					url: '<?= base_url("CPost/ajaxLoadPost") ?>',
					data: {	startPost: startPost,
							// endPost: endPost
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(result) {
					$('.post-container').append(result);
				});
			}
		};
		
		//edit post di klik
		$(document).on('click','.modal-edit',function(){
			var id = $(this).attr("id-post");
			$.ajax({
				method: "post",
				url: '<?= base_url("CHome/ajaxEditPost") ?>',
				data: {	id: id
					},
				beforeSend: function () {
                    $('#modal-edit').html("");
                }
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(result) {
				$('#modal-edit').html(result);
				$('#textarea1').trigger('autoresize');
			});
		})

		//delete post di klik
        $(document).on('click','.modal-delete',function(){
            var id = $(this).attr("id-post");
            $("#modal-delete>.modal-footer>.btn-yes").attr("href","<?php echo base_url('CHome/deletePost/'); ?>"+id)
        });
		$( document ).ajaxStart(function() {
			$( ".preloader-wrapper" ).show();
		});
		
		$(document).ajaxStop(function(){
			$( ".preloader-wrapper" ).hide();
		})
		
	});
	</script>

</body>
</html>