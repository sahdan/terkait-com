<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    <!-- height: auto !important; -->
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}
.card .card-action{
	padding: 13px 24px !important;
}
.like{
	cursor: pointer;
}
a span.card-title{
	color:black;
}
a h5{
	color:black;
}
.card-sugestion{
	font-size:15px;
	color:black;
}
.card-sugestion:hover{
	background-color: lightgrey;
}
</style>

<?php if($user_company["status"] != -1){ ?>
	<form method="post" action="<?php echo base_url('CPost/submit_post_company/').$this->uri->segment(3); ?>" enctype="multipart/form-data">
		<div class="card post">
			<div class="card-content">
				<textarea id="textarea" name='edContent' class="materialize-textarea" placeholder="Tulis disini..." ></textarea>
				<input name='edImage' type="file" id="idImage" class="dropify" />
			</div>	
				<div class="card-action post-action">
					<button class="btn btn-post waves-effect waves-light right indigo darken-4" type="submit" name="action">Post</button>
				</div>
		</div>
	</form>
<?php } ?>
<?php 
	//tampilkan 10 post terakhir
	// $post dapat dari CHOME $data['post']
foreach ($post as $item) {
?>
		<div class="card">
			<div class="card-content row">
				<div class="col s10 m10 l10">
				<a href="http://localhost/bsd2/CProfile/index/<?php echo $item->account_id?>">
				<span class="card-title" style="display: flex; align-items: center; margin-left: -10px;">
				<div class="circle" style="height:60px;width:60px;background-color:white;left:calc(50% - 50px)">
					<?php if($item->logo_url != "") { ?>
							<img src="<?php echo $item->logo_url; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:3px">
					<?php } else { ?>
							<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:3px">
					<?php } ?>
					</div>
				<?php echo $item->company_name; ?>
				</span></a>
				
				</div>
				<div class="col s2 m2 l2">
					<?php if($item->account_id == $this->uri->segment(3)){?>
						<i class="material-icons right activator">more_vert</i>
					<?php } ?>
				</div>
				<div class="col s12 m12 l12">
					<pre class="post-content"><?php echo $item->post_content; ?></pre>
				</div>
				<?php if ($item->media_link != "") {
				?>
						<br>
						<img class="responsive-img img-post" src="<?php echo $item->media_link; ?>" \>
					<?php

				} ?>
			</div>
			<?php if ($item->account_id == $this->uri->segment(3)) { ?>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4"><i class="material-icons right">close</i></span>
					<ul class="right">
						<li>
							<a class="modal-trigger waves-effect waves-light modal-delete" id-post="<?php echo $item->post_id; ?>" href="#modal-delete"><i class="material-icons left">delete</i>Delete</a>
						</li>
					</ul>
				</div>
			<?php 
			} ?>
			<div id="modal-delete" class="modal modal-fixed-footer">
                <div class="modal-content" style="position: relative;height:150px">
                    <h6>Apakah anda yakin ingin menghapus?</h6>
                </div>
                <div class="modal-footer">
                    <a href="#" class="modal-close waves-effect waves-green btn btn-yes indigo darken-4">Ya</a>
                </div>
            </div>
			<!----------------------------------- COMMENT AREA ----------------------------------->
			<div class="card-action">
				<a idPost="<?php echo $item->post_id; ?>" <?php if($item->flag != 1){echo ' class="like" ';}?> ctrLikes="<?php echo $item->likes; ?>" id="like-<?php echo $item->post_id; ?>" flag="true"><?php echo $item->likes; ?> Suka</a>
				<a class="waves-effect btn-flat show-comment" komentar="<?php echo $item->post_id; ?>"><?php echo $item->ctrComment; ?> komentar</a>
			</div>
			<div id="fieldComment-<?php echo $item->post_id;?>" class="fieldComment" style="display:none">
				<div class="card-content" style="background-color: #eaeaea;">
					
				</div>
				<form method="post" class="submitComment" komentar="<?php echo $item->post_id; ?>" action="<?php echo base_url('CComment/submit_comment_company');?>" enctype="multipart/form-data">
					<div class="card-content" style="background-color: #eaeaea;padding: 5px;">
						<input name="edIdPost" value="<?php echo $item->post_id; ?>" style="display:none">
						<input name="edIdCompany" value="<?php echo $this->uri->segment(3); ?>" style="display:none">
						<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="responsive-img" style="width: 35px;margin: 15px 0px;">
						<textarea class="materialize-textarea content"  id="comment-textarea-<?php echo $item->post_id; ?>" name='edContent' placeholder="Tulis disini..." style="height: 45px;width: 100%;background-color: white;"></textarea>
						<input name='edImage' type="file" id="idImageComment" class="dropify" />
					</div>
					<div style="height: 50px;background-color: #eaeaea; padding-top: 10px;padding-right: 10px;">
						<button class="btn btn-post waves-effect waves-light right indigo darken-4" type="submit" name="action">Post</button>
					</div>
				</form>
		</div>
	</div>
		<?php

}
?>
<script>
	$(document).ready(function() {
		$('.modal').modal();
		//deklarasi dropify
		$('.dropify').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		
		xhrPool = [];
		//ganti text nya dropify
		$('.post .dropify-message p').text("Unggah gambar disini");
		
		//untuk deteksi scroll
		window.onscroll = function(ev) {
			
			//kalau sudah sampai dibawah
			if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
				
				//nanti di isi ajax buat post
				
			}
		};
		
		//edit comment di klik
		$(document).on('click','.modal-edit-comment',function(){
			var id = $(this).attr("id-comment");
			$.ajax({
				method: "post",
				url: '<?= base_url("CComment/ajaxEditComment") ?>',
				data: {	id: id
					},
				beforeSend: function () {
                    $('#modal-edit-comment').html("");
                }
			}).fail(function(jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
			}).done(function(result) {
				$('#modal-edit-comment').html(result);
				$('#textarea2').trigger('autoresize');
			});
		})

		//delete post di klik
        $(document).on('click','.modal-delete',function(){
            var id = $(this).attr("id-post");
            $("#modal-delete>.modal-footer>.btn-yes").attr("href","<?php echo base_url('CHome/deletePost/'); ?>"+id)
        })
		
		//delete comment di klik
        $(document).on('click','.modal-delete-comment',function(){
            var id = $(this).attr("id-comment");
            $("#modal-delete-comment>.modal-footer>.btn-yes").attr("href","<?php echo base_url('CComment/deleteComment/'); ?>"+id)
        })
		$(document).ajaxStart(function() {
			$( ".preloader-wrapper" ).show();
		});
		
		$(document).ajaxStop(function(){
			$( ".preloader-wrapper" ).hide();
		})
		
		$(document).on('click','.show-comment',function(){
			var id = $(this).attr("komentar");
			if($("#fieldComment-"+id+"").css('display') == 'none'){
				$("#fieldComment-"+id+"").css('display', 'block');
				$.ajax({
					method: "post",
					url: '<?= base_url("CComment/ajaxLoadCommentCompany") ?>',
					data: {	id: id,
							// endPost: endPost
						},
					beforeSend: function () {
						$("#fieldComment-"+id+">.card-content").html("LOADING....");
					}
				}).fail(function(jqXHR, textStatus, errorThrown) {
					console.log(errorThrown);
				}).done(function(result) {
					$("#fieldComment-"+id+">.card-content").html(result);
				});
			}else{
				$("#fieldComment-"+id+"").css('display', 'none');
			}
		});
		$(document).on('submit','.submitComment',function(event){
			var id = $(this).attr("komentar");
			event.preventDefault();
			$.ajax({
				url: '<?= base_url("CComment/submit_comment_company") ?>',
				type: "POST",            
				data: new FormData(this),
				contentType: false,      
				cache: false,            
				processData:false, 
			}).fail(function(jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
			}).done(function(result) {
				$("#fieldComment-"+id+">.card-content").append(result);
				$("#comment-textarea-"+id).val("");
				$(".dropify-clear").trigger("click");
			});
		});
		
	});
	</script>