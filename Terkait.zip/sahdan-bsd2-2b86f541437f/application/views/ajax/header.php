<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<title>Terkait</title>
	<link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.ico') ?>" type="image/x-icon">
	
	<script src="<?php echo base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
	<link href="<?php echo base_url('assets/css/materialize.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/css.css'); ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/dropify.min.css'); ?>" rel="stylesheet">
	
	<script src="<?php echo base_url('assets/js/materialize.min.js') ?>"></script>
	
	<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/dropify.min.js') ?>"></script>
	
</head>