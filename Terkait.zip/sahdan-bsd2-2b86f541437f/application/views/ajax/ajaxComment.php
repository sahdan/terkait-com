<?php
require('header.php');
foreach($comment as $item){
	$img = $item->image_link;
?>
	<form method="post" action="<?php echo base_url('CComment/edit_comment');?>" enctype="multipart/form-data">
		<div class="card comment" style="padding-bottom: 35px;">
			<div class="card-content">
				<div class="row">
					<div class="input-field col s12">
					  <textarea id="textarea2" name='edContent' class="materialize-textarea" placeholder="Tulis disini..." ><?php echo $item->comment_content; ?></textarea>
					</div>
				</div>
				<input type="text" style="display:none;" name="edIdComment" value="<?php echo $item->comment_id; ?>">
				<input name='edImage' type="file" id="idImage" class="dropify new"/>
				<?php if($img != ""){ ?>
				<img style="margin: 20%; margin-top: 5%;  margin-bottom: 5%; width: 60%;" src="<?php echo $img; ?>" />
				<?php } ?>
			</div>	
			<div class="card-action comment-action">
				<button class="btn btn-comment waves-effect waves-light right indigo darken-4" type="submit" name="action">Edit
				</button>
			</div>
		</div>
	</form>
<?php }?>

<script>
	$(document).ready(function(){
		$('select').formSelect();
		$('.dropify.new').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		//ganti text nya dropify
		$('.comment .dropify-message p').text("Unggah gambar disini");
		M.textareaAutoResize($('#textarea2'));
	});
</script>