<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.collapsible-body{
    border-top: 1px solid #ddd;
    border-top-width: 1px;
    border-top-style: solid;
    border-top-color: rgb(221, 221, 221);
}
.collapsible-li{
    border-bottom: 1px solid #ddd;
    border-bottom-width: 1px;
    border-bottom-style: solid;
    border-bottom-color: rgb(221, 221, 221);
}
.collapsible-header{
    border:none!important;
}
</style>
<?php
	$flag = false;
	if($job_applier){ ?> 
    <h5 style="padding:10px;">Daftar Pelamar</h5>
    <div class="card">
        <ul class="collapsible expandable jobApp">
            <?php 
            $prev_applier_id = -1;
            foreach($job_applier as $item){ ?>
                <?php if($prev_applier_id != -1 && $item->applier_id != $prev_applier_id){ ?>
                            </ul>
                        </div>
                    </li>
                <?php } ?>
                <?php if($item->applier_id != $prev_applier_id){
						$flag = true;
						$ctr = 0;
						$skillOwned = 0;
						foreach($job_applier as $item1){
							if($item->applier_id == $item1->applier_id ){
								if($item1->is_owned == 1){
									$skillOwned++;
								}
								$ctr++;	
							}
						}
					?>
                    <li class="collapsible-li jobApplier" data-order="<?php echo $skillOwned; ?>">
                        <div class="collapsible-header">
                            <?php echo $item->full_name;?>
							<span style="color:blue; font-size:12px;margin-left: 10px;padding-top:1px;">
								<?php  echo " (Mempunyai $skillOwned dari $ctr skill yang dibutuhkan)" ?>
							</span>
                            <span style="right:20px;position:absolute;">
                                <a href="<?php echo base_url('CProfile/index/').$item->applier_id;?>" style="position:relative;float:right;right:0px;">
                                    (see profil)
                                </a>
                            </span>
                        </div>
                        <?php if($item->skill_name){ ?>
                        <div class="collapsible-body">
                            <ul>
                        <?php } ?>
                <?php 
                $prev_applier_id = $item->applier_id;
                } ?>
                <?php if($item->skill_name){ ?>
                    
                    <li style="padding:10px 0px;">
                        <span class="secondary-content left" style="margin-right:10px;">
                            <?php if($item->is_owned == 1){?>
                                <i class="material-icons" style="color:blue;">done</i>
                            <?php } else { ?> 
                                <i class="material-icons" style="color:red;">close</i>
                            <?php } ?>
                        </span>
                        <?php echo $item->skill_name;?>
                    </li>
                <?php } ?>
            <?php } ?>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
<?php } ?>
<script>
	<?php if($job_applier){?>
	function getSorted(selector, attrName) {
		return $($(selector).toArray().sort(function(a, b){
			var aVal = parseInt(a.getAttribute(attrName)),
				bVal = parseInt(b.getAttribute(attrName));
			return bVal - aVal;
		}));
	};
	<?php } ?>
    $(document).ready(function(){
        $('.collapsible').collapsible();
        var elem = document.querySelector('.collapsible.expandable');
        var instance = M.Collapsible.init(elem, {
            accordion: false
        });
        $(".box > a").click(function(e) {
            e.stopPropagation();
            console.log("huray");
        });
		<?php if($job_applier){?>
			$('.jobApp').html(getSorted('.jobApplier', 'data-order'));
		<?php } ?>
    });
	
</script>