<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php if($job_skill){ ?>
<h5 style="padding:10px;">Daftar Keterampilan yang dibutuhkan</h5>
<div class="card">
    <ul class="collection">
        <?php foreach($job_skill as $item){ ?>
            <li class="collection-item" style="padding:15px 20px;">
                <div>
                    <?php echo $item->skill_name;?>
                    <span class="secondary-content left" style="margin-right:10px;">
                        <?php if($item->is_skill_owned == 1){?>
                            <i class="material-icons" style="color:blue;">done</i>
                        <?php } else { ?> 
                            <i class="material-icons" style="color:red;">close</i>
                        <?php } ?>
                    </span>
                </div>
            </li>
        <?php } ?>
    </ul>
</div>
<?php } ?>