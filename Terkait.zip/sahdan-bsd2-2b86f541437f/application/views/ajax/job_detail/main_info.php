<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<style>
</style>

<span><b>Job Position</b> <br><?php echo $job->job_position;?></span><br><br>
<span><b>Job Description</b> <br><?php echo nl2br($job->job_description  );?></span><br><br>
<span><b>Seniority Level</b> <br><?php echo $job->seniority_level;?></span><br><br>
<span><b>Industry</b> <br><?php echo $job->industry;?></span><br><br>
<span><b>Employment Type</b> <br><?php echo $job->employment_type;?></span><br><br>
<span><b>Job Functions</b> <br><?php echo $job->job_functions;?></span><br><br>
<span><b>Created At</b> <br><?php echo date_format(date_create($job->created_at),'l jS F Y');?></span><br><br>
<span><b>Expired At</b> <br><?php echo date_format(date_create($job->expired_at),'l jS F Y');?></span><br><br>
<span><b>Min Salary</b> <br><?php echo number_format($job->min_gaji);?></span><br><br>
<span><b>Max Salary</b> <br><?php echo number_format($job->max_gaji);?></span><br><br>

<script>
</script>