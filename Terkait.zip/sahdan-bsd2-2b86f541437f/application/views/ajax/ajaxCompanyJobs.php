<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.jobs-card:hover{
	box-shadow: 0 0 0 1px rgba(0,0,0,.15), 0 2px 3px rgba(0,0,0,.2), 0 2px 3px rgba(0,0,0,.2);
	cursor: pointer;
}
.jobs-card{
    z-index: 1;
    opacity: .99;
    min-height: 380;
    max-height: 380;
    overflow-y: hidden;
}
.div-edit-pekerjaan{
    position:absolute;
    right:30px;
    z-index: 2;
}
.div-edit-pekerjaan a{
    position:relative;
    float:right;
    top:20px;
}
</style>
<?php if($user_company["status"] != -1){ ?>
    <div class="col s12">
        <ul class="tabs">
            <li class="tab col s6"><a class="active" href="#tab-lowongan-aktif">Aktif</a></li>
            <li class="tab col s6"><a href="#tab-lowongan-tidak-aktif">Tidak Aktif</a></li>
        </ul>
    </div>
    <div class="col s12">
        <div id="tab-lowongan-aktif">
            <?php foreach ($jobs as $item) {?>
                <?php if($item->status == "1"){ ?>
                    <div class="col s12 m6 l4 lowongan-aktif" style="position:relative;">
                        <div class="div-edit-pekerjaan">
                            <input class="jobId" name="edJobId" type="hidden" value="<?php echo $item->job_id;?>">
                            <input class="companyId" name="edCompanyId" type="hidden" value="<?php echo $item->company_id;?>">
                            <?php if($user_company["status"] != -1){ ?>
                                <a href="#modalPekerjaan" class="modal-trigger secondary-content edit-pekerjaan"><i class="material-icons" style="color:blue;">edit</i></a>
                            <?php } ?>
                        </div>
                        <a href="<?php echo base_url('CJob/detail/').$item->job_id;?>" style="color:inherit;">
                        <div class="card jobs-card" style="padding:24px;">
                            <div class="card-content" style="overflow-x: hidden;padding:0px;">
                                <span class="card-title">
                                    <?php if($item->logo_url){ ?>
                                        <img id="logo-perusahaan" style="padding:20px;max-width:100px;max-height:100px;" src="<?php echo $item->logo_url;?>">
                                    <?php } else {?>
                                        <img id="logo-perusahaan" style="padding:20px;max-width:100px;max-height:100px;" src="<?php echo base_url('assets/images/company.png');?>">
                                    <?php }?>
                                </span>
                                <b><?php  echo $item->company_name;?></b><br>
                                Jabatan : <?php echo $item->job_position;?><br>
                                <span style="color:blue; font-weight: lighter;font-size: small;">
                                <?php echo "Gaji : Rp ".number_format($item->min_gaji)." ~ Rp ".number_format($item->max_gaji);?></span><br>
                                <span style="font-weight: lighter;font-size: small;">
                                <?php if(isset($item->company_address)) { ?>
                                    <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->company_address;?></div>
                                    <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->city;?></div>
                                    <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->state;?></div>
                                <?php } ?>
                                </span>
                                <div class="divider" style="width:50px;margin: 5px 0px;"></div>
                                <span style="font-weight: lighter;font-size: small;">
                                <!--Dibuka : <?php echo date_format(date_create($item->created_at),'l jS F Y');?><br>
                                Ditutup : <?php echo date_format(date_create($item->expired_at),'l jS F Y');?> -->
                                Dibuka <?php echo $item->created_at;?><br>
                                Ditutup sebelum tanggal <?php echo date_format(date_create($item->expired_at),'j/m/Y');?>
                                </span>
                                <div class="divider" style="width:50px;margin: 5px 0px;"></div>
                                <span>
                                    <?php if($item->count_required_skill){?>
                                        <?php echo "Kamu mempunyai ".$item->count_owned_skill." dari ".$item->count_required_skill." skill yang dibutuhkan"; ?><br>
                                    <?php }else{ ?>
                                        Skill tidak disebutkan<br>
                                    <?php } ?>
                                </span>
                            </div>
                        </div>
                        </a>
                    </div>
                <?php } ?>
            <?php }?>
        </div>
        <div id="tab-lowongan-tidak-aktif">
            <?php foreach ($jobs as $item) {?>
                <?php if($item->status == "0"){ ?>
                    <div class="col s12 m6 l4 lowongan-tidak-aktif" style="position:relative;">
                        <div class="div-edit-pekerjaan">
                            <input class="jobId" name="edJobId" type="hidden" value="<?php echo $item->job_id;?>">
                            <input class="companyId" name="edCompanyId" type="hidden" value="<?php echo $item->company_id;?>">
                        </div>
                        <a href="<?php echo base_url('CJob/detail/').$item->job_id;?>" style="color:inherit;">
                        <div class="card jobs-card" style="padding:24px;">
                            <div class="card-content" style="overflow-x: hidden;padding:0px;">
                                <span class="card-title">
                                    <?php if($item->logo_url){ ?>
                                        <img id="logo-perusahaan" style="padding:20px;max-width:100px;max-height:100px;" src="<?php echo $item->logo_url;?>">
                                    <?php } else {?>
                                        <img id="logo-perusahaan" style="padding:20px;max-width:100px;max-height:100px;" src="<?php echo base_url('assets/images/company.png');?>">
                                    <?php }?>
                                </span>
                                <b><?php  echo $item->company_name;?></b><br>
                                Jabatan : <?php echo $item->job_position;?><br>
                                <span style="color:blue; font-weight: lighter;font-size: small;">
                                <?php echo "Gaji : Rp ".number_format($item->min_gaji)." ~ Rp ".number_format($item->max_gaji);?></span><br>
                                <span style="font-weight: lighter;font-size: small;">
                                <?php if($item->company_address) { ?>
                                    <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->company_address;?></div>
                                    <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->city;?></div>
                                    <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->state;?></div>
                                <?php } ?>
                                </span>
                                <div class="divider" style="width:50px;margin: 5px 0px;"></div>
                                <span style="font-weight: lighter;font-size: small;">
                                <!--Dibuka : <?php echo date_format(date_create($item->created_at),'l jS F Y');?><br>
                                Ditutup : <?php echo date_format(date_create($item->expired_at),'l jS F Y');?> -->
                                Dibuka <?php echo $item->created_at;?><br>
                                Ditutup sebelum tanggal <?php echo date_format(date_create($item->expired_at),'j/m/Y');?>
                                </span>
                                <div class="divider" style="width:50px;margin: 5px 0px;"></div>
                                <span>
                                    <?php if($item->count_required_skill){?>
                                        <?php echo "Kamu mempunyai ".$item->count_owned_skill." dari ".$item->count_required_skill." skill yang dibutuhkan"; ?><br>
                                    <?php }else{ ?>
                                        Skill tidak disebutkan<br>
                                    <?php } ?>
                                </span>
                            </div>
                        </div>
                        </a>
                    </div>
                <?php } ?>
            <?php }?>
        </div>
    </div> 
<?php } else { ?>
    <div id="tab-lowongan-aktif">
        <?php foreach ($jobs as $item) {?>
            <?php if($item->status == "1"){ ?>
                <div class="col s12 m6 l4 lowongan-aktif" style="position:relative;">
                    <div class="div-edit-pekerjaan">
                        <input class="jobId" name="edJobId" type="hidden" value="<?php echo $item->job_id;?>">
                        <input class="companyId" name="edCompanyId" type="hidden" value="<?php echo $item->company_id;?>">
                        <?php if($user_company["status"] != -1){ ?>
                            <a href="#modalPekerjaan" class="modal-trigger secondary-content edit-pekerjaan"><i class="material-icons" style="color:blue;">edit</i></a>
                        <?php } ?>
                    </div>
                    <a href="<?php echo base_url('CJob/detail/').$item->job_id;?>" style="color:inherit;">
                    <div class="card jobs-card" style="padding:24px;">
                        <div class="card-content" style="overflow-x: hidden;padding:0px;">
                            <span class="card-title">
                                <?php if($item->logo_url){ ?>
                                    <img id="logo-perusahaan" style="padding:20px;max-width:100px;max-height:100px;" src="<?php echo $item->logo_url;?>">
                                <?php } else {?>
                                    <img id="logo-perusahaan" style="padding:20px;max-width:100px;max-height:100px;" src="<?php echo base_url('assets/images/company.png');?>">
                                <?php }?>
                            </span>
                            <b><?php  echo $item->company_name;?></b><br>
                            Jabatan : <?php echo $item->job_position;?><br>
                            <span style="color:blue; font-weight: lighter;font-size: small;">
                            <?php echo "Gaji : Rp ".number_format($item->min_gaji)." ~ Rp ".number_format($item->max_gaji);?></span><br>
                            <span style="font-weight: lighter;font-size: small;">
                            <?php if($item->company_address) { ?>
                                <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->company_address;?></div>
                                <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->city;?></div>
                                <div style="white-space: nowrap; text-overflow:ellipsis;"><?php echo $item->state;?></div>
                            <?php } ?>
                            </span>
                            <div class="divider" style="width:50px;margin: 5px 0px;"></div>
                            <span style="font-weight: lighter;font-size: small;">
                            <!--Dibuka : <?php echo date_format(date_create($item->created_at),'l jS F Y');?><br>
                                Ditutup : <?php echo date_format(date_create($item->expired_at),'l jS F Y');?> -->
                                Dibuka <?php echo $item->created_at;?><br>
                                Ditutup sebelum tanggal <?php echo date_format(date_create($item->expired_at),'j/m/Y');?>
                            </span>
                            <div class="divider" style="width:50px;margin: 5px 0px;"></div>
                            <span>
                                <?php if($item->count_required_skill){?>
                                    <?php echo "Kamu mempunyai ".$item->count_owned_skill." dari ".$item->count_required_skill." skill yang dibutuhkan"; ?><br>
                                <?php }else{ ?>
                                    Skill tidak disebutkan<br>
                                <?php } ?>
                            </span>
                        </div>
                    </div>
                    </a>
                </div>
            <?php } ?>
        <?php }?>
    </div>
<?php } ?>
<script>
    $(document).ready(function(){
        // console.log($('.lowongan-aktif').length);
        // console.log($('.lowongan-tidak-aktif').length);
        if($('.lowongan-aktif').length == 0){
            $('#tab-lowongan-aktif').append('<P style="margin-left:10px;margin-top:10px;">Daftar kosong.</P>');
        }
        <?php if($user_company["status"] != -1){ ?>
            if($('.lowongan-tidak-aktif').length == 0){
                $('#tab-lowongan-tidak-aktif').append('<P style="margin-left:10px;margin-top:10px;">Daftar kosong.</P>');
            }
        <?php } ?>
        $('.tabs').tabs();
    });
</script>
