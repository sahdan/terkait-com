<?php
require('header.php');
?>

<?php 
	//tampilkan 10 post terakhir
	// $post dapat dari CHOME $data['post']
	foreach($post as $item){
		?>
		<div class="card">
			<div class="card-content row">
				<div class="col s10 m10 l10">
				<a href="http://localhost/bsd2/CProfile/index/<?php echo $item->account_id?>"><span class="card-title" style="display: flex; align-items: center; margin-left: -10px;">
				<div class="circle" style="height:60px;width:60px;background-color:white;left:calc(50% - 50px)">
										<?php if($item->photo_url != "" || $item->logo_url != "") { ?>
												<img src="<?php echo $item->photo_url.$item->logo_url; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:3px">
										<?php } else { ?>
												<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:3px">
										<?php } ?>
										</div>
										<?php echo $item->user_first_name . $item->company_name . ' ' . $item->user_last_name;?>
										<span style="color:gray; font-size: 12px; margin-top: 4px;"> &nbsp - <?php echo $item->created_at; ?></span>
									
									<?php if ($item->account_id == $_SESSION["user_id"]) { ?>
									
									
									<?php 
							} ?>
				</span>
				</a></div>
				<div class="col s2 m2 l2">
					<?php if($item->account_id == $_SESSION["user_id"]){?>
						<i class="material-icons right activator">more_vert</i>
					<?php } ?>
				</div>
				<div class="col s12 m12 l12">
					<pre class="post-content"><?php echo $item->post_content; ?></pre>
				</div>
				<?php if($item->media_link != ""){
					?>
						<br>
						<img class="responsive-img img-post" src="<?php echo $item->media_link; ?>" \>
					<?php
				}?>
			</div>
			<?php if($item->account_id == $_SESSION["user_id"]){?>
				<div class="card-reveal">
					<span class="card-title grey-text text-darken-4"><i class="material-icons right">close</i></span>
					<ul class="right">
						<li>
							<a class="modal-trigger waves-effect waves-light modal-edit" id-post="<?php echo $item->post_id; ?>" href="#modal-edit"><i class="material-icons left">edit</i>Edit</a>
						</li>
						<li>
							<a class="modal-trigger waves-effect waves-light modal-delete" id-post="<?php echo $item->post_id; ?>" href="#modal-delete"><i class="material-icons left">delete</i>Delete</a>
						</li>
					</ul>
				</div>
			<?php } ?>
			<div class="card-action">
				<a idPost="<?php echo $item->post_id; ?>" <?php if($item->flag != 1){echo ' class="like" ';}?> ctrLikes="<?php echo $item->likes; ?>" id="like-<?php echo $item->post_id; ?>" flag="true"><?php echo $item->likes; ?> Suka</a>
				<a class="waves-effect btn-flat show-comment" komentar="<?php echo $item->post_id; ?>"><?php echo $item->ctrComment; ?> komentar</a>
			</div>
			<div id="fieldComment-<?php echo $item->post_id;?>" class="fieldComment" style="display:none">
				<div class="card-content" style="background-color: #eaeaea;">
					
				</div>
				<form method="post" class="submitComment" komentar="<?php echo $item->post_id; ?>" action="<?php echo base_url('CComment/submit_comment');?>" enctype="multipart/form-data">
					<div class="card-content" style="background-color: #eaeaea;padding: 5px;">
						<input name="edIdPost" value="<?php echo $item->post_id; ?>" style="display:none">
						<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="responsive-img" style="width: 35px;margin: 15px 0px;">
						<textarea class="materialize-textarea content"  id="comment-textarea" name='edContent' placeholder="Tulis disini..." style="height: 45px;width: 100%;background-color: white;"></textarea>
						<input name='edImage' type="file" id="idImageComment" class="dropify edit" />
					</div>
					<div style="height: 50px;background-color: #eaeaea; padding-top: 10px;padding-right: 10px;">
						<button class="btn btn-post waves-effect waves-light right indigo darken-4" type="submit" name="action">Post</button>
					</div>
				</form>
			</div>
		</div>
		<?php
	}
?>
<script>
	startPost = <?php echo $start;?>;
	$(document).ready(function() {
		$('.modal').modal();
		//deklarasi dropify
		$('.dropify.edit').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		
		//ganti text nya dropify
		$('.post .dropify-message p').text("Unggah gambar disini");
		
	})
</script>