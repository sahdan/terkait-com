<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php if($company_locations) { ?>
    <?php $kantor_pusat = 1; ?>
    <?php $header_cabang = 1; ?>
    <?php foreach($company_locations as $item) {?>
        <?php if($kantor_pusat == 1){ ?>
            <div style="font-size:24px;">Kantor Pusat</div>
            <div class="divider" style="margin:5px;"></div>
            <div id="div-kantor-pusat">
                <div style="min-height:62px;">
                    <input class="id-lokasi" type="hidden" name="edLocationId" value="<?php echo $item->company_location_id; ?>"/>
                    <button style="float:right; margin-top:3px; color: #0D47A1; background-color:transparent !important;" data-target="modalLokasi" class="btn-flat modal-trigger right edit-lokasi">
                        <i class="material-icons">edit</i>
                    </button>
                    <div><?php echo $item->company_address; ?></div>
                    <div><?php echo $item->city.', '.$item->state; ?></div>
                    <div>Kode Pos : <?php echo $item->zip_code2; ?></div>
                    <?php if($item->building_name){ ?> 
                        <div>Nama Bangunan : <?php echo $item->building_name; ?></div>
                    <?php } ?>
                    <?php if($item->suite_apt){ ?> 
                        <div>Apartemen : <?php echo $item->suite_apt; ?></div>
                    <?php } ?>
                </div>
                <div class="divider" style="margin:5px;"></div>
            </div>
            <?php $kantor_pusat = 0; ?>
        <?php } else { ?>
            <?php if($header_cabang == 1){ ?>
                <div id="header-cabang">
                    <div style="font-size:24px;">Cabang</div>
                    <div class="divider" style="margin:5px;"></div>
                    <?php $header_cabang = 0;?>
                </div>
            <?php } ?>
            <div>
                <div style="min-height:62px;">
                    <input class="id-lokasi" type="hidden" name="edLocationId" value="<?php echo $item->company_location_id; ?>"/>
                    <button style="float:right; margin-top:3px; color: #0D47A1; background-color:transparent !important;" data-target="modalLokasi" class="btn-flat modal-trigger right edit-lokasi">
                        <i class="material-icons">edit</i>
                    </button>
                    <div><?php echo $item->company_address; ?></div>
                    <div><?php echo $item->city.', '.$item->state; ?></div>
                    <div>Kode Pos : <?php echo $item->zip_code2; ?></div>
                    <?php if($item->building_name){ ?> 
                        <div>Nama Bangunan : <?php echo $item->building_name; ?></div>
                    <?php } ?>
                    <?php if($item->suite_apt){ ?> 
                        <div>Apartemen : <?php echo $item->suite_apt; ?></div>
                    <?php } ?>
                </div>
            </div>
            <div class="divider" style="margin:5px;"></div>
        <?php } ?>
    <?php }	?>
<?php } else {?>
    <div class="row col s12">
        <P>Lokasi perusahaan belum didaftarkan.</P>
    </div>
<?php } ?>
