<form class="regis" method="post" action="<?php echo base_url('CAdmin/editAdmin');?>" enctype="multipart/form-data">
	<div class="modal-content">
		<h6>Tambah Admin</h6>
		<div id="form-regis card-content" >
			<div>
				<?php foreach($listAdmin as $item){?>
				<input type="text" name="edId" hidden value="<?php echo $item->admin_id; ?>">
						
				<div class="form-group">
					<div class="input-field col s12">
						<input id="firstName" type="text" name="edFirstName" value="<?php echo $item->admin_first_name; ?>" required oninvalid="this.setCustomValidity('Masukkan Nama Depan Anda')" oninput="setCustomValidity('')">
						<label for="firstName" >Nama Depan *</label>
					</div>
					<div class="input-field col s12">
						<input id="lastName" type="text" name="edLastName" value="<?php echo $item->admin_last_name; ?>">
						<label for="lastName" >Nama Belakang (optional)</label>
					</div>
					<div class="input-field col s12">
						<input id="email" type="text" name="edEmail" value="<?php echo $item->admin_email; ?>" required oninvalid="this.setCustomValidity('Masukkan Alamat Email Anda')" oninput="setCustomValidity('')">
						<label for="email" >Email *</label>
					</div>
					<div class="input-field col s12">
						<input id="password" type="password" name="edPassword" required oninvalid="this.setCustomValidity('Masukkan Kata Sandi Anda')" oninput="setCustomValidity('')">
						<label for="password" >Kata Sandi *</label>
					</div>
					<div class="input-field col s12">
						<input id="confPassword" type="password" name="edConfPassword" required oninvalid="this.setCustomValidity('Masukkan Konfirmasi Kata Sandi Anda')" oninput="setCustomValidity('')">
						<label for="confPassword" >Konfirmasi Kata Sandi *</label>
						<div class="validErr" style="display:none">Kata Sandi Tidak Sama</div>
					</div>
				</div>
				<?php }?>
			</div>
		</div>
	</div>
	<div class="modal-footer">
		<a href="#" class="modal-close waves-effect waves-green btn btn-yes red">Batal</a>
		<button class="btn waves-effect waves-light indigo darken-4" type="submit" name="action">Buat
			<i class="material-icons right">send</i>
		</button>
	</div>
</form>
<script>
	$(document).ready(function() {	
		$("#confPassword").keyup(function() {
			if($("#password").val() != $("#confPassword").val()){
				$(".validErr").show();
			}
			else{
				$(".validErr").hide();
			}
		});
		
		$(".regis").submit(function(e){
			if($(".validErr").is( ':visible' )){
				e.preventDefault();
			}
		});
	});
</script>