<?php
require('header.php');
?>

<?php 
	foreach($comments as $item){
		?>
		<span class="card-title">
			<div class="circle col s4 m4 l4" style="height:40px;width:40px;background-color:white;left:calc(50% - 50px)">
				<?php if($item->photo_url != "" || $item->logo_url) { ?>
						<img src="<?php echo $item->photo_url.$item->logo_url; ?>" class="circle valign profile-image blue darken-2" style="height:90%;margin:2px; margin-left: -9px;">
				<?php } else { ?>
						<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle valign profile-image blue darken-2" style="height:90%; margin:2px; margin-left: -9px;">
				<?php } ?>
			</div>
		<?php echo $item->user_first_name.$item->company_name. ' ' . $item->user_last_name; ?>
		<?php if ($item->account_id == $this->uri->segment(3)) { ?>
			<a class="modal-trigger waves-effect waves-light modal-delete-comment right" id-comment="<?php echo $item->comment_id; ?>" href="#modal-delete-comment"><i class="material-icons left">delete</i></a>
			<a class="modal-trigger waves-effect waves-light modal-edit-comment right" id-comment="<?php echo $item->comment_id; ?>" href="#modal-edit-comment"><i class="material-icons left">edit</i></a>
		<?php 
		} ?>
		</span>
		
		<pre class="post-content" style="margin: 15px 0px 5px 31px;"><?php echo $item->comment_content; ?></pre>
		<?php if($item->image_link != ""){
			?>
				<br>
				<img class="responsive-img img-post" src="<?php echo $item->image_link; ?>" style="margin-left: 33px;"\>
			<?php
		}?>
		<?php
	}
?>