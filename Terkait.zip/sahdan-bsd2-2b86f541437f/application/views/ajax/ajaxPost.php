<?php
require('header.php');
foreach($post as $item){
	$img = $item->media_link;
?>
	<form method="post" action="<?php echo base_url('CHome/edit_post');?>" enctype="multipart/form-data">
		<div class="card post">
			<div class="card-content">
				<div class="row">
					<div class="input-field col s12">
					  <textarea id="textarea1" name='edContent' class="materialize-textarea" placeholder="Tulis disini..." ><?php echo $item->post_content; ?></textarea>
					</div>
				</div>
				<input type="text" style="display:none;" name="edIdPost" value="<?php echo $item->post_id; ?>">
				<input name='edImage' type="file" id="idImage" class="dropify new"/>
				<?php if($img != ""){ ?>
				<img style="margin: 20%; margin-top: 5%;  margin-bottom: 5%; width: 60%;" src="<?php echo $img; ?>" />
				<?php } ?>
			</div>	
			<div class="card-action post-action">
				<button class="btn btn-post waves-effect waves-light right indigo darken-4" type="submit" name="action">Edit
				</button>
			</div>
		</div>
	</form>
<?php }?>

<script>
	$(document).ready(function(){
		$('select').formSelect();
		$('.dropify.new').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		//ganti text nya dropify
		$('.post .dropify-message p').text("Unggah gambar disini");
		M.textareaAutoResize($('#textarea1'));
	});
</script>