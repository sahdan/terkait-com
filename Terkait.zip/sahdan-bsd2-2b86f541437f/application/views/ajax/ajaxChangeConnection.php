<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<input id="status-koneksi" type="hidden" value="<?php echo $status;?>">
<?php 
    if($status == "-1") { ?>
        <button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
            <i style="margin-right:5px;" class="material-icons left">add</i>
            TAMBAH KONEKSI
        </button>
        <button id="koneksi-2" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
            <i style="margin-right:5px;" class="material-icons left">do_not_disturb</i>
            BLOKIR USER
        </button>
    <?php } elseif($status == "0") { ?>
        <button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
            <i style="margin-right:5px;" class="material-icons left">clear</i>
            BATALKAN KONEKSI	
        </button>
    <?php } elseif($status == "1") { ?>
        <button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
            <i style="margin-right:5px;" class="material-icons left">delete</i>
            HAPUS KONEKSI
        </button>
    <?php } elseif($status == "2") { ?>
        <button id="koneksi-2" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
            UNBLOK USER
        </button>
    <?php } 
?>
