<div><?php
foreach($message as $item){
?>
	<?php if($_SESSION["user_id"] == $item->user_id){
		?>
			<div style="margin-left:20px;" class="row right col s12 m6 l6">
				<div style="background-color:#d3d3d3; margin:30px; padding:20px; border-radius:30px;word-wrap: break-word;">
				<b><?php echo $item->name?></b>
				<br>
				<?php echo $item->message_content?>
				</div>
			</div>
		<?php
	}else{ ?>
		<div style="margin-left:20px;" class="row col s12 m6 l6">
				<div class="circle" style="height:50px;width:50px;background-color:white;margin-left:-25px;  border: white solid; margin-top: -50px;">
										<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="    margin-top: 75px;">
									</div>
				<div style="background-color:skyblue; margin:30px; padding:20px; border-radius:30px;word-wrap: break-word;">
				<b><?php echo $item->name?></b>
				<br>
				<?php echo $item->message_content?>
				</div>
			</div>
<?php 
}
}
?>
<div>