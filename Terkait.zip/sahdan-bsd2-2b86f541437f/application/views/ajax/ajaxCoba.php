<?php 
	var_dump($post);
?>