<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.collection li.collection-item:not(.active):hover {
    background-color: #ddd;
	cursor: pointer;
}
.collection li.collection-item{
    z-index: 1;
    position: relative;
}
.div-hapus-perusahaan{
    position:absolute;
    right:30px;
    z-index: 2;
}
.div-hapus-perusahaan a{
    position:relative;
    float:right;
    top:20px;
}
</style>
<?php if(empty($user_company) || count($user_company) == 0) { ?>
    <div class="row">
        Tidak ada perusahaan terkait.
    </div>
<?php } else {?>
    <h4>Daftar Perusahaan</h4>
    <ul id="list-perusahaan" class="collection">
    <!--  Menampilkan perusahaan yang terkait dengan user(item) -->
    <?php foreach($user_company as $item) {?>
        <div id="perusahaan-<?php echo $item->company_id;?>">
            <?php if($item->status == 1){ ?>
                <div class="div-hapus-perusahaan" style="margin-top: 2px;">
                    <input type="hidden" name="edCompanyId" value="<?php echo $item->company_id; ?>"/>
                    <a href="#modalHapusPerusahaan" class="btn-floating btn-flat btn-no-hover blue darken-4 secondary-content modal-trigger hapus-perusahaan"><i class="material-icons left">delete</i></a>
                </div>
            <?php } ?>
            <a href="<?php echo base_url('CCompany/profil/').$item->company_id;?>" class="collection-item avatar" style="padding-top:20px;">
                <div class="list-item-perusahaan">
                    <input type="hidden" name="edCompanyId" value="<?php echo $item->company_id; ?>"/>
                    <?php if($item->logo_url != ""){ ?>
                    <img class="circle" src="<?php echo $item->logo_url; ?>"\>	
                    <?php } else { ?>
                    <i class="material-icons circle blue darken-4">work</i>
                    <?php } ?>
                    <div style="float:left;margin-top:10px;">
                        <?php echo $item->company_name; ?>
                        <?php if($item->status == 1){ ?>
                            (Sebagai super admin)
                        <?php } elseif($item->status == 0){ ?>
                            (Sebagai admin)
                        <?php } ?>
                    </div>
                    <?php if($item->status == 1) { ?>
                    <?php } ?>
                </div>
            </a>
        </div>
    <?php }	?>
    <!-- selesai for each -->
    </ul>
<?php } ?>
<script>
</script>