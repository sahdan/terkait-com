<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
</style>
<ul class="collection with-header">
    <li class="collection-header"><h6>Daftar Koneksi</h6></li>
    <?php 
    //tampilkan List Koneksi
    // $connections dapat dari CCompany $param['connections']
    foreach ($connections as $item) {
    ?>
    <li class="collection-item avatar">
        <div class="circle" style="height:60px;width:60px;background-color:#0D47A1;">
        <?php if($item->photo_url != "") { ?>
            <img src="<?php echo $item->photo_url; ?>" class="circle" style="width:100%;height:100%;margin-left:-15px">
        <?php } else { ?>
            <img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle" style="width:100%;height:100%;margin-left:-15px">
        <?php } ?>
            
        </div>
        <p style="margin:20px 0 0 20px;"><?php echo $item->name?><br>
        </p>
        <?php if(!in_array($item->user_id, $admin_company_id)){ ?>
            <input type="hidden" name="edConnectionId" value="<?php echo $item->user_id;?>"/>
            <button style="margin-top: 10px;" type="button" class="btn-small blue darken-4 secondary-content tambah-admin"><i class="material-icons left">add</i>TAMBAH ADMIN</a>
        <?php } ?>
    </li>
    <?php } ?>
</ul>
<script>
    $(document).ready(function(){

    });
</script>