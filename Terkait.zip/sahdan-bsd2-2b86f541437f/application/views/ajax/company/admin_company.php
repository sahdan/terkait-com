<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
</style>
<div class="divider" style="margin:5px 5px 10px 0px"></div>
<?php if($admin_company){ ?> 
    <ul class="collection">
        <?php 
        //tampilkan List Admin
        // $admin_company dapat dari CCompany $param['admin_company']
        foreach ($admin_company as $item) {
        ?>
        <li class="collection-item avatar">
            <div class="circle" style="height:60px;width:60px;background-color:#0D47A1;">
            <?php if($item["photo_url"] != "") { ?>
                <img src="<?php echo $item["photo_url"]; ?>" class="circle" style="width:100%;height:100%;margin-left:-15px">
            <?php } else { ?>
                <img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle" style="width:100%;height:100%;margin-left:-15px">
            <?php } ?>
            </div>
            <p style="margin:20px 0 0 20px;">
                <?php echo $item["user_name"];?>
            </p>
            <input type="hidden" name="edAdminId" value="<?php echo $item["user_id"];?>"/>
            <button style="margin-top: 7px;" class="btn-floating btn-flat btn-no-hover blue darken-4 secondary-content delete-admin"><i class="material-icons left">delete</i></button>
        </li>
        <?php } ?>
    </ul>
<?php } else { ?>
    <div class="row" style="margin-left:5px;">
        Tidak ada admin selain super admin.
    </div>
<?php } ?>
<script>
    $(document).ready(function(){

    });
</script>