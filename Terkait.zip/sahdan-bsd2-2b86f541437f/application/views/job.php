<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    height: auto !important;
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}

</style>
	<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 post-container">
					<!-- Untuk unggah status -->
                    <div class="card">
						<div class="row card-content" style="min-height:150px">
							<span class="card-title">Daftar Lowongan Pekerjaan</span>
							<form id="formSkill" autocomplete="off" method="post" action="<?php echo base_url('CJob/searchJob');?>" enctype="multipart/form-data">
								<div class="row">
									<div class="col s12">
										<div class="row" style="padding:0px 10px;">
											<div class="input-field col s12">
												<input type="text" id="autocomplete-job" name="edJobName" class="autocomplete">
												<label for="autocomplete-job">Search</label>
												<i style="right:0px;" class="material-icons prefix">search</i>
											</div>
										</div>
									</div>
								</div>
							</form>
							<div class="divider" style="margin:5px 5px 10px 0px"></div>
							<div class="row" id="daftar-lowongan">
								<?php include("ajax/ajaxCompanyJobs.php"); ?>
							</div>
						</div>
					</div>
				</div>
				<div class="preloader-wrapper big active" style="margin-left: -43%; display:none; position: fixed;">
					<div class="spinner-layer spinner-blue-only">
						<div class="circle-clipper left">
							<div class="circle">
							</div>
						</div>
						<div class="gap-patch">
							<div class="circle">
							</div>
						</div>
						<div class="circle-clipper right">
							<div class="circle">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script>
	$(document).ready(function() {
		$('#autocomplete-job').autocomplete({
			limit: 5,
		});
		var timeout = null;
		$('#autocomplete-job').on('keyup', function () {
			var keyword = $(this).val();
			if (timeout !== null) {
				clearTimeout(timeout);
			}
			timeout = setTimeout(function () {
				$.ajax({
					method: "post",
					url: '<?= base_url("CJob/searchJob") ?>',
					data:{
						keyword: keyword,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					$('#daftar-lowongan').html(data);
				});
			}, 1000);
		});


		//untuk deteksi scroll
		window.onscroll = function(ev) {
			
			//kalau sudah sampai dibawah
			if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
				
				//nanti di isi ajax buat post
				
			}
		};
		
	});
	</script>

</body>
</html>