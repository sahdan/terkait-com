<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    <!-- height: auto !important; -->
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}
.cover{
	background: url(<?php echo base_url('assets/images/background.jpg');?>);
	background-size: cover;
	background-repeat: no-repeat;
	min-height:240px;
}

</style>
	<?php include('navbar.php');?>
    <div class="section" style="padding-top:0">
        <div class="cover">
        </div>
    </div>
	<div class="section" style="margin-top:-150px">
		<div class="container" style="width:80%">

			<div class="row" style="margin-top:50px">
                <div class="col s12">
					<div class="card horizontal" style="min-height:150px">
						<div class="card-image">
							<img src="<?php echo base_url('assets/images/company.png');?>">
						</div>
						<div class="card-stacked">
							<div class="card-content">
							<span class="card-title">
								<span style="font-size:2.4rem">Terkait Company Limited</span>
								<a href="#!" class="dropdown-trigger secondary-content" data-target='dropdown1'><i class="material-icons">more_vert</i></a>
							</span>
							<p>Computer Software ~ Surabaya, East Java ~ 18 followers</p>
							</div>
							<div class="card-action" style="border-top:0">
								<a href="#"  class="waves-effect waves-light btn-flat btn-small" style="border:1px solid #1565C0">Ikuti</a>
								<a href="#"  class="waves-effect waves-light blue darken-3 btn-small">lihat pekerjaan</a>
							</div>
						</div>
					</div>
                </div>
            </div>
			<div class="row">
				<div class="col s12 post-container">
					<!-- Untuk unggah status -->
                    <div class="card" style="min-height:150px">
						<div class="card-content">
							<span class="card-title">Tentang</span>
							<P>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</P><br>
							<span class="card-title">Rincian Perusahaan</span><br>
							<P><b>Website</b><br><a href="http://terkait.com">http://terkait.com</a></P><br>
							<P><b>Lokasi Kantor</b><br>Surabaya, East Java</P><br>
							<P><b>Tahun Berdiri</b><br>2018</P><br>
							<P><b>Tipe Perusahaan</b><br>Perusahaan Keluarga</P><br>
							<P><b>Ukuran Perusahaan</b><br>100 - 1000 Pekerja</P><br>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script>
	$(document).ready(function() {
		$('.modal').modal();
		//deklarasi dropify
		$('.dropify').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		
		//ganti text nya dropify
		$('.post .dropify-message p').text("Unggah gambar disini");
		
		//untuk deteksi scroll
		window.onscroll = function(ev) {
			
			//kalau sudah sampai dibawah
			if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
				
				//nanti di isi ajax buat post
				$.ajax({
					method: "post",
					url: '<?= base_url("CPost/ajaxLoadPost") ?>',
					data: {	startPost: startPost,
							// endPost: endPost
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(result) {
					$('.post-container').append(result);
				});
			}
		};
		
		//edit post di klik
		$(document).on('click','.modal-edit',function(){
			var id = $(this).attr("id-post");
			$.ajax({
				method: "post",
				url: '<?= base_url("CHome/ajaxEditPost") ?>',
				data: {	id: id
					},
				beforeSend: function () {
                    $('#modal-edit').html("");
                }
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(result) {
				$('#modal-edit').html(result);
				$('#textarea1').trigger('autoresize');
			});
		})

		//delete post di klik
        $(document).on('click','.modal-delete',function(){
            var id = $(this).attr("id-post");
            $("#modal-delete>.modal-footer>.btn-yes").attr("href","<?php echo base_url('CHome/deletePost/'); ?>"+id)
        });
		$( document ).ajaxStart(function() {
			$( ".preloader-wrapper" ).show();
		});
		
		$(document).ajaxStop(function(){
			$( ".preloader-wrapper" ).hide();
		})
		
	});
	</script>

</body>
</html>