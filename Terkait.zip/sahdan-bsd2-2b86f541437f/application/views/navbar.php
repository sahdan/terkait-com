<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	require('header.php');
	if(!isset($_SESSION["user_id"])){
		// var_dump($_SESSION["user_id"]);
		header("Location: " . base_url('/CLogin/'));
	}
?>
<style> 
	.custom-search:focus{
		border:none!important;
		box-shadow:none!important;
	}
	.bio{
		margin-top:0px;
		height:65px;
		padding-top:5px;
	}
	.bio #nama a{
		text-align:center;
		font-weight:600;
		font-size:24pt;
	}
	nav ul li.active{
		border-bottom:1px solid white;
	}
	.sidenav .collapsible-body>ul:not(.collapsible)>li.active, .sidenav.sidenav-fixed .collapsible-body>ul:not(.collapsible)>li.active {
		background-color: grey;
	}
	@media only screen and (max-width: 992px) {
		#idLogo{
			text-align:left;
		}
	}
	.dropdown-content{
		width:250px;
	}
	#nav-profile{
		height:70px;
	}
	@media only screen and (max-width: 600px){

	}
	
	nav ul a:hover {
	    background-color: rgba(0,0,0,0);
	}

</style>
<body>

	<div class="navbar-fixed">
			
		<nav class="blue darken-4">
			<div class="nav-wrapper container" style="width:80%">
				<a href="<?php echo base_url('CHome'); ?>" id="idLogo" class="left brand-logo hide-on-small-only"><b><span class="blue darken-1" style="padding: 0px 5px;border-radius:5px;margin-left:2px">Ter</span>kait</b></a>
				<a href="<?php echo base_url('CHome'); ?>" id="idLogo" class="brand-logo  hide-on-med-and-up"><b><span class="blue darken-1" style="padding: 0px 5px;border-radius:5px;margin-left:2px">Ter</span>kait</b></a>
				
				<ul class="right hide-on-small-only">
					<form class="custom-search-form" autocomplete="off" style="float:left;">
						<input type="hidden" id="custom-search-status" value="0"/>
						<div class="custom-search-container" style="">
							<div class="custom-search-div input-field" style="display:none;float:left;">
								<input id="custom-search" class="autocomplete" type="text" size="35" style="margin:unset;height:100%;width:90%;background-color:white!important;padding:0 10px;">
							</div>
							<li style="float:right;" class="custom-search-icon"><a><i class="material-icons tooltipped" data-position="bottom" data-tooltip="Cari">search</i></a></li>
						</div>							
					</form>
					<li <?php if($this->uri->segment(1) == 'CHome'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CHome'); ?>" style="height:100%" class='tooltipped' data-position="bottom" data-tooltip="Home">
							<i class="material-icons left">home</i>
						</a>
					</li>
					<li <?php if($this->uri->segment(1) == 'CNetwork'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CNetwork'); ?>" style="height:100%" class='tooltipped' data-position="bottom" data-tooltip="Koneksi">
							<?php if($countRequest > 0){ ?>
								<span class="new badge red" data-badge-caption="" style="margin-top: 25%;margin-left: -25px;min-width: 20px;"><?php if(isset($countRequest))echo $countRequest; ?></span>
							<?php }?>
							<i class="material-icons left">people</i>
						</a>
					</li>
					<li <?php if($this->uri->segment(1) == 'CJob'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CJob'); ?>" style="height:100%" class='tooltipped' data-position="bottom" data-tooltip="Lowongan Kerja">
							<?php if($countJob > 0){ ?>
								<span class="new badge red" data-badge-caption="" style="margin-top: 25%;margin-left: -25px;min-width: 20px;"><?php if(isset($countJob))echo $countJob; ?></span>
							<?php }?>
							<i class="material-icons left">work</i></a></li>
					<li <?php if($this->uri->segment(1) == 'CMessages'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CMessages'); ?>" style="height:100%" class='tooltipped' data-position="bottom" data-tooltip="Pesan">
							<?php if($countMsg > 0){ ?>
								<span class="new badge red" data-badge-caption="" style="margin-top: 25%;margin-left: -25px;min-width: 20px;"><?php if(isset($countMsg))echo $countMsg; ?></span>
							<?php }?>
							<i class="material-icons left">message</i>
						</a>
					</li>
					<li <?php if($this->uri->segment(1) == 'CNotification'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CNotification'); ?>" style="height:100%" class='tooltipped' data-position="bottom" data-tooltip="Notifikasi">
						<?php if($countNotif > 0){ ?>
								<span class="new badge red" data-badge-caption="" style="margin-top: 25%;margin-left: -25px;min-width: 20px;"><?php if(isset($countNotif))echo $countNotif; ?></span>
							<?php }?>
							<i class="material-icons left">notifications</i>
						</a>
					</li>
					
					<li>
						<a style="height:100%;padding-top: 10px;" class="dropdown-trigger" href="#!" data-target="dropdown1">
							<div class="circle" style="height:40px;width:40px;background-color:white;left:calc(50% - 50px)">
							<?php if($user->photo_url != "") { ?>
							<img src="<?php echo $user->photo_url; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:2px">
						<?php } else { ?>
							<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:2px">
						<?php } ?>
							</div>
							<i class="material-icons right" style=" margin-top: -50px; margin-left: 40px;">arrow_drop_down</i>
						</a>
					</li>
				</ul>
			</div>
		</nav>
		<ul id="dropdown1" class="dropdown-content">
			<li id="nav-profile">
				<a style="height:100%" href="<?php echo base_url('CProfile/index/'.$_SESSION["user_id"])?>">
					<div class="circle left" style="height:40px;width:40px;background-color:white;left:calc(50% - 50px)">
						<?php if($user->photo_url != "") { ?>
							<img src="<?php echo $user->photo_url; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:2px">
						<?php } else { ?>
							<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:2px">
						<?php } ?>
					</div>
					<span>
						<?php
						//menampilkan nama
							echo $_SESSION["user_first_name"];
							if ($_SESSION["user_last_name"] != "") {
								echo " " . $_SESSION["user_last_name"];
							}
						?>
						<br><span style="color:gray"><small><?php echo $_SESSION["user_headline"]; ?></small></span>
					</span>
				</a>
			</li>
			<li><a class="waves-effect waves-teal btn-flat" href="<?php echo base_url('CCompany/index/');?>" style="background-color:rgba(0,0,0,0)">Perusahaan</a></li>
			<li class="divider"></li>
			<li><a href="<?php echo base_url('CLogin/logout')?>">Sign Out</a></li>
		</ul>
	</div>
	<div class="navbar-fixed hide-on-med-and-up" style="position: fixed;bottom:0px;z-index: 10;">
		<nav class="blue darken-4">
			<div class="nav-wrapper container" style="width:80%">
				<ul class="right show-on-small" style="margin-right: calc(50% - 125px);">
					<li <?php if($this->uri->segment(1) == 'CHome'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CHome'); ?>" style="height:100%">
							<span class="new badge red" data-badge-caption="" style="margin-top: 25%;margin-left: -25px;min-width: 20px;">99</span>
							<i class="material-icons left">home</i>
						</a>
					</li>
					<li <?php if($this->uri->segment(1) == 'CNetwork'){echo "class='active'";}?>><a href="<?php echo base_url('CNetwork'); ?>"><i class="material-icons">people</i></a></li>
					<li <?php if($this->uri->segment(1) == 'CJob'){echo "class='active'";}?>><a href="<?php echo base_url('CJob'); ?>"><i class="material-icons">work</i></a></li>
					<li <?php if($this->uri->segment(1) == 'CMessages'){echo "class='active'";}?>>
						<a href="<?php echo base_url('CMessages'); ?>" style="height:100%">
							<?php if($countMsg > 0){ ?>
								<span class="new badge red" data-badge-caption="" style="margin-top: 25%;margin-left: -25px;min-width: 20px;"><?php if(isset($countMsg))echo $countMsg; ?></span>
							<?php }?>
							<i class="material-icons left">message</i>
						</a>
					</li>
				</ul>
			</div>
		</nav>
	</div>
	<script async>
		// console.log('');
		$(document).ready(function(){
			$('.tooltipped').tooltip();
			$('.sidenav').sidenav();
			$('.collapsible').collapsible();
			$(".dropdown-trigger").dropdown({
				coverTrigger: false,
				constrainWidth:false,
				alignment:"right"
			});
			$('#custom-search').autocomplete({
				limit: 4,
				onAutocomplete: function(value){
					$url = "<?php echo base_url('CSearch/redirectPage/'); ?>"+value;
					$url = encodeURI($url);
					window.location = $url;
				},
			});

			$('#custom-search').keyup(function(){
				var keyword = $(this).val();
				$.ajax({
					method: "post",
					url: '<?= base_url("CSearch/getSuggestion") ?>',
					data:{
						keyword: keyword
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					// alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					var array = {};
					for(var i=0; i < result[0].length; i++){
						array[result[0][i].suggestion] = null;
					}
					for(var i=0; i < result[1].length; i++){
						array[result[1][i].company_name] = null;
					}
					$('#custom-search').autocomplete('updateData', array);
				});
			});
			$('.custom-search-div').on('mousedown', 'li', function(){
				console.log("li");
				$("#custom-search-status").val("1");
				console.log($("#custom-search-status").val());
			});
			var searchShow = function(){
				$(".custom-search-div").animate({
					opacity: "toggle",
    				width: "toggle"
				}, 500, function(){
					$(".custom-search-icon").off('click');
					$(".custom-search-icon").on('mousedown', searchAction);
					$(".custom-search-container").on('focusout', searchHide);
					$('#custom-search').focus();
				});
			};
			var searchHide = function(){
				var status = $("#custom-search-status").val();
				status -= 1;
				if(status<0){
					$(".custom-search-div").animate({
						opacity: "toggle",
						width: "toggle"
					}, 500, function(){
						$(".custom-search-container").off('focusout');
						$(".custom-search-icon").off('mousedown');
						$(".custom-search-div ul li").off('mousedown');
						$(".custom-search-icon").on('click', searchShow);
					});
				}else{

				}
				$("#custom-search-status").val("0");
			};
			var searchAction = function(){
				$("#custom-search-status").val("1");
				if($('#custom-search').val().length >= 3){
					$url = "<?php echo base_url('CSearch/index/'); ?>"+$('#custom-search').val();
					$url = encodeURI($url);
					window.location = $url;
				}else{
				}
			}
			$(".custom-search-icon").on('click', searchShow);

			$('#custom-search').keypress(function (e) {
				var key = e.which;
				if(key == 13) //enter key
				{
					searchAction();
					return false;  
				}
			}); 
		});
	</script>