<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	require('header.php');
?>
<style>
.highcharts-title tspan{
	font-size:20px;
}
</style>
<body>
	<div class="navbar-fixed">
		<nav class="blue darken-4">
			<div class="nav-wrapper container" style="width:80%">
				<a href="<?php echo base_url('CLogin/admin'); ?>" id="idLogo" class="left brand-logo"><b><span class="blue darken-1" style="padding: 0px 5px;border-radius:5px;margin-left:2px">Ter</span>kait</b></a>
				
				<a class="right" href="<?php echo base_url('CLogin/logout'); ?>"><i class="material-icons">exit_to_app</i></a>
			</div>
		</nav>
	</div>
	<div id="modal-add" class="modal modal-fixed-footer">
		<form class="regis" method="post" action="<?php echo base_url('CAdmin/addAdmin');?>" enctype="multipart/form-data">
			<div class="modal-content">
				<h6>Tambah Admin</h6>
				<div id="form-regis card-content" >
					<div>
						<div class="form-group">
							<div class="input-field col s12">
								<input id="firstName" type="text" name="edFirstName" required oninvalid="this.setCustomValidity('Masukkan Nama Depan Anda')" oninput="setCustomValidity('')">
								<label for="firstName" >Nama Depan *</label>
							</div>
							<div class="input-field col s12">
								<input id="lastName" type="text" name="edLastName">
								<label for="lastName" >Nama Belakang (optional)</label>
							</div>
							<div class="input-field col s12">
								<input id="email" type="text" name="edEmail" required oninvalid="this.setCustomValidity('Masukkan Alamat Email Anda')" oninput="setCustomValidity('')">
								<label for="email" >Email *</label>
							</div>
							<div class="input-field col s12">
								<input id="password" type="password" name="edPassword" required oninvalid="this.setCustomValidity('Masukkan Kata Sandi Anda')" oninput="setCustomValidity('')">
								<label for="password" >Kata Sandi *</label>
							</div>
							<div class="input-field col s12">
								<input id="confPassword" type="password" name="edConfPassword" required oninvalid="this.setCustomValidity('Masukkan Konfirmasi Kata Sandi Anda')" oninput="setCustomValidity('')">
								<label for="confPassword" >Konfirmasi Kata Sandi *</label>
								<div class="validErr" style="display:none">Kata Sandi Tidak Sama</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<a href="#" class="modal-close waves-effect waves-green btn btn-yes red">Batal</a>
				<button class="btn waves-effect waves-light indigo darken-4" type="submit" name="action">Buat
					<i class="material-icons right">send</i>
				</button>
			</div>
		</form>
    </div>
	<div id="container">
		<div style="text-align:center; margin: 5px;">
			<a class="modal-trigger waves-effect waves-light modal-add btn indigo darken-4" href="#modal-add"><i class="material-icons left">add</i>Tambah Admin</a>
			<a class="modal-trigger waves-effect waves-light modal-add btn indigo darken-4" href=""><i class="material-icons left">people</i>List Admin</a>
		</div>
		<div class="row card" style="text-align:center; padding-bottom:2% !important; margin-bottom:1% !important;">
			<h4 style="padding:1% !important; margin-bottom:1% !important;">List Admin</h4>
			<table>
				<thead>
					<tr>
						<th>Nama Depan</th>
						<th>Nama Belakang</th>
						<th>Email</th>
						<th style="text-align:center;">Aksi</th>
					</tr>
				</thead>
	
				<tbody>
					<?php foreach($listAdmin as $item){?>
					<tr>
						<td><?php echo $item->admin_first_name; ?></td>
						<td><?php echo $item->admin_last_name; ?></td>
						<td><?php echo $item->admin_email; ?></td>
						<td style="text-align:center;">
							<?php if($item->admin_id != 1){?>
							<a class="modal-trigger waves-effect waves-light btn modal-edit blue darken-2" admin="<?php echo $item->admin_id; ?>" href="#modal-edit"><i class="material-icons left">edit</i>Edit</a>
							<a href="<?php echo base_url(($item->status == 1 ? "CAdmin/deleteAdmin/" : "CAdmin/recoverAdmin/").$item->admin_id);?>" class="waves-effect waves-light btn <?php echo ($item->status == 1 ? "red" : "green")?>"><i class="material-icons left"><?php echo ($item->status == 1 ? "remove" : "check")?></i><?php echo ($item->status == 1 ? "Non-Aktifkan" : "Aktifkan")?></a>
							<?php }?>
						</td>
					</tr>
					<?php }?>
				</tbody>
			</table>
		</div>
			
		<div id="modal-edit" class="modal modal-fixed-footer">
			
		</div>
	</div>
	<script async>
		$(document).ready(function() {
			
			$('.modal').modal();
			$('.sidenav').sidenav();
			$('.collapsible').collapsible();
			M.updateTextFields();
			$("#confPassword").keyup(function() {
				if($("#password").val() != $("#confPassword").val()){
					$(".validErr").show();
				}
				else{
					$(".validErr").hide();
				}
			});
			
			$(".regis").submit(function(e){
				if($(".validErr").is( ':visible' )){
					e.preventDefault();
				}
			});
			
			xhrPool = [];
			$(document).on('click','.modal-edit',function(){
				var id = $(this).attr("admin");
				$.ajax({
					method: "post",
					url: '<?= base_url("CAdmin/ajaxEdit") ?>',
					data: {	id: id
						},
				beforeSend: function (jqXHR, settings) {
					xhrPool.push(jqXHR);
				}
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(result) {
					$.each(xhrPool, function(idx, jqXHR) {
						  jqXHR.abort();
					});
					$('#modal-edit').html(result);
					M.updateTextFields();
				});
			});
		});
	</script>
</body>
</html>