<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<body>
	<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 m4 l3 ">
					<div class="card">
						<div class="card-image blue darken-4" style="height:90px;">
						</div>
						<div class="circle" style="position:absolute;height:100px;width:100px;background-color:white;top:40px;left:calc(50% - 50px)">
							<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:5px">
						</div>
						<div class="card-content center" style="margin-top:12px">
							<div class="row" style="margin-bottom:10px !important;">
								<h5><b>geraldo Christo</b></h5>
								<p style="color:gray"><small>Seorang Manusia yang sedang bernafas</small></p>
							</div>
							<div class="divider"></div>
							<div class="row" style="margin-bottom:10px !important;">
								<h6 style="color:gray">346</h6>
								<p>Koneksi</p>
							</div>
						</div>	
					</div>
				</div>
				<div class="col s12 m8 l6">
					<div class="card">
						<div class="card-content">
						</div>	
					</div>
					<div class="card">
						<div class="card-content white-text">
							<span class="card-title">Card Title</span>
							<p>I am a very simple card. I am good at containing small bits of information.
							I am convenient because I require little markup to use effectively.</p>
						</div>
						<div class="card-action">
							<a href="#">This is a link</a>
							<a href="#">This is a link</a>
						</div>
					</div>
					<div class="card">
						<div class="card-content white-text">
							<span class="card-title">Card Title</span>
							<p>I am a very simple card. I am good at containing small bits of information.
							I am convenient because I require little markup to use effectively.</p>
						</div>
						<div class="card-action">
							<a href="#">This is a link</a>
							<a href="#">This is a link</a>
						</div>
					</div>
					<div class="card">
						<div class="card-content white-text">
							<span class="card-title">Card Title</span>
							<p>I am a very simple card. I am good at containing small bits of information.
							I am convenient because I require little markup to use effectively.</p>
						</div>
						<div class="card-action">
							<a href="#">This is a link</a>
							<a href="#">This is a link</a>
						</div>
					</div>
				</div>
				<div class="col s12 m12 l3">
					<div class="card">
						<div class="card-content">
						</div>	
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	

</body>
</html>