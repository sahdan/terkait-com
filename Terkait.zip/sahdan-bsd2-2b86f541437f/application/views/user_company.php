<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
</style>
    <?php include('navbar.php');?>
        <div class="section" style="min-height:55%;">
            <div class="container" style="width:80%;">
                <button class="btn blue darken-4 modal-trigger" data-target="modalPerusahaan"><i class="material-icons left">add</i>Perusahaan baru</button>
                <div class="divider" style="margin:10px;"></div>
                <!-- <button class="button"></button> -->
                <div id="container-list-perusahaan">
                    <?php include('ajax/company/list_company.php');?>
                </div>
            </div>
        </div>
    <?php include('footer.php');?>
    <!-- Modal untuk tambah perusahaan -->
    <form id="formPerusahaan" autocomplete="off" method="post" action="<?php echo base_url('CCompany/tambahPerusahaan');?>" enctype="multipart/form-data">
        <div id="modalPerusahaan" class="modal modal-fixed-footer">
            <div id="header-modal-perusahaan" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>TAMBAH PERUSAHAAN</h6>
            </div>

            <div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
                <div class="row">
                    <div class="col s12">
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-perusahaan" name="edNama" class="validate">
                                <label for="textfield-perusahaan">NAMA PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <textarea type="text" id="textfield-deskripsi" name="edDeskripsi" class="materialize-textarea"></textarea>
                                <label for="textfield-deskripsi">DESKRIPSI PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-ukuran" name="edUkuran" class="validate">
                                <label for="textfield-ukuran">UKURAN PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-tipe" name="edTipe" class="validate">
                                <label for="textfield-tipe">TIPE PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="file-field input-field col s12">
                                <div class="btn blue darken-4">
                                    <span>UPLOAD COVER PERUSAHAAN</span>
                                    <input type="file" name="edCover">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="file-field input-field col s12">
                                <div class="btn blue darken-4">
                                    <span>UPLOAD LOGO PERUSAHAAN</span>
                                    <input type="file" name="edLogo">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-website-url" name="edWebsiteURL" class="validate">
                                <label for="textfield-website-url">WEBSITE URL</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s6">
                                <select name="edTahunBerdiri" id="select-tahun-berdiri">
                                    <?php
                                        for( $i= date("Y") ; $i >= 1800 ; $i-- ){
                                            echo '<option value="' . $i . '" >' . $i . '</option>';
                                        }
                                    ?>
                                </select>
                                <label>TAHUN MULAI</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button id="submitTambahPerusahaan" class="modal-close btn blue darken-4" type="submit" name="action">TAMBAHKAN</button>
            </div>
        </div>
    </form>

    <!-- Modal untuk hapus perusahaan -->
    <form id="formHapusPerusahaan" autocomplete="off" method="post" action="<?php echo base_url('CCompany/hapusPerusahaan');?>" enctype="multipart/form-data">
        <div id="modalHapusPerusahaan" class="modal modal-fixed-footer" style="height:200px;">
            <input type="hidden" name="edCompanyId" val=""/>
            <div id="header-modal-hapus-perusahaan" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>HAPUS PERUSAHAAN</h6>
            </div>
            <div id="konfirmasiHapusPerusahaan" class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
                Apakah anda yakin untuk menghapus perusahaan ini?
            </div>
            <div class="modal-footer">
                <button id="submitHapusPerusahaan" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
                <button id="batalHapusPerusahaan" class="modal-close btn blue darken-4" type="button">TIDAK</button>
            </div>
        </div>
    </form>

    <!--  Modal pemberitahuan-->
    <div id="modalPemberitahuan" class="modal modal-fixed-footer" style="height:200px;">
        <div id="header-modal-pemberitahuan" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
            <h6>PEMBERITAHUAN</h6>
        </div>
        <div id="isiPemberitahuan" class="modal-content" style="top:56px; height:calc(100% - 84px);max-height:calc(100% - 84px);">

        </div>
        <div class="modal-footer">
            <button class="modal-close btn blue darken-4" type="button">OK</button>
        </div>
    </div>                          

	<script>
	$(document).ready(function(){
        // inisialisasi class modal
        $('.modal').modal();
        // inisialisasi elemen select
        $('select').formSelect();
        var elem = document.getElementById('select-tahun-berdiri');
        M.FormSelect.init(elem, {dropdownOptions:{container:document.body}});
        //
		M.textareaAutoResize($('#textfield-deskripsi'));
        //
        $('#formPerusahaan').submit(function(event){
			event.preventDefault();
            $.ajax({
                type: "POST",
                url: '<?= base_url("CCompany/tambahPerusahaan")?>',
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
            }).fail(function(jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }).done(function(data) {
                result = JSON.parse(data);
                tambahPerusahaan(result[0]);
                $('#container-list-perusahaan').html(result[1]);
            });
        });

        function tambahPerusahaan(data){
            if(data["status"] == "adaPemilik"){
                var namaPemilik = data["data"]["user_name"];
                var idPemilik = data["data"]["user_id"];
                var url = "<?php echo base_url('CProfile/index/');?>"+idPemilik;
                $('#isiPemberitahuan').html(
                    'Perusahaan dengan nama "'+$('#textfield-perusahaan').val()+'" telah terdaftar dengan super admin : '+
                    '<a href="'+url+'">'+namaPemilik+'</a>'
                );
                $('#modalPemberitahuan').modal('open');
            }else if(data["status"] == "milikSendiri"){
                $('#isiPemberitahuan').html(
                    'Perusahaan dengan nama "'+$('#textfield-perusahaan').val()+'" sebelum ini sudah terdaftar didatabase, dengan anda sebagai admin perusahaan '
                );
                $('#modalPemberitahuan').modal('open');
            }else{
                $('#isiPemberitahuan').html('Perusahaan dengan nama "'+$('#textfield-perusahaan').val()+'" telah berhasil ditambahkan');
                $('#modalPemberitahuan').modal('open');
            }
        }

        $("#container-list-perusahaan").on('click','ul div div a.hapus-perusahaan', function(){
            var companyId = $(this).siblings('input[name="edCompanyId"]').val();
            $('#modalHapusPerusahaan input[name="edCompanyId"]').val(companyId);
        });

        $("#formHapusPerusahaan").submit(function(event){
            event.preventDefault();
            $.ajax({
                type: "POST",
				url: $(this).attr('action'),
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				$('#container-list-perusahaan').html(data);
			});
        });
    })
	</script>

</body>
</html>