<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
    .card-content{
        padding:12px 16px!important;
    }
    .card-title a{
        font-size:18;
    }
</style>
<body>
    <?php include('navbar.php');?>
    <!--  -->
    <div class="section">
        <div class="container" style="width:80%">
            <?php 
            if(!empty($search_result_user)){ ?>
                <h5>Orang</h5>
            <?php }
            $index = 1;
            foreach($search_result_user as $item){ ?>
                <?php if($index % 3 == 1){ ?>
                    <div class="row">
                <?php } ?>
                <div class="col s4">
                    <div class="card">
                        <div class="card-content">
                            <?php if($item->photo_url != ""){?>
                                <img src="<?php echo $item->photo_url; ?>" class="circle responsive-img left profile-image blue darken-2" style="width:45px;height:45px;margin:0 8px 0 0">
                            <?php }else{ ?>
                                <i class="material-icons small left blue-text text-darken-4" style="font-size:48px;">account_circle</i>
                            <?php } ?>
                            <span class="card-title" style="margin:6px 0 14px 0;">
                                <a href='<?php echo base_url('CProfile/index/').$item->user_id;?>'><?php echo $item->user_first_name.' '.$item->user_last_name;?></a>
                            </span>
                            <!-- <p style="height:80px;overflow-y:auto;"> -->
                            <p style="height:35px;overflow-y:hidden;overflow-x:none;">
                                <?php echo $item->headline; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php if($index % 3 == 0){ ?>
                    </div>
                <?php } 
                $index++; ?>
            <?php } ?>
            <?php 
            if(!empty($search_result_company)){ ?>
                <h5>Perusahaan</h5>
            <?php }
            $index = 1;
            foreach($search_result_company as $item){ ?>
                <?php if($index % 3 == 1){ ?>
                    <div class="row">
                <?php } ?>
                <div class="col s4">
                    <div class="card">
                        <div class="card-content">
                            <div>
                                <?php if($item->logo_url != ""){?>
                                    <img src="<?php echo $item->logo_url; ?>" class="circle responsive-img left profile-image blue darken-2" style="width:42px;height:42px;vertical-align:middle;">
                                <?php }else{ ?>
                                    <i class="material-icons small left blue-text text-darken-4" style="font-size:48px;">account_circle</i>
                                <?php } ?>
                                <span class="card-title" style="margin:6px 0 14px 0;">
                                    <a href='<?php echo base_url('CCompany/profil/').$item->company_id;?>'><?php echo $item->company_name;?></a>
                                </span>
                            </div>
                            <!-- <p style="height:80px;overflow-y:auto;"> -->
                            <p style="height:35px;overflow-y:hidden;overflow-x:none;">
                                <?php echo $item->company_description; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php if($index % 3 == 0){ ?>
                    </div>
                <?php } 
                $index++; ?>
            <?php } ?>
            <!-- <div class="row">
                <div class="col s4">
                    <div class="card">
                        <div class="card-content">
                            <i class="material-icons small left blue-text text-darken-4" style="font-size:48px;">account_circle</i>
                            <!-- <img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img left profile-image blue darken-2" style="width:45px;height:45px;margin:0 8px 0 0"> 
                            <span class="card-title" style="margin:6px 0 14px 0;">Col 3</span>
                            <p style="max-height:80px;overflow-y:auto;">Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col s4">
                    <div class="card">
                        <div class="card-content">
                            <i class="material-icons small left blue-text text-darken-4" style="font-size:48px;">account_circle</i>
                            <!-- <img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img left profile-image blue darken-2" style="width:45px;height:45px;margin:0 8px 0 0"> 
                            <span class="card-title" style="margin:6px 0 12px 0;">Col 3</span>
                            <p style="max-height:80px;overflow-y:auto;">Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            Content col 3 abcd efgh ijkl
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col s4">
                    <div class="card">
                        <div class="card-content">
                            <i class="material-icons small left blue-text text-darken-4" style="font-size:48px;">account_circle</i>
                            <!-- <img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img left profile-image blue darken-2" style="width:45px;height:45px;margin:0 8px 0 0"> 
                            <span class="card-title" style="margin:6px 0 12px 0;">Col 3</span>
                            <p style="max-height:80px;overflow-y:auto;">Content col 3 abcd efgh ijkl</p>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    <!--  -->
    <?php include('footer.php');?>
    <script>
        // 

        // 
    </script>
</body>
</html>