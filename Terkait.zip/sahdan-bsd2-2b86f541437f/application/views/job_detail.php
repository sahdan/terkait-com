<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
</style>
<?php include('navbar.php'); ?>
<div class="section">
    <div class="container" style="width:80%">
        <h4>Detail Lowongan</h4>
        <div class="card">
            <div class="row" style="margin-top:20px;">
                <div class="col s12" style="padding:20px;">
                    <input id="job-id" type="hidden" name="edJobId" value="<?php echo $job->job_id;?>">
                    <div class="card horizontal">
                        <div class="card-image" id="logo-perusahaan">
                            <?php if($job->logo_url){ ?>
                                <img id="logo-perusahaan" style="padding:0px;max-width:150px;max-height:150px;" src="<?php echo $job->logo_url;?>">
                            <?php } else {?>
                                <img id="logo-perusahaan" src="<?php echo base_url('assets/images/company.png');?>">
                            <?php }?>
                        </div>
                        <div class="card-stacked">
                            <div class="card-content">
                                <span class="card-title">
                                    <span><b><?php echo $job->company_name;?></b></span>
                                </span>
                                <?php if($job->company_address){?>
                                    <span><?php echo $job->company_address.", ".$job->city.", ".$job->state;?></span>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div id="main-info">
                        <?php include("ajax/job_detail/main_info.php"); ?>
                    </div>
                    <div class="row" id="div-job-apply">
                        <?php if($job->status == 1){ ?>
                            <?php if($job->admin_status == -1){ ?> 
                                <input type="hidden" name="edApplicationStatus" value="<?php echo $job_application["status"];?>"/>
                                <?php if($job_application["status"] == -1){ ?>
                                    <button id="button-apply" class="btn right blue darken-4">APPLY FOR THIS JOB</button>
                                <?php } elseif($job_application["status"] == 1) { ?>
                                    <button id="button-apply" class="btn right blue darken-4" disabled>JOB APPLIED</button>
                                <?php } ?>
                            <?php } else { ?>
                                <button id="edit-job" class="btn right blue darken-4 modal-trigger" data-target="modalPekerjaan"><i class="material-icons left">edit</i>EDIT</button>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <div id="skill-needed">
            <?php include("ajax/job_detail/skill_needed.php"); ?>
        </div>
        <?php if($job->admin_status != -1){ ?> 
            <div id="job-appliers">
                <?php include("ajax/job_detail/job_appliers.php"); ?>
            </div>
        <?php } ?>
    </div>
</div>

<?php if($job->admin_status != -1){ ?> 
    <form id="formPekerjaan" autocomplete="off" method="post" action="<?php echo base_url('CJob/editPekerjaan');?>" enctype="multipart/form-data">
        <div id="modalPekerjaan" class="modal modal-fixed-footer">
            <div id="header-modal-lokasi" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>LOWONGAN PEKERJAAN</h6>
            </div>
            <input type="hidden" name="edCompanyId" value="<?php echo $job->company_id;?>">
            <input type="hidden" name="edLowonganId" value="<?php echo $job->job_id;?>">
            <div class="form-group modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
                <div class="row">
                    <div class="input-field col s12">
                        <input id="industry" type="text" name="edIndustry" required oninvalid="this.setCustomValidity('Masukkan Bidang Pekerjaan')" oninput="setCustomValidity('')">
                        <label for="industry" >Bidang Pekerjaan *</label>
                        <div class="note">
                            Contoh : Accounting/Auditing, Analyst, Information Technology, Advertising, dll
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <select id="jobFunction" name="edJobFunction">
                            <option value="Full-Time">Full-Time</option>
                            <option value="Part-Time">Part-Time</option>
                            <option value="Kontrak">Kontrak</option>
                            <option value="Sementara">Sementara</option>
                            <option value="Relawan">Relawan</option>
                            <option value="Magang">Magang</option>
                        </select>
                        <label for="jobFunction" >Jenis Pekerjaan *</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <input id="employmentType" type="text" name="edEmploymentType">
                        <label for="employmentType" >Tipe Pekerjaan *</label>
                        <div class="note">
                            Contoh : Government, Hospitality, Airlines, Accounting, dll
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <select id="seniorityLevel" name="edSeniorityLevel">
                            <option value="Internship">Internship</option>
                            <option value="Entry Level">Entry Level</option>
                            <option value="Associate">Associate</option>
                            <option value="Mid-Senior Level">Mid-Senior Level</option>
                            <option value="Director">Director</option>
                            <option value="Executive">Executive</option>
                        </select>
                        <label for="seniorityLevel" >Tingkat Senioritas *</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s6">
                        <input id="picker-created-at" name="edCreated" class="datepicker" type="text" disabled="disabled">
                        <label for="picker-created-at">Tanggal Lowongan Dibuka</label>
                    </div>
                    <div class="input-field col s6">
                        <input id="picker-expired-at" name="edExpired" class="datepicker" type="text">
                        <label for="picker-expired-at">Tanggal Lowongan Ditutup</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s6">
                        <input id="minSalary" name="edMinSalary" min=0 step="1000" type="number">
                        <label for="minSalary">Gaji Minimum</label>
                    </div>
                    <div class="input-field col s6">
                        <input id="maxSalary" name="edMaxSalary" min=0 step="1000" type="number">
                        <label for="maxSalary">Gaji Maksimum</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <label for="description" >Deskripsi Pekerjaan</label>
                        <textarea id="description" name='edDescription' class="materialize-textarea" placeholder="Masukkan Deskripsi Pekerjaan..." style="margin-top: 10px;"></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s10">
                        <input type="text" id="autocomplete-skill" name="edSkill" class="autocomplete">
                        <label for="autocomplete-skill">Keterampilan</label>
                    </div>
                    <button id="button-tambah-skill" class="btn-small right blue darken-4" style="margin:20px 10px 0px 0px;" type="button"><i class="material-icons left">add</i>Add</button>
                </div>
                <div class="row">
                    <div class="col s12" id="daftar-skill">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="submit-edit-pekerjaan" style="display:none;" class="modal-close btn blue darken-4" type="submit" name="action">EDIT LOWONGAN</button>
                <button id="hapus-pekerjaan" style="display:none;" class="modal-close btn blue darken-4" type="button">HAPUS LOWONGAN</button>
            </div>
        </div>
    </form>

    <!-- konfirmasi hapus pekerjaan -->
    <form id="formHapusPekerjaan" autocomplete="off" method="post" action="<?php echo base_url('CJob/hapusPekerjaan');?>" enctype="multipart/form-data">
        <div id="modalHapusPekerjaan" class="modal modal-fixed-footer" style="height:200px;">
            <input type="hidden" name="edCompanyId" value="<?php echo $job->company_id?>">
            <input type="hidden" name="edLowonganId" value=""/>
            <div class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>HAPUS LOWONGAN PEKERJAAN</h6>
            </div>
            <div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
                Apakah anda yakin untuk menghapus lowongan pekerjaan ini?
            </div>
            <div class="modal-footer">
                <button id="submit-hapus-pekerjaan" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
                <button id="batal-hapus-pekerjaan" class="modal-close btn blue darken-4" type="button">TIDAK</button>
            </div>
        </div>
    </form>

<?php } ?>

<?php include('footer.php'); ?>
<script>
    $(document).ready(function(){
        <?php if($job->admin_status != -1){ ?> 
            //select
            $('select').formSelect();
            var elem = document.getElementsByTagName('select'), i;
            for(i in elem){
                M.FormSelect.init(elem[i], {dropdownOptions:{container:document.body}});
            }
            //modal
            $('.modal').modal();
            //text area
            M.textareaAutoResize($('.materialize-textarea'));
            $('.datepicker').datepicker({
                // mengatur elemen sebagai parent dari date picker
                container: 'body',
                // mengatur format penulisan datepicker diinputfield
                format: 'yyyy-mm-dd'
            });
            //datepicker
            var dt = new Date();
            var now = dt.getFullYear() + "-" + (dt.getMonth()+1) + "-" + dt.getDate();
            $('#picker-created-at').datepicker({
                container: 'body',
                format: 'yyyy-mm-dd',
                defaultDate: new Date(now),
                setDefaultDate: true,
            });
            //deklarasi autocomplete
            $('#autocomplete-skill').autocomplete({
                limit: 3,
            });
            $('.autocomplete-content').appendTo(document.body);
            //

            $('#edit-job').click(function(){
                var jobId = $('#job-id').val();
                $.ajax({
                    method: "post",
                    url: '<?= base_url("CJob/dataPekerjaan") ?>',
                    data: {
                        jobId : jobId
                    },
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }).done(function(data) {
                    // console.log(data);
                    var result = JSON.parse(data);
                    // console.log(result);
                    $('input[name="edCompanyId"]').val(result[0].company_id);
                    $('input[name="edLowonganId"]').val(result[0].job_id);
                    $('#modalPekerjaan #industry').val(result[0].industry);
                    $('#modalPekerjaan #employmentType').val(result[0].employment_type);
                    $('#modalPekerjaan #minSalary').val(result[0].min_gaji);
                    $('#modalPekerjaan #maxSalary').val(result[0].max_gaji);
                    $('#modalPekerjaan #description').val(result[0].job_description);
                    $('#modalPekerjaan #jobFunction').val(result[0].job_functions);
                    $('#modalPekerjaan #jobFunction').siblings('input.select-dropdown').val(result[0].job_functions);
                    $('#modalPekerjaan #seniorityLevel').val(result[0].seniority_level);
                    $('#modalPekerjaan #seniorityLevel').siblings('input.select-dropdown').val(result[0].seniority_level);
                    var expired_at = new Date(result[0].expired_at);
                    $('#picker-expired-at').datepicker({
                        container: 'body',
                        format: 'yyyy-mm-dd',
                        defaultDate: expired_at,
                        setDefaultDate: true,
                    });
                    M.textareaAutoResize($('#modalPekerjaan #description'));
                    M.updateTextFields();
                    $('#hapus-pekerjaan').show();
                    $('#submit-edit-pekerjaan').show();
                    $('#submit-tambah-pekerjaan').hide();
                    if(result[1].length > 0){
                        $('#daftar-skill').html('<h6>Daftar keterampilan yang dibutuhkan : </h6>');
                        for(var i = 0; i < result[1].length; i++){
                            var skill = 
                            "<span>"+
                            "<input type='hidden' name='edSkill[]' value='"+result[1][i].skill_name+"' />"+
                            "<span class='card-panel skill-name' style='padding:6px 12px;margin:10px 5px;display:inline-block;background-color: #0D47A1 !important;color:white;'>"+result[1][i].skill_name+
                            "<button style='margin-left:10px;width:20px;height:20px;background-color: #0D47A1 !important;' class='btn-small btn-flat btn-floating white btn-no-hover remove-skill'>"+
                            "<i class='material-icons' style='font-size:1.2rem;color:white;line-height:3px;'>clear</i>"+
                            "</button>"+
                            "</span>"+
                            "</span>";
                            $('#daftar-skill').append(skill);
                        }
                    }
                });
            });

            $('#formPekerjaan').submit(function(event){
                event.preventDefault();
                $.ajax({
                    type: "POST",
                    url: $(this).attr('action'),
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    cache: false,
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }).done(function(data) {
                    var result = JSON.parse(data);
                    $('#main-info').html(result[0]);
                    $('#skill-needed').html(result[1]);
                    $('#job-appliers').html(result[2]);
                });
            });

            $('#hapus-pekerjaan').click(function(){
                var jobId = $('#modalPekerjaan input[name="edLowonganId"]').val();
                $('#modalHapusPekerjaan input[name="edLowonganId"]').val(jobId);
                $('#modalHapusPekerjaan').modal('open');
            });

            $('#batal-hapus-pekerjaan').click(function(){
                $('#modalPekerjaan').modal('open');
            });

            $('#formHapusPekerjaan').submit(function(event){
                event.preventDefault();
                $.ajax({
                    type: "POST",
                    url: $('#formHapusPekerjaan').attr('action'),
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    cache: false,
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }).done(function(data) {
                    var result = JSON.parse(data);
                    $('#main-info').html(result[0]);
                    $('#skill-needed').html(result[1]);
                    $('#job-appliers').html(result[2]);
                });
            });

            //mendapatkan hasil sugestion untuk autocomplete-skill saat user melepas key(keyup)
            $('#autocomplete-skill').keypress(function(){
                var skillName = $(this).val().trim();
                // console.log(skillName);
                $.ajax({
                    method: "post",
                    url: '<?= base_url("CCompany/getSkill") ?>',
                    data:{
                        skillName: skillName
                        },
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }).done(function(data) {
                    var result = JSON.parse(data);
                    var array = {};
                    for(var i=0; i < result.length; i++){
                        array[result[i].skill_name] = null;
                    }
                    $('#autocomplete-skill').autocomplete('updateData', array);
                });
            });

            $('#button-tambah-skill').click(function(){
                var skillName = $('#autocomplete-skill').val().trim();
                if(skillName.length >= 3){
                    if(!($('#daftar-skill > h6')).length){
                        $('#daftar-skill').append('<h6>Daftar keterampilan yang dibutuhkan : </h6>');	
                    }
                    // console.log(skillName);
                    var skill = 
                    "<span>"+
                    "<input type='hidden' name='edSkill[]' value='"+skillName+"' />"+
                    "<span class='card-panel skill-name' style='padding:6px 12px;margin:10px 5px;display:inline-block;background-color: #0D47A1 !important;color:white;'>"+skillName+
                    "<button style='margin-left:10px;width:20px;height:20px;background-color: #0D47A1 !important;' class='btn-small btn-flat btn-floating white btn-no-hover remove-skill'>"+
                    "<i class='material-icons' style='font-size:1.2rem;color:white;line-height:3px;'>clear</i>"+
                    "</button>"+
                    "</span>"+
                    "</span>";
                    // var skillButton = "<button class='btn-small blue darken-4'>"+skillName+"</button>";
                    $('#daftar-skill').append(skill);
                }else{
                }
            });

            $('#daftar-skill').on('click', 'span span button.remove-skill', function(){
                $(this).parent().parent().remove();
                if(!($('#daftar-skill > span')).length){
                    $('#daftar-skill > h6').remove();
                }
            });
        <?php } ?>

        $('#button-apply').click(function(){
            var jobId = $('#job-id').val();
            var companyId = <?php echo $job->company_id; ?>;
            var status = $('#div-job-apply input[name="edApplicationStatus"]').val();
			$.ajax({
				method: "post",
				url: '<?= base_url("CJob/lamarPekerjaan") ?>',
				data: {
					jobId : jobId,
                    companyId : companyId,
                    status: status,
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
                if(data == "success"){
                    $('#button-apply').html('JOB APPLIED');
                    $('#button-apply').prop('disabled', true);
                    $('#div-job-apply input[name="edApplicationStatus"]').val("1");
                }
            });
        });

    });
</script>