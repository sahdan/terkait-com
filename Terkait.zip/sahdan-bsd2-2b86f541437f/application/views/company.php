<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	/* border: 1px solid #e0e0e0 !important; */
	/* padding: 3% !important; */
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.divider{
	background-color:#b3b3b3 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}
.cover{
	background-size: cover;
	background-repeat: no-repeat;
	min-height:360px;
}
.btn-no-hover{
	background-color:transparent !important;
	cursor:default !important,
	:hover{-webkit-box-shadow:none;box-shadow:none};
}
.tabs .indicator{
	background-color: #0D47A1 !important;
}
.tabs .tab a{
	color: rgba(13,71,161,0.7) !important;
}
.tabs .tab a:hover, .tabs .tab a.active{
	color: #0D47A1 !important;
}
.tabs .tab a:focus, .tabs .tab a:focus.active {
    background-color: rgba(13,71,161,0.2) !important;
}
</style>
	<?php include('navbar.php');?>
	<style>
		
		.modal.modal-fixed-footer {
			height: 100% !important;
		}
	</style>
    <div id="cover-perusahaan" class="section" style="padding-top:0">
	<?php if($company->cover_url) {?>
        <div class="cover" style="background: url(<?php echo $company->cover_url;?>);background-size: cover;background-repeat: no-repeat;min-height:360px;">
        </div>
	<?php } ?>
    </div>
	<div id="section-perusahaan" class="section" style="<?php if($company->cover_url){?>margin-top:-250px<?php }else{?>margin-top:50px<?php }?>">
		<div class="container" style="width:80%">

			<div class="row" style="margin-top:50px">
                <div class="col s12">
					<div class="card horizontal" style="min-height:150px">
						<div class="card-image" id="logo-perusahaan">
							<?php if($company->logo_url){ ?>
								<img id="logo-perusahaan" style="padding:20px;max-width:240px;max-height:240px;" src="<?php echo $company->logo_url;?>">
							<?php } else {?>
								<img id="logo-perusahaan" src="<?php echo base_url('assets/images/company.png');?>">
							<?php }?>
						</div>
						<div class="card-stacked">
							<div class="card-content">
							<span class="card-title">
								<span id="nama-perusahaan" style="font-size:2.4rem"><?php echo $company->company_name;?></span>
								<!-- <a href="#!" class="dropdown-trigger secondary-content" data-target='dropdown1'><i class="material-icons">more_vert</i></a> -->
								<?php if($user_company["status"] != -1){ ?>
								<button id="edit-perusahaan" class="btn-flat btn-floating modal-trigger right btn-no-hover" data-target="modalPerusahaan">
									<i style="color:blue;" class="material-icons">edit</i>
								</button>
								<?php } ?>
							</span>
							<p>
							<!-- <span><?php echo $company->company_type;?> ~ </span> -->
							<?php if($company_locations){ 
								echo  "<span id='kota'>".$company_locations[0]->city."</span>, <span id='provinsi'>".$company_locations[0]->state."</span> ~ ";
							} ?> 
							<span id="follow-count"><?php echo $followCount; ?> followers</span>
							</p>
							</div>
							<div class="card-action" style="border-top:0">
								<!-- <a href="#"  class="waves-effect waves-light btn-flat btn-small" style="border:1px solid #1565C0">Ikuti</a> -->
								<?php if($follow_status == 0) { ?>
									<input type="hidden" name="edFollowStatus" value="0"/>
									<button id="button-follow" style="font-size:11px;padding:0px 8px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										FOLLOW
									</button>
								<?php } else {?>
									<input type="hidden" name="edFollowStatus" value="1"/>
									<button id="button-follow" style="font-size:11px;padding:0px 8px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										UNFOLLOW
									</button>
								<?php } ?>
							</div>
						</div>
					</div>
                </div>
            </div>

			<?php if($company->status == 1){?>
			<!--  -->
			<div class="row">
				<div class="col s12">
					<ul class="tabs">
						<?php if($user_company["status"] != -1){ ?>
							<li class="tab col s2"><a class="active" href="#tab-profil">Profil</a></li>
							<li class="tab col s2"><a href="#tab-dashboard">Dashboard</a></li>
							<li class="tab col s2"><a href="#tab-lowongan">Lowongan</a></li>
							<li class="tab col s2"><a href="#tab-lokasi">Lokasi</a></li>
							<li class="tab col s2"><a href="#tab-admin">Admin</a></li>
							<li class="tab col s2"><a href="#tab-report">Report</a></li>
						<?php } else { ?>
							<li class="tab col s3"><a class="active" href="#tab-profil">Profil</a></li>
							<li class="tab col s3"><a href="#tab-dashboard">Dashboard</a></li>
							<li class="tab col s3"><a href="#tab-lowongan">Lowongan</a></li>
							<li class="tab col s3"><a href="#tab-lokasi">Lokasi</a></li>
						<?php } ?>
					</ul>
				</div>
				<div class="col s12 post-container">
                    <div id="tab-profil" class="card" style="min-height:150px;">
						<div class="card-content">
							<span class="card-title"><b>Deskripsi Perusahaan</b></span>
							<P id="deskripsi-perusahaan"><?php echo nl2br($company->company_description); ?></P><br>
							<P><b>Website</b><br><a id="website-url-perusahaan" href="<?php echo $company->website_url;?>"><?php echo $company->website_url;?></a></P><br>
							<P><b>Tahun Berdiri</b><br><span id="tahun-berdiri-perusahaan"><?php echo $company->year_founded;?></span></P><br>
							<P><b>Tipe Perusahaan</b><br><span id="tipe-perusahaan"><?php echo $company->company_type;?></span></P><br>
							<P><b>Ukuran Perusahaan</b><br>&plusmn<span id="ukuran-perusahaan"><?php echo $company->company_size;?> Pekerja</span></P><br>
						</div>
					</div>
					<div id="tab-dashboard" class="card" style="min-height:150px;">
						<?php include('feedCompany.php');?>
					</div>
					<div id="tab-lowongan" class="card" >
						<div class="card-content">
							<div>
								<span style="font-size:36px;">Lowongan Pekerjaan</span>
								<button id="tambah-pekerjaan" class="btn blue darken-4 modal-trigger right" data-target="modalPekerjaan"><i class="material-icons left">add</i>Lowongan Baru</button>
							</div>
							<div class="divider" style="margin:5px 5px 10px 0px"></div>
							<div class="row" id="daftar-lowongan">
								<?php include("ajax/ajaxCompanyJobs.php"); ?>
							</div>
						</div>
					</div>
					<div id="tab-lokasi" class="card" style="min-height:150px">
						<div class="card-content" style="margin-left:10px;">
							<div>
								<span style="font-size:36px;">Daftar Lokasi</span>
								<?php if($user_company["status"] != -1){ ?>
									<button id="tambah-lokasi" class="btn blue darken-4 modal-trigger tambah-lokasi right" data-target="modalLokasi"><i class="material-icons left">add</i>Lokasi Baru</button>
								<?php } ?>
							</div>
							<div class="divider" style="margin:5px;"></div>
							<div id="daftar-lokasi-perusahaan">
							<?php if($company_locations) { ?>
								<?php $kantor_pusat = 1; ?>
								<?php $header_cabang = 1; ?>
								<?php foreach($company_locations as $item) {?>
									<?php if($kantor_pusat == 1){ ?>
										<div style="font-size:24px;">Kantor Pusat</div>
										<div class="divider" style="margin:5px;"></div>
										<div id="div-kantor-pusat">
											<div style="min-height:62px;">
												<?php if($user_company["status"] != -1){ ?>
													<input class="id-lokasi" type="hidden" name="edLocationId" value="<?php echo $item->company_location_id; ?>"/>
													<button style="float:right; margin-top:3px; color: #0D47A1; background-color:transparent !important;" data-target="modalLokasi" class="btn-flat modal-trigger right edit-lokasi">
														<i class="material-icons">edit</i>
													</button>
												<?php } ?>
												<div><?php echo $item->company_address; ?></div>
												<div><?php echo $item->city.', '.$item->state; ?></div>
												<div>Kode Pos : <?php echo $item->zip_code2; ?></div>
												<?php if($item->building_name){ ?> 
													<div>Nama Bangunan : <?php echo $item->building_name; ?></div>
												<?php } ?>
												<?php if($item->suite_apt){ ?> 
													<div>Apartemen : <?php echo $item->suite_apt; ?></div>
												<?php } ?>
											</div>
											<div class="divider" style="margin:5px;"></div>
										</div>
										<?php $kantor_pusat = 0; ?>
									<?php } else { ?>
										<?php if($header_cabang == 1){ ?>
											<div id="header-cabang">
												<div style="font-size:24px;">Cabang</div>
												<div class="divider" style="margin:5px;"></div>
												<?php $header_cabang = 0;?>
											</div>
										<?php } ?>
										<div>
											<div style="min-height:62px;">
												<input class="id-lokasi" type="hidden" name="edLocationId" value="<?php echo $item->company_location_id; ?>"/>
												<button style="float:right; margin-top:3px; color: #0D47A1; background-color:transparent !important;" data-target="modalLokasi" class="btn-flat modal-trigger right edit-lokasi">
													<i class="material-icons">edit</i>
												</button>
												<div><?php echo $item->company_address; ?></div>
												<div><?php echo $item->city.', '.$item->state; ?></div>
												<div>Kode Pos : <?php echo $item->zip_code2; ?></div>
												<?php if($item->building_name){ ?> 
													<div>Nama Bangunan : <?php echo $item->building_name; ?></div>
												<?php } ?>
												<?php if($item->suite_apt){ ?> 
													<div>Apartemen : <?php echo $item->suite_apt; ?></div>
												<?php } ?>
											</div>
										</div>
										<div class="divider" style="margin:5px;"></div>
									<?php } ?>
								<?php }	?>
							<?php } else {?>
								<div class="row col s12">
									<P>Lokasi perusahaan belum didaftarkan.</P>
								</div>
							<?php } ?>
							</div>
						</div>
					</div>
					<?php if($user_company["status"] == 1){ ?>
						<div id="tab-admin" class="card">
							<div class="card-content">
								<div>
									<span style="font-size:36px;">Daftar Admin</span>
									<button class="btn blue darken-4 modal-trigger right" data-target="modalAdmin"><i class="material-icons left">add</i>Admin Baru</button>
								</div>
								<div id="daftar-admin">
									<?php include("ajax/company/admin_company.php"); ?>
								</div>
							</div>
						</div>
						<div id="tab-report" class="card" >
							<div class="card-content">
								<div>
									<span style="font-size:36px;">Report Perusahaan</span>
									<div class="row card" style="text-align: center">
										<p>Jumlah Pengunjung</p>
										<h6 id="jumlah-pengunjung" style="color:gray"><?php echo $ctr_visit?></h6>
									</div>
									<div class="row">
										<?php if(count($reportJobs) > 0){ ?>
											<div id="chartJobs" class="col s12 m6 l6 card" style="height:420px;"></div>
										<?php }else{ ?>
											<h5>Tidak ada data lowongan pekerjaan</h5>
										<?php } ?>
										<?php if(count($reportApplier) > 0){ ?>
											<div id="chartApplier" class="col s12 m6 l6 card" style="height:420px;"></div>
										<?php }else{ ?>
											<h5>Tidak ada data pelamar pekerjaan</h5>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
					<?php } ?>
				</div>
			</div>
			<!--  -->
			<?php } ?>
		</div>
	</div>
	
	<?php if($user_company["status"] != -1){ ?>
	<!-- Modal untuk edit perusahaan -->
    <form id="formPerusahaan" autocomplete="off" method="post" action="<?php echo base_url('CCompany/editPerusahaan');?>" enctype="multipart/form-data">
        <div id="modalPerusahaan" class="modal modal-fixed-footer">
            <div id="header-modal-perusahaan" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>EDIT PERUSAHAAN</h6>
            </div>
			<input type="hidden" name="edId" value="<?php echo $company->company_id;?>">
            <div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
                <div class="row">
                    <div class="col s12">
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-nama" name="edNama" class="validate">
                                <label for="textfield-nama">NAMA PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
								<textarea type="text" id="textfield-deskripsi" name="edDeskripsi" class="materialize-textarea"></textarea>
                                <label for="textfield-deskripsi">DESKRIPSI PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-ukuran" name="edUkuran" class="validate">
                                <label for="textfield-ukuran">UKURAN PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-tipe" name="edTipe" class="validate">
                                <label for="textfield-tipe">TIPE PERUSAHAAN</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="file-field input-field col s12">
                                <div class="btn blue darken-4">
                                    <span>UPLOAD COVER PERUSAHAAN</span>
                                    <input type="file" name="edCover">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="file-field input-field col s12">
                                <div class="btn blue darken-4">
                                    <span>UPLOAD LOGO PERUSAHAAN</span>
                                    <input type="file" name="edLogo">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-website-url" name="edWebsiteURL" class="validate">
                                <label for="textfield-website-url">WEBSITE URL</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s6">
                                <select name="edTahunBerdiri" id="select-tahun-berdiri">
                                    <?php
                                        for( $i= date("Y") ; $i >= 1800 ; $i-- ){
                                            echo '<option value="' . $i . '" >' . $i . '</option>';
                                        }
                                    ?>
                                </select>
                                <label>TAHUN MULAI</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="submit-edit-perusahaan" class="modal-close btn blue darken-4" type="submit" name="action">EDIT</button>
            </div>
        </div>
    </form>

	<!-- Modal lokasi -->
	<form id="formLokasi" autocomplete="off" method="post" action="<?php echo base_url('CCompany/tambahLokasi');?>" enctype="multipart/form-data">
        <div id="modalLokasi" class="modal modal-fixed-footer">
            <div id="header-modal-lokasi" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>LOKASI PERUSAHAAN</h6>
            </div>
			<input type="hidden" name="edCompanyId" value="<?php echo $company->company_id?>">
			<input id="input-company-location-id" type="hidden" name="edLocationId" value="">
            <div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
                <div class="row">
                    <div class="col s12">
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-alamat" name="edAlamat" class="validate">
                                <label for="textfield-alamat">ALAMAT</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
								<input type="text" id="textfield-apartemen" name="edApartemen" class="validate">
                                <label for="textfield-apartemen">APARTEMEN</label>
                            </div>
                        </div>
						<div class="row">
                            <div class="input-field col s6">
                                <select name="edProvinsi" id="select-provinsi">
									<option value="" disabled selected>Pilih Provinsi</option>;
                                    <?php
                                        foreach($province as $item){
                                            echo '<option value="' . $item->province_name . '" >' . $item->province_name . '</option>';
                                        }
                                    ?>
                                </select>
                                <label>PROVINSI</label>
                            </div>
                            <div class="input-field col s6">
                                <select name="edKota" id="select-kota" disabled>
									<option value="" disabled selected>Pilih Kota</option>
                                </select>
                                <label>KOTA</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-kode-pos" name="edKodePos" class="validate">
                                <label for="textfield-kode-pos">KODE POS</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input type="text" id="textfield-nama-bangunan" name="edNamaBangunan" class="validate">
                                <label for="textfield-nama-bangunan">NAMA BANGUNAN</label>
                            </div>
                        </div>
						<div class="row">
                            <div class="input-field col s12">
								<label>
									<?php if($company_locations){ ?>
									<input id="checkbox-kantor-pusat" name="edKantorPusat" type="checkbox" class="filled-in">
									<?php } else { ?>
									<input id="checkbox-kantor-pusat" name="edKantorPusat" checked="checked" type="checkbox" class="filled-in" disabled="disabled">
									<?php } ?>
									<span>KANTOR PUSAT</span>
								</label>
								<br/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="submit-tambah-lokasi" class="modal-close btn blue darken-4" type="submit" name="action">TAMBAH</button>
				<button id="submit-edit-lokasi" style="display:none;" class="modal-close btn blue darken-4" type="submit" name="action">EDIT</button>
				<button id="hapus-lokasi" style="display:none;" class="modal-close btn blue darken-4" type="button">HAPUS</button>
            </div>
        </div>
    </form>

	<!-- Modal pekerjaan-->
	<form id="formPekerjaan" autocomplete="off" method="post" action="<?php echo base_url('CCompany/tambahPekerjaan');?>" enctype="multipart/form-data">
	<div id="modalPekerjaan" class="modal modal-fixed-footer">
            <div id="header-modal-lokasi" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
                <h6>LOWONGAN PEKERJAAN</h6>
            </div>
			<input type="hidden" name="edCompanyId" value="<?php echo $company->company_id?>">
			<input type="hidden" name="edLowonganId" value="">
			<div class="form-group modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
				<div class="row">
					<div class="input-field col s12">
						<input id="industry" type="text" name="edIndustry" required oninvalid="this.setCustomValidity('Masukkan Bidang Pekerjaan')" oninput="setCustomValidity('')">
						<label for="industry" >Bidang Pekerjaan *</label>
						<div class="note">
							Contoh : Accounting/Auditing, Analyst, Information Technology, Advertising, dll
						</div>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<select id="jobFunction" name="edJobFunction">
							<option value="Full-Time">Full-Time</option>
							<option value="Part-Time">Part-Time</option>
							<option value="Kontrak">Kontrak</option>
							<option value="Sementara">Sementara</option>
							<option value="Relawan">Relawan</option>
							<option value="Magang">Magang</option>
						</select>
						<label for="jobFunction" >Jenis Pekerjaan *</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<input id="employmentType" type="text" name="edEmploymentType">
						<label for="employmentType" >Tipe Pekerjaan *</label>
						<div class="note">
							Contoh : Government, Hospitality, Airlines, Accounting, dll
						</div>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<select id="seniorityLevel" name="edSeniorityLevel">
							<option value="Internship">Internship</option>
							<option value="Entry Level">Entry Level</option>
							<option value="Associate">Associate</option>
							<option value="Mid-Senior Level">Mid-Senior Level</option>
							<option value="Director">Director</option>
							<option value="Executive">Executive</option>
						</select>
						<label for="seniorityLevel" >Tingkat Senioritas *</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s6">
						<input id="picker-created-at" name="edCreated" class="datepicker" type="text">
						<label for="picker-created-at">Tanggal Lowongan Dibuka</label>
					</div>
					<div class="input-field col s6">
						<input id="picker-expired-at" name="edExpired" class="datepicker" type="text">
						<label for="picker-expired-at">Tanggal Lowongan Ditutup</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s6">
						<input id="minSalary" name="edMinSalary" min=0 step="1000" type="number">
						<label for="minSalary">Gaji Minimum</label>
					</div>
					<div class="input-field col s6">
						<input id="maxSalary" name="edMaxSalary" min=0 step="1000" type="number">
						<label for="maxSalary">Gaji Maksimum</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<label for="description" >Deskripsi Pekerjaan</label>
						<textarea id="description" name='edDescription' class="materialize-textarea" placeholder="Masukkan Deskripsi Pekerjaan..." style="margin-top: 10px;"></textarea>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s10">
						<input type="text" id="autocomplete-skill" name="edSkill" class="autocomplete">
						<label for="autocomplete-skill">Keterampilan</label>
					</div>
					<button id="button-tambah-skill" class="btn-small right blue darken-4" style="margin:20px 10px 0px 0px;" type="button"><i class="material-icons left">add</i>Add</button>
				</div>
				<div class="row">
					<div class="col s12" id="daftar-skill">
					</div>
				</div>
			</div>
            <div class="modal-footer">
                <button id="submit-tambah-pekerjaan" class="modal-close btn blue darken-4" type="submit" name="action">TAMBAH LOWONGAN</button>
				<button id="submit-edit-pekerjaan" style="display:none;" class="modal-close btn blue darken-4" type="submit" name="action">EDIT LOWONGAN</button>
				<button id="hapus-pekerjaan" style="display:none;" class="modal-close btn blue darken-4" type="button">HAPUS LOWONGAN</button>
            </div>
        </div>
	</form>

	<!-- form tambah admin -->
	<form id="formAdmin" autocomplete="off" method="post" action="<?php echo base_url('CCompany/tambahAdmin');?>" enctype="multipart/form-data">
		<div id="modalAdmin" class="modal modal-fixed-footer">
			<input type="hidden" name="edCompanyId" value="<?php echo $company->company_id?>">
			<div class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
				<h6>TAMBAH ADMIN PERUSAHAAN</h6>
			</div>
			<div class="modal-content" style="top:56px; height:calc(100% - 112px);min-height:calc(100%-112px);">
				<?php include('ajax/company/modal_admin_company.php'); ?>
			</div>
			<div class="modal-footer">
				<button class="modal-close btn blue darken-4" type="button">OK</button>
			</div>
		</div>
	</form>

	<!-- konfirmasi hapus lokasi -->
	<form id="formHapusLokasi" autocomplete="off" method="post" action="<?php echo base_url('CCompany/hapusLokasi');?>" enctype="multipart/form-data">
		<div id="modalHapusLokasi" class="modal modal-fixed-footer" style="height:200px;">
			<input type="hidden" name="edCompanyId" value="<?php echo $company->company_id?>">
			<input id="input-company-location-id-hapus" type="hidden" name="edLocationId" val=""/>
			<div class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
				<h6>HAPUS LOKASI</h6>
			</div>
			<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
				Apakah anda yakin untuk menghapus lokasi ini?
			</div>
			<div class="modal-footer">
				<button id="submit-hapus-lokasi" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
				<button id="batal-hapus-lokasi" class="modal-close btn blue darken-4" type="button">TIDAK</button>
			</div>
		</div>
	</form>

	<!-- konfirmasi hapus pekerjaan -->
	<form id="formHapusPekerjaan" autocomplete="off" method="post" action="<?php echo base_url('CCompany/hapusPekerjaan');?>" enctype="multipart/form-data">
		<div id="modalHapusPekerjaan" class="modal modal-fixed-footer" style="height:200px;">
			<input type="hidden" name="edCompanyId" value="<?php echo $company->company_id?>">
			<input type="hidden" name="edLowonganId" value=""/>
			<div class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
				<h6>HAPUS LOWONGAN PEKERJAAN</h6>
			</div>
			<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
				Apakah anda yakin untuk menghapus lowongan pekerjaan ini?
			</div>
			<div class="modal-footer">
				<button id="submit-hapus-pekerjaan" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
				<button id="batal-hapus-pekerjaan" class="modal-close btn blue darken-4" type="button">TIDAK</button>
			</div>
		</div>
	</form>

	<!-- konfirmasi hapus admin -->
	<form id="formHapusAdmin" autocomplete="off" method="post" action="<?php echo base_url('CCompany/hapusAdmin');?>" enctype="multipart/form-data">
		<div id="modalHapusAdmin" class="modal modal-fixed-footer" style="height:200px;">
			<input type="hidden" name="edCompanyId" value="<?php echo $company->company_id?>">
			<input type="hidden" name="edAdminId" val="a"/>
			<div class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
				<h6>HAPUS ADMIN</h6>
			</div>
			<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
				Apakah anda yakin untuk menghapus admin ini?
			</div>
			<div class="modal-footer">
				<button id="submit-hapus-admin" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
				<button id="batal-hapus-admin" class="modal-close btn blue darken-4" type="button">TIDAK</button>
			</div>
		</div>
	</form>

	<?php } ?>
	<?php include('footer.php');?>
	<script>
	$(document).ready(function() {
		//tabs
		$('.tabs').tabs();
		//select(dropdown)
		$('select').formSelect();
        var elem = document.getElementsByTagName('select'), i;
		for(i in elem){
        	M.FormSelect.init(elem[i], {dropdownOptions:{container:document.body}});
		}

		// var elem = document.getElementById('select-provinsi');
        // M.FormSelect.init(elem, {dropdownOptions:{container:document.body}});
		// var elem = document.getElementById('select-provinsi');
		//modal
		$('.modal').modal();
		//deklarasi dropify
		$('.dropify').dropify();
		//atur height dropify
		$('.dropify-wrapper').height(100);
		//
		M.textareaAutoResize($('.materialize-textarea'));
		
		$('.datepicker').datepicker({
			// mengatur elemen sebagai parent dari date picker
			container: 'body',
			// mengatur format penulisan datepicker diinputfield
			format: 'yyyy-mm-dd'
		});
		// var dt = new Date();
		// var now = dt.getFullYear() + "-" + (dt.getMonth()+1) + "-" + dt.getDate();
		// $('#picker-created-at').datepicker({
		// 	container: 'body',
		// 	format: 'yyyy-mm-dd',
		// 	defaultDate: new Date(now),
		// 	setDefaultDate: true,
		// });
		//deklarasi autocomplete
		$('#autocomplete-skill').autocomplete({
			limit: 3,
		});
		$('.autocomplete-content').appendTo(document.body);

		//ganti text nya dropify
		$('.post .dropify-message p').text("Unggah gambar disini");
		
		$('#modalAdmin').on('click', 'div ul li button.tambah-admin', function(){
			var userId = $(this).siblings('input[name="edConnectionId"]').val();
			var companyId = <?php echo $company->company_id;?>;
			$.ajax({
				method: "post",
				url: '<?= base_url("CCompany/tambahAdmin") ?>',
				data: {
					companyId : companyId,
					userId : userId,
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				var result = JSON.parse(data);
				$('#daftar-admin').html(result[0]);
				$('#modalAdmin .modal-content').html(result[1]);
			});
		});

		$('#daftar-admin').on('click', 'ul li button.delete-admin', function(){
			var adminId = $(this).siblings('input[name="edAdminId"]').val();
			$('#modalHapusAdmin input[name="edAdminId"]').val(adminId);
			$('#modalHapusAdmin').modal('open');
		});

		$('#formHapusAdmin').submit(function(){
			event.preventDefault();
			$.ajax({
                type: "POST",
				url: $('#formHapusAdmin').attr('action'),
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				var result = JSON.parse(data);
				$('#daftar-admin').html(result[0]);
				$('#modalAdmin .modal-content').html(result[1]);
			});
		})
		
		$('#edit-perusahaan').click(function() {
			var companyId = <?php echo $company->company_id;?>;
			$.ajax({
				method: "post",
				url: '<?= base_url("CCompany/dataPerusahaan") ?>',
				data: {
					companyId : companyId
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				var result = JSON.parse(data);
				$('#textfield-nama').val(result.company_name);
				$('#textfield-deskripsi').val(result.company_description);
				$('#textfield-ukuran').val(result.company_size);
				$('#textfield-tipe').val(result.company_type);
				$('#textfield-website-url').val(result.website_url);
				$('#select-tahun-berdiri').val(result.year_founded);
				$('#select-tahun-berdiri').siblings('input.select-dropdown').val(result.year_founded);
				M.textareaAutoResize($('#textfield-deskripsi'));
				M.updateTextFields();
			});
		});

		//edit 
		$('#daftar-lowongan').on('click', 'div div a.edit-pekerjaan', function() {
			var jobId = $(this).siblings('input[name="edJobId"]').val();
			var companyId = $(this).siblings('input[name="edCompanyId"]').val();
			$.ajax({
				method: "post",
				url: '<?= base_url("CCompany/dataPekerjaan") ?>',
				data: {
					jobId : jobId
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				// console.log(data);
				var result = JSON.parse(data);
				// console.log(result);
				$('input[name="edCompanyId"]').val(result[0].company_id);
				$('input[name="edLowonganId"]').val(result[0].job_id);
				$('#modalPekerjaan #industry').val(result[0].industry);
				$('#modalPekerjaan #employmentType').val(result[0].employment_type);
				$('#modalPekerjaan #minSalary').val(result[0].min_gaji);
				$('#modalPekerjaan #maxSalary').val(result[0].max_gaji);
				$('#modalPekerjaan #description').val(result[0].job_description);
				$('#modalPekerjaan #jobFunction').val(result[0].job_functions);
				$('#modalPekerjaan #jobFunction').siblings('input.select-dropdown').val(result[0].job_functions);
				$('#modalPekerjaan #seniorityLevel').val(result[0].seniority_level);
				$('#modalPekerjaan #seniorityLevel').siblings('input.select-dropdown').val(result[0].seniority_level);
				var expired_at = new Date(result[0].expired_at);
				$('#picker-expired-at').datepicker({
					container: 'body',
					format: 'yyyy-mm-dd',
					defaultDate: expired_at,
					setDefaultDate: true,
				});
				var created_at = new Date(result[0].created_at);
				$('#picker-created-at').datepicker({
					container: 'body',
					format: 'yyyy-mm-dd',
					defaultDate: created_at,
					setDefaultDate: true,
				});
				M.textareaAutoResize($('#modalPekerjaan #description'));
				M.updateTextFields();
				$('#hapus-pekerjaan').show();
				$('#submit-edit-pekerjaan').show();
				$('#submit-tambah-pekerjaan').hide();
				$('#formPekerjaan').attr('action','<?= base_url("CCompany/editPekerjaan")?>');
				$('#daftar-skill').html('<h6>Daftar keterampilan yang dibutuhkan : </h6>');
				for(var i = 0; i < result[1].length; i++){
					var skill = 
					"<span>"+
					"<input type='hidden' name='edSkill[]' value='"+result[1][i].skill_name+"' />"+
					"<span class='card-panel skill-name' style='padding:6px 12px;margin:10px 5px;display:inline-block;background-color: #0D47A1 !important;color:white;'>"+result[1][i].skill_name+
					"<button style='margin-left:10px;width:20px;height:20px;background-color: #0D47A1 !important;' class='btn-small btn-flat btn-floating white btn-no-hover remove-skill'>"+
					"<i class='material-icons' style='font-size:1.2rem;color:white;line-height:3px;'>clear</i>"+
					"</button>"+
					"</span>"+
					"</span>";
					$('#daftar-skill').append(skill);
				}
			});
		});

		$('#tambah-pekerjaan').click(function(){
			$('#hapus-pekerjaan').hide();
			$('#submit-edit-pekerjaan').hide();
			$('#submit-tambah-pekerjaan').show();
			$('#formPekerjaan').attr('action','<?= base_url("CCompany/tambahPekerjaan")?>');
		});

		$('#select-provinsi').on('change', function(e){
    		var provinceName = this.value;
			$.ajax({
				type: "POST",
				url: '<?= base_url("CCompany/dataKota")?>',
				data: {
					provinceName: provinceName,
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				var result = JSON.parse(data);
				$('#select-kota').html("<option value='' disabled selected>Pilih Kota</option>");
				for(var i=0; i < result.length; i++){
					$('#select-kota').append('<option value="'+result[i].city_name+'">'+result[i].city_name+'</option>');
				}
				$('#select-kota').prop('disabled', false);
				$('#select-kota').formSelect();
				var elem = document.getElementById('select-kota');
        		M.FormSelect.init(elem, {dropdownOptions:{container:document.body}});
			});
		});
		
		$('#tambah-lokasi').click(function(){
			$('#hapus-lokasi').hide();
			$('#submit-edit-lokasi').hide();
			$('#submit-tambah-lokasi').show();
			$('#checkbox-kantor-pusat').prop('checked', false);
			$('#checkbox-kantor-pusat').prop('disabled', false);
			$('#formLokasi').attr('action','<?= base_url("CCompany/tambahLokasi")?>');
		});

		$('#hapus-lokasi').click(function(){
			$('#modalHapusLokasi').modal('open');
			$('#input-company-location-id-hapus').val($('#input-company-location-id').val());
		});

		$('#batal-hapus-lokasi').click(function(){
			$('#modalLocation').modal('open');
		})

		$('#daftar-lokasi-perusahaan').on('click','div div button.edit-lokasi',function(){
			$('#formLokasi').attr('action','<?= base_url("CCompany/editLokasi")?>');
			$('#submit-edit-lokasi').show();
			$('#submit-tambah-lokasi').hide();
            var companyLocationId = $(this).siblings("input[name='edLocationId']").val();
			$.ajax({
				method: "post",
				url: '<?= base_url("CCompany/dataLokasi") ?>',
				data: {
                    companyLocationId : companyLocationId
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				dataLokasi(data);
			});
		});

		function dataLokasi(data){
			if(data){
				var result = JSON.parse(data);
				$('#input-company-location-id').val(result.location.company_location_id);
				$('#textfield-alamat').val(result.location.company_address);
				$('#textfield-apartemen').val(result.location.suite_apt);
				$('#textfield-kode-pos').val(result.location.zip_code2);
				$('#textfield-nama-bangunan').val(result.location.building_name);
				$('#select-provinsi').val(result.location.state);
				$('#select-provinsi').siblings('input.select-dropdown').val(result.location.state);
				$('#select-kota').html("<option value='' disabled selected>Pilih Kota</option>");
				for(var i=0; i < result.cities.length; i++){
					$('#select-kota').append('<option value="'+result.cities[i].city_name+'">'+result.cities[i].city_name+'</option>');
				}
				$('#select-kota').prop('disabled', false);
				$('#select-kota').formSelect();
				var elem = document.getElementById('select-kota');
				M.FormSelect.init(elem, {dropdownOptions:{container:document.body}});
				$('#select-kota').val(result.location.city);
				$('#select-kota').siblings('input.select-dropdown').val(result.location.city);
				M.textareaAutoResize($('#textfield-deskripsi'));
				M.updateTextFields();
				if(result.location.is_main_office == 1){
					$('#checkbox-kantor-pusat').prop('checked', true);
					$('#checkbox-kantor-pusat').prop('disabled', true);
					$('#hapus-lokasi').hide();
				}else{
					$('#checkbox-kantor-pusat').prop('checked', false);
					$('#checkbox-kantor-pusat').prop('disabled', false);
					$('#hapus-lokasi').show();
				}
			}
		}

		$('#formLokasi').submit(function(event){
			event.preventDefault();
			$('#checkbox-kantor-pusat').prop('disabled', false);
			$.ajax({
                type: "POST",
				url: $('#formLokasi').attr('action'),
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				// console.log(data);
				var result = JSON.parse(data);
				$('#daftar-lokasi-perusahaan').html(result[0]);
				$('#kota').html(result[1].city);
				$('#provinsi').html(result[1].state);
			});
		});

		$('#formPekerjaan').submit(function(event){
			event.preventDefault();
			$.ajax({
                type: "POST",
				url: $('#formPekerjaan').attr('action'),
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				$('#daftar-lowongan').html(data);
			});
		});

		$('#hapus-pekerjaan').click(function(){
			var jobId = $('#modalPekerjaan input[name="edLowonganId"]').val();
			$('#modalHapusPekerjaan input[name="edLowonganId"]').val(jobId);
			$('#modalHapusPekerjaan').modal('open');
		});

		$('#batal-hapus-pekerjaan').click(function(){
			$('#modalPekerjaan').modal('open');
		});

		$('#formHapusPekerjaan').submit(function(event){
			event.preventDefault();
			//console.log($('#modalHapusPekerjaan input[name="edLowonganId"]').val());
			$.ajax({
				type: "POST",
				url: $('#formHapusPekerjaan').attr('action'),
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				$('#daftar-lowongan').html(data);
			});
		});

		$('#formHapusLokasi').submit(function(event){
			event.preventDefault();
			$.ajax({
                type: "POST",
				url: $('#formHapusLokasi').attr('action'),
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				$('#daftar-lokasi-perusahaan').html(data);
			});
		});

		$('#formPerusahaan').submit(function(event) {
			event.preventDefault();
			var companyId = <?php echo $company->company_id;?>;
			$.ajax({
                type: "POST",
                url: '<?= base_url("CCompany/editPerusahaan")?>',
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				// console.log(data);
				var result = JSON.parse(data);
				// console.log(result);	
				$('#nama-perusahaan').html(result[0].COMPANY_NAME);
				$('#deskripsi-perusahaan').html(result[0].COMPANY_DESCRIPTION);
				$('#ukuran-perusahaan').html(result[0].COMPANY_SIZE);
				$('#tipe-perusahaan').html(result[0].COMPANY_TYPE);
				$('#website-url-perusahaan').html(result[0].WEBSITE_URL);
				$('#website-url-perusahaan').attr("href", result[0].WEBSITE_URL);
				$('#tahun-berdiri-perusahaan').html(result[0].YEAR_FOUNDED);
				if(result[0].LOGO_URL){
					$('div#logo-perusahaan').html('<img id="logo-perusahaan" style="padding:20px;max-width:240px;max-height:240px;" src="'+result[0].LOGO_URL+'">');
				}
				if(result[0].COVER_URL){
					$('#cover-perusahaan').html('<div class="cover" style="background: url('+result[0].COVER_URL+');background-size: cover;background-repeat: no-repeat;min-height:360px;"></div>');
					$('#section-perusahaan').css("{margin-top:-250px;}");
				}
				$('#daftar-lowongan').html(result[1]);
			});
		});

		//
		$('#button-follow').click(function(){
			var status = $(this).siblings('input[name="edFollowStatus"]').val();
			var companyId = "<?php echo $company->company_id;?>";
			$.ajax({
				method: "post",
				url: '<?= base_url("CCompany/akunFollow") ?>',
				data:{
					status: status,
					companyId: companyId,
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				// console.log(data);
				var result = JSON.parse(data);
				$('#button-follow').html(result[0]);
				$('#button-follow').siblings('input[name="edFollowStatus"]').val(result[1]);
				$('#follow-count').html(result[2]+" followers");
			});
		});

		//mendapatkan hasil sugestion untuk autocomplete-skill saat user melepas key(keyup)
		$('#autocomplete-skill').keypress(function(){
			var skillName = $(this).val().trim();
			// console.log(skillName);
			$.ajax({
				method: "post",
				url: '<?= base_url("CCompany/getSkill") ?>',
				data:{
					skillName: skillName
				},
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(data) {
				var result = JSON.parse(data);
				var array = {};
				for(var i=0; i < result.length; i++){
					array[result[i].skill_name] = null;
				}
				$('#autocomplete-skill').autocomplete('updateData', array);
			});
		});

		$('#button-tambah-skill').click(function(){
			var skillName = $('#autocomplete-skill').val().trim();
			if(skillName.length >= 3){
				if(!($('#daftar-skill > h6')).length){
					$('#daftar-skill').append('<h6>Daftar keterampilan yang dibutuhkan : </h6>');	
				}
				// console.log(skillName);
				var skill = 
				"<span>"+
				"<input type='hidden' name='edSkill[]' value='"+skillName+"' />"+
				"<span class='card-panel skill-name' style='padding:6px 12px;margin:10px 5px;display:inline-block;background-color: #0D47A1 !important;color:white;'>"+skillName+
				"<button style='margin-left:10px;width:20px;height:20px;background-color: #0D47A1 !important;' class='btn-small btn-flat btn-floating white btn-no-hover remove-skill'>"+
				"<i class='material-icons' style='font-size:1.2rem;color:white;line-height:3px;'>clear</i>"+
				"</button>"+
				"</span>"+
				"</span>";
				// var skillButton = "<button class='btn-small blue darken-4'>"+skillName+"</button>";
				$('#daftar-skill').append(skill);
			}else{
				// console.log("ha");
			}
		});

		$('#daftar-skill').on('click', 'span span button.remove-skill', function(){
			$(this).parent().parent().remove();
			if(!($('#daftar-skill > span')).length){
				$('#daftar-skill > h6').remove();
			}
		});

		//untuk deteksi scroll
		window.onscroll = function(ev) {
			
			//kalau sudah sampai dibawah
			if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
				
				//nanti di isi ajax buat post
				$.ajax({
					method: "post",
					url: '<?= base_url("CPost/ajaxLoadPost") ?>',
					data: {	startPost: startPost,
							// endPost: endPost
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(result) {
					$('.post-container').append(result);
				});
			}
		};
		
		//edit post di klik
		$(document).on('click','.modal-edit',function(){
			var id = $(this).attr("id-post");
			$.ajax({
				method: "post",
				url: '<?= base_url("CHome/ajaxEditPost") ?>',
				data: {	id: id
					},
				beforeSend: function () {
                    $('#modal-edit').html("");
                }
			}).fail(function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}).done(function(result) {
				$('#modal-edit').html(result);
				$('#textarea1').trigger('autoresize');
			});
		})

		//delete post di klik
        $(document).on('click','.modal-delete',function(){
            var id = $(this).attr("id-post");
            $("#modal-delete>.modal-footer>.btn-yes").attr("href","<?php echo base_url('CHome/deletePost/'); ?>"+id)
        });
		$( document ).ajaxStart(function() {
			$( ".preloader-wrapper" ).show();
		});
		
		$(document).ajaxStop(function(){
			$( ".preloader-wrapper" ).hide();
		})
		Highcharts.stockChart('chartJobs', {
			chart: {
				type: 'spline'
			},
			title: {
				text: 'Peningkatan Jumlah Pekerjaan yang dibuat selama 1 Tahun Terkahir'
			},
			legend: {
				align: 'left',
				verticalAlign: 'top',
				borderWidth: 0
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			},
			rangeSelector : {
				buttons: [{
					type: 'month',
					count: 1,
					text: '1m'
				}, {
					type: 'all',
					text: 'All'
				}],
				inputEnabled: false,
				selected : 1
			},

			xAxis: {
				type: 'datetime',
				dateTimeLabelFormats: {
					month: '%e. %b',
					year: '%Y'
				},
				title: {
					text: 'Tanggal'
				}
			},
			yAxis: {
				title: {
					text: 'Pekerjaan'
				},
				min: 0,
				opposite:false
			},

			plotOptions: {
				spline: {
					marker: {
						enabled: true
					}
				}
			},
			series: [{
				name: "Pekerja",
				colors: ['#6CF'],
				data: [
					<?php 
						$i = 1;
						$ctr = count($reportJobs);
						foreach($reportJobs as $item) {
							$tahun = substr($item->tgl, 0,4);
							$bulan = substr($item->tgl, 4,2);
							$bulan = $bulan - 1;
							$tgl = substr($item->tgl, 6,2);
							$date = "Date.UTC($tahun, $bulan, $tgl, 00, 00, 00)";
							echo "[$date, ".$item->jml."]";
							if($i != $ctr){echo ",";};
							$i++;
						}
					?>
				]
			}
			],
			tooltip: {
				 pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} {series.name}</b><br/>'
			}
		});
		
		Highcharts.stockChart('chartApplier', {
			chart: {
				type: 'spline'
			},
			title: {
				text: 'Peningkatan Jumlah Pendaftar Pekerjaan selama 1 Tahun Terkahir'
			},
			legend: {
				align: 'left',
				verticalAlign: 'top',
				borderWidth: 0
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			},
			rangeSelector : {
				buttons: [{
					type: 'month',
					count: 1,
					text: '1m'
				}, {
					type: 'all',
					text: 'All'
				}],
				inputEnabled: false,
				selected : 1
			},

			xAxis: {
				type: 'datetime',
				dateTimeLabelFormats: {
					month: '%e. %b',
					year: '%Y'
				},
				title: {
					text: 'Tanggal'
				}
			},
			yAxis: {
				title: {
					text: 'Pekerja'
				},
				min: 0,
				opposite:false
			},

			plotOptions: {
				spline: {
					marker: {
						enabled: true
					}
				}
			},
			series: [{
				name: "Pekerja",
				colors: ['#6CF'],
				data: [
					<?php 
						$i = 1;
						$ctr = count($reportApplier);
						foreach($reportApplier as $item) {
							$tahun = substr($item->tgl, 0,4);
							$bulan = substr($item->tgl, 4,2);
							$bulan = $bulan - 1;
							$tgl = substr($item->tgl, 6,2);
							$date = "Date.UTC($tahun, $bulan, $tgl, 00, 00, 00)";
							echo "[$date, ".$item->jml."]";
							if($i != $ctr){echo ",";};
							$i++;
						}
					?>
				]
			}
			],
			tooltip: {
				 pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} {series.name}</b><br/>'
			}
		});
	});
	</script>

</body>
</html>