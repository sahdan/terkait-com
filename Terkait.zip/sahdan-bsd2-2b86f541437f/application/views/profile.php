<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 m12 l12 ">
					<!-- Bagian atas profil -->
					<div class="card">
						<div class="card-image blue lighten-2" style="height:180px;">
							<?php if($profileID == $loginID){ ?>
								<button id="edit-profil" data-target="modalEditProfil" style="background-color:transparent;cursor:default, :hover{-webkit-box-shadow:none;box-shadow:none};" class="btn-flat btn-floating modal-trigger right">
									<i class="material-icons">edit</i>
								</button>
							<?php } ?>
						</div>

						<!-- Foto user -->
						<div class="circle" style="position:absolute;height:160px;width:160px;background-color:white;top:100px;left:calc(10% - 50px)">
							<?php if($userProfile->photo_url != "") { ?>
								<img src="<?php echo $userProfile->photo_url; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:8px">
							<?php } else { ?>
								<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:8px">
							<?php } ?>
						</div>
						
						<!-- Button untuk interkasi koneksi(tambah koneksi, hapus koneksi,etc) dengan saat mengakses profil user lain -->
						<div class="row">
							<div class="col l12 m12 s12"  id="div-button-koneksi">
								<input id="status-koneksi" type="hidden" value="<?php if(!empty($connection_status)){echo $connection_status;}?> ">
								<?php if($connection_status == "-1") { ?>
									<button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">add</i>
										TAMBAH KONEKSI
									</button>
									<button id="koneksi-2" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">do_not_disturb</i>
										BLOKIR USER
									</button>
								<?php } elseif($connection_status == "0" && $connection_user_in_action == $loginID) { ?>
									<button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">clear</i>
										BATALKAN KONEKSI	
									</button>
								<?php } elseif($connection_status == "0" && $connection_user_affected == $loginID) { ?>
									<button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">done</i>
										TERIMA KONEKSI
									</button>
									<button id="koneksi-2" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">clear</i>
										TOLAK KONEKSI
									</button>
								<?php } elseif($connection_status == "1") { ?>
									<button id="koneksi-1" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">delete</i>
										HAPUS KONEKSI
									</button>
								<?php } elseif($connection_status == "2" && $connection_user_in_action == $loginID) { ?>
									<button id="koneksi-2" style="font-size:11px;padding:0px 12px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										UNBLOK USER
									</button>
								<?php } ?>
							</div>
						</div>

						<!-- Button untuk kirim pesan dan follow user -->
						<div class="row">
							<input id="status-follow" type="hidden" value="<?php if(!empty($follow_status)){echo $follow_status;}else{echo "0";}?> ">
							<div class="col l12 m12 s12" id="div-button-follow">
								<?php if($connection_status != "2" && $connection_status != "-2"){ ?>
									<button id="button-message" style="font-size:11px;padding:0px 8px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
										<i style="margin-right:5px;" class="material-icons left">message</i>	
										KIRIM PESAN
									</button>
								<?php } ?>
								<?php if($connection_status == "-1" || $connection_status == "0"){ ?>
									<?php if($follow_status == 0) { ?>
										<button id="button-follow" style="font-size:11px;padding:0px 8px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
											FOLLOW
										</button>
									<?php } else {?>
										<button id="button-follow" style="font-size:11px;padding:0px 8px 0px 8px;margin:8px 8px 0px 0px;" class="btn-small blue darken-4 right">
											UNFOLLOW
										</button>
									<?php } ?>
								<?php } ?>
							</div>
						</div>

						<!-- Button untuk informasi user (nama, headline, jumlah koneksi) -->
						<div class="card-content center" style="padding-top:0px;margin-top:24px;">
							<div class="row" style="margin-bottom:10px !important;">
								<h5><b><?php echo ucwords($userProfile->user_first_name." ".$userProfile->user_last_name) ?></b></h5>
								<p style="color:gray"><small><?php echo $userProfile->headline ?></small></p>
							</div>
							<div class="divider"></div>
							<div class="row" style="margin-bottom:10px !important;">
								<?php if($profileID == $loginID){ ?>
								<div class="col l6 m6 s6">
									<h6 id="jumlah-koneksi" style="color:gray"><?php echo $count_user_connections?></h6>
									<p>Koneksi</p>
								</div>
								<div class="col l6 m6 s6">
									<h6 id="jumlah-pengunjung" style="color:gray"><?php echo $ctr_visit?></h6>
									<p>Jumlah Pengunjung</p>
								</div>
								
								<?php }else{?>
								<h6 id="jumlah-koneksi" style="color:gray"><?php echo $count_user_connections?></h6>
								<p>Koneksi</p>
								<?php } ?>
							</div>
							<div class="divider"></div>
							<div class="row" style="margin-bottom:10px !important;">
								<p style="color:gray; margin-top: 25px;"><small><?php echo $userProfile->summary ?></small></p>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Menampilkan sejarah pendidikan user(header) -->
				<?php if(!empty($user_educations) OR $profileID == $loginID) { ?>
					<ul class="collection">

						<li class="collection-item avatar" style="padding-top:0px;">

							<!-- <i class="material-icons circle blue darken-4">school</i> -->

							<h4 style="position:absolute;left:20px;">Edukasi</h4>

							<?php if($profileID == $loginID){?>
								<button id="tambahEdukasi" data-target="modalEdukasi" class="btn-floating modal-trigger secondary-content blue darken-4">
									<i class="material-icons">add</i>
								</button>
							<?php } ?>

						</li>
						
						<!-- Menampilkan sejarah pendidikan user(item) -->
						<?php foreach($user_educations as $item) {?>

							<li class="collection-item avatar">

								<input type="hidden" order="<?php echo $item->education_order; ?>" value="<?php echo $item->company_id; ?>"/>
								<?php if($item->logo_url != ""){ ?>
									<img class="circle" src="<?php echo $item->logo_url; ?>" \>	
								<?php } else { ?>
									<i class="material-icons circle blue darken-4">school</i>
								<?php } ?>

								<div class="title" style="font-weight:bold;"><?php echo $item->company_name; ?></div>

								<span><?php echo $item->from_year."-".$item->to_year." ".$item->academic_degree." ".$item->field_of_study ?></span><br>
								<div><?php echo "NILAI : ".$item->grade ?></div>

								<?php if($item->education_description != ""){ ?>
									<div style="font-weight:bold;"><br>Deskripsi Pendidikan</div>
									<p class="deskripsi"><br><?php echo nl2br($item->education_description) ?></p>
									<br>
								<?php } ?>
								
								<?php if($item->activities_societies != ""){ ?>
									<div style="font-weight:bold;">Kegiatan Sosial atau Aktifitas Lainnya </div>
									<p class="deskripsi"><br><?php echo nl2br($item->activities_societies) ?></p>
									<br>
								<?php } ?>
								
								<?php if($profileID == $loginID){?>
									<button data-target="modalEdukasi" class="btn-floating modal-trigger secondary-content blue darken-4 edit-edukasi">
										<i class="material-icons">edit</i>
									</button>
								<?php } ?>

							</li>
						
						<?php }	?>
						<!-- selesai for each -->
					</ul>
				<?php } ?>

				<!-- Menampilkan skill yang dimiliki user(header) -->
				<?php if(!empty($user_skills) OR $profileID == $loginID) { ?>
					<ul class="collection">

						<li class="collection-item avatar" style="padding-top:0px;">

							<!-- <i class="material-icons circle blue darken-4">school</i> -->

							<h4 style="position:absolute;left:20px;">Skill</h4>

							<?php if($profileID == $loginID){?>
								<button id="tambahSkill" data-target="modalSkill" class="btn-floating modal-trigger secondary-content blue darken-4">
									<i class="material-icons">add</i>
								</button>
							<?php } ?>

						</li>
								
						<!--  Menampilkan skill yang dimiliki user(item) -->
						<?php foreach($user_skills as $item) {?>

							<li style="padding:10px 10px 20px 20px;" class="collection-item list-item-skill">

								<input type="hidden" name="skill-id" value="<?php echo $item->skill_id; ?>"/>

								<span style="position:relative;top:5px;">
									<?php echo $item->skill_name; ?>
									<span class="total-endorsement">
										<?php if($item->ctr != 0){ ?>
											<a style="font-size:10.5pt;">
												(Di-endorse oleh 
												<?php echo $item->ctr; ?>
												user)
											</a>
										<?php } ?>
									</span>
								</span>
								
								<!-- Button untuk menghapus skill/mengendorse skill -->
								<?php if($profileID == $loginID) { ?>
									<button style="color: #0D47A1; background-color:transparent !important;" data-target="modalHapusSkill" class="btn-flat modal-trigger right hapus-skill">
										<i class="material-icons">delete</i>
									</button>
								<?php } elseif($connection_status == 1) { ?>
									<?php if(in_array($item->skill_id, $skill_endorsed)){ ?>
										<span class="span-endorse-skill">
											<input type="hidden" name="is-endorsed" value="1"/>
											<button class="btn-small secondary-content blue darken-4 endorse-skill">
												<i style="margin-right:5px;" class="material-icons left">clear</i>
												Hapus Endorsement
											</button>
										</span>
									<?php } else { ?>
										<span class="span-endorse-skill">
											<input type="hidden" name="is-endorsed" value="0"/>
											<button class="btn-small secondary-content blue darken-4 endorse-skill">
												Endorse
											</button>
										</span>
									<?php } ?>
								<?php } else { ?>
									<span class="span-endorse-skill"></span>
								<?php } ?>
							</li>

						<?php }	?>
						<!-- selesai for each -->
					</ul>
				<?php } ?>
				
				<!-- Menampilkan sejarah pekerjaan user(header) -->
				<?php if(!empty($user_positions) OR $profileID == $loginID) { ?>
					<ul class="collection">

						<li class="collection-item avatar" style="padding-top:0px;">

							<!-- <i class="material-icons circle blue darken-4">school</i> -->

							<h4 style="position:absolute;left:20px;">Pengalaman kerja</h4>

							<?php if($profileID == $loginID){?>
								<button id="tambahPengalaman" data-target="modalPengalaman" class="btn-floating modal-trigger secondary-content blue darken-4">
									<i class="material-icons">add</i>
								</button>
							<?php } ?>

						</li>

						<!-- Menampilkan sejarah pekerjaan user(item) -->
						<?php foreach($user_positions as $item) {?>

							<li class="collection-item avatar">

								<input type="hidden" name="position-company-id" value="<?php echo $item->company_id; ?>"/>
								<input type="hidden" name="position-company-<?php echo strtolower($item->company_name);?>"/>

								<?php if($item->logo_url != ""){ ?>
									<img class="circle" src="<?php echo $item->logo_url; ?>" \>	
								<?php } else { ?>
									<i class="material-icons circle blue darken-4">work</i>
								<?php } ?>

								<div class="title" style="font-weight:bold;"><?php echo $item->title." di ".$item->company_name; ?></div>

								<?php if($item->currently_work_here == '1') { ?>
									<span>Bekerja dari tanggal <?php $date = date_create($item->from_date); echo date_format($date, "d M Y")." sampai sekarang" ?></span><br>
								<?php } else { ?>
									<span>Bekerja dari tanggal <?php $date1 = date_create($item->from_date); $date2 = date_create($item->to_date); echo date_format($date1, "d M Y")." sampai ".date_format($date2, "d M Y") ?></span><br>
								<?php }  ?>
								<div><?php echo "Lokasi : ".$item->location ?></div>

								<?php if($profileID == $loginID){?>
									<button data-target="modalPengalaman" class="btn-floating modal-trigger secondary-content blue darken-4 edit-pengalaman">
										<i class="material-icons">edit</i>
									</button>
								<?php } ?>

							</li>

						<?php }	?>
						<!-- selesai for each -->
					</ul>
				<?php } ?>

				<!-- Modal untuk tambah skill -->
				<form id="formSkill" autocomplete="off" method="post" action="<?php echo base_url('CProfile/tambahSkill');?>" enctype="multipart/form-data">
					<div id="modalSkill" class="modal modal-fixed-footer">
						<div id="header-modal-skill" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>TAMBAH SKILL</h6>
						</div>

						<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<input type="text" id="autocomplete-skill" name="edSkill" class="autocomplete">
											<label for="autocomplete-skill">SKILL</label>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal-footer">
							<button id="submitTambahSkill" class="modal-close btn blue darken-4" type="submit" name="action">TAMBAHKAN</button>
						</div>
					</div>
				</form>
				
				<!-- Modal untuk hapus skill -->
				<form id="formHapusSkill" autocomplete="off" method="post" action="<?php echo base_url('CProfile/hapusSkill');?>" enctype="multipart/form-data">
					<div id="modalHapusSkill" class="modal modal-fixed-footer" style="height:200px;">
						<input id="input-hapus-skill-id" type="hidden" name="edSkillID" val=""/>
						<div id="header-modal-hapus-skill" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>HAPUS SKILL</h6>
						</div>
						<div id="konfirmasiHapusSkill" class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							
						</div>
						<div class="modal-footer">
							<button id="submitHapusSkill" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
							<button id="batalHapusSkill" class="modal-close btn blue darken-4" type="button">TIDAK</button>
						</div>
					</div>
				</form>
				
				<!-- Modal untuk hapus pengalaman -->
				<form id="formHapusPengalaman" autocomplete="off" method="post" action="<?php echo base_url('CProfile/hapusPengalaman');?>" enctype="multipart/form-data">
					<div id="modalHapusPengalaman" class="modal modal-fixed-footer" style="height:200px;">
						<input id="input-hapus-pengalaman-id" type="hidden" name="edCompanyID" val=""/>
						<div id="header-modal-hapus-pengalaman" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>HAPUS PENGALAMAN</h6>
						</div>
						<div id="konfirmasiHapusPengalaman" class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							Apakah anda yakin untuk menghapus pengalaman kerja ini?
						</div>
						<div class="modal-footer">
							<button id="submitHapusPengalaman" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
							<button id="batalHapusPengalaman" class="modal-close btn blue darken-4" type="button">TIDAK</button>
						</div>
					</div>
				</form>

				<!-- Modal untuk hapus edukasi -->
				<form id="formHapusEdukasi" autocomplete="off" method="post" action="<?php echo base_url('CProfile/hapusEdukasi');?>" enctype="multipart/form-data">
					<div id="modalHapusEdukasi" class="modal modal-fixed-footer" style="height:200px;">
						<input id="input-hapus-edukasi-order" type="hidden" name="edOrderEdukasi" val=""/>
						<div id="header-modal-hapus-edukasi" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>HAPUS EDUKASI</h6>
						</div>
						<div id="konfirmasiHapusEdukasi" class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							Apakah anda yakin untuk menghapus edukasi ini?
						</div>
						<div class="modal-footer">
							<button id="submitHapusEdukasi" class="modal-close btn blue darken-4" type="submit" name="action">YA</button>
							<button id="batalHapusEdukasi" class="modal-close btn blue darken-4" type="button">TIDAK</button>
						</div>
					</div>
				</form>

				<!-- Modal untuk edit profil -->
				<form id="formProfil" autocomplete="off" method="post" action="<?php echo base_url('CProfile/editProfil');?>" enctype="multipart/form-data">
					<div id="modalEditProfil" class="modal modal-fixed-footer">
						<div id="header-modal-profil" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>EDIT PROFIL</h6>
						</div>
						<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							<div class="row">
								<div class="col s12">
									<div class = row>
										<div class="input-field col s12 m6">
											<input type="text" id="textfield-nama-depan" name="edNamaDepan">
											<label for="textfield-nama-depan">NAMA DEPAN</label>
										</div>
										<div class="input-field col s12 m6">
											<input type="text" id="textfield-nama-belakang" name="edNamaBelakang">
											<label for="textfield-nama-belakang">NAMA BELAKANG</label>
										</div>
									</div>
									<div class = row>
										<div class="input-field col s12">
											<input type="text" id="textfield-headline" name="edHeadline">
											<label for="textfield-headline">HEADLINE</label>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<textarea type="text" id="textarea-ringkasan" name="edRingkasan" class="materialize-textarea"></textarea>
											<label for="textarea-ringkasan">RINGKASAN</label>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<input id="textfield-email" name="edEmail" type="email" class="validate">
											<label for="textfield-email">EMAIL</label>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<input id="textfield-zipcode" name="edZipcode" type="text">
											<label for="textfield-zipcode">ZIPCODE</label>
										</div>
									</div>
									<div class="row">
										<div class="file-field input-field col s12">
											<div class="btn blue darken-4">
												<span>UPLOAD FOTO PROFIL</span>
												<input type="file" name="edPhotoUrl">
											</div>
											<div class="file-path-wrapper">
												<input class="file-path validate" type="text">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button id="submitProfil" class="modal-close btn blue darken-4" type="submit" name="action">SIMPAN</button>
						</div>
					</div>
				</form>
				
				<!-- Modal untuk tambah/edit pengalaman kerja -->
				<form id="formPengalaman" autocomplete="off" method="post" action="<?php echo base_url('CProfile/tambahPengalaman');?>" enctype="multipart/form-data">
					
					<div id="modalPengalaman" class="modal modal-fixed-footer">
						
						<input id="input-tipe" type="hidden" name="edTipeFormPengalaman" value="tambah"/>
						<input id="input-company-id" type="hidden" name="edCompanyID" value=""/>

						<div id="header-modal-pengalaman" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>TAMBAH PENGALAMAN KERJA</h6>
						</div>

						<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<i class="material-icons prefix">work</i>
											<input type="text" id="autocomplete-perusahaan" name="edPerusahaan" class="autocomplete">
											<label for="autocomplete-perusahaan">PERUSAHAAN</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class = row>
										<div class="col s12 m6">
											<input id="picker-mulai-kerja" name="edMulaiKerja" class="datepicker" type="text">
											<label for="picker-mulai-kerja">TANGGAL MULAI BEKERJA</label>
										</div>
										<div id="div-selesai-kerja" class="col s12 m6">
											<input id="picker-selesai-kerja" name="edSelesaiKerja" class="datepicker" type="text">
											<label for="picker-selesai-kerja">TANGGAL SELESAI BEKERJA</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="col s12">
										<br/>
										<label>
											<input id="checkbox-sedang-bekerja" name="edSedangBekerja" type="checkbox" class="filled-in"/>
											<span>SEDANG BEKERJA DI PERUSAHAAN INI</span>
										</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<input type="text" id="textfield-lokasi" name="edLokasi" class="validate">
											<label for="textfield-lokasi">LOKASI</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<input type="text" id="textfield-jabatan" name="edJabatan" class="validate">
											<label for="textfield-jabatan">JABATAN</label>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Selesai modal content -->
						<div class="modal-footer">
							<button id="submitTambahPengalaman" class="modal-close btn blue darken-4" type="submit" name="action">TAMBAHKAN</button>
							<button id="submitEditPengalaman" style="display:none;" class="modal-close btn blue darken-4" type="submit" name="action">EDIT</button>
							<button id="hapusPengalaman" style="display:none;" class="modal-close btn blue darken-4 left" type="button">HAPUS</button>
						</div>

					</div>
					<!-- Selesai modal pekerjaan -->
				</form>
				
				<!-- Modal untuk tambah/edit sejarah pendidikan -->
				<form id="formEdukasi" autocomplete="off" method="post" action="<?php echo base_url('CProfile/tambahEdukasi');?>" enctype="multipart/form-data">
					
					<div id="modalEdukasi" class="modal modal-fixed-footer">
						
						<input id="input-university-id" type="hidden" name="edUniversityID" value=""/>
						<input id="input-edukasi-order" type="hidden" name="edOrderEdukasi" value=""/>

						<div id="header-modal-edukasi" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
							<h6>TAMBAH EDUKASI</h6>
						</div>

						<div class="modal-content" style="top:56px; height:calc(100% - 112px);max-height:calc(100%-112px);">
							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<i class="material-icons prefix">school</i>
											<input type="text" id="autocomplete-sekolah" name="edSekolah" class="autocomplete">
											<label for="autocomplete-sekolah">SEKOLAH</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class = row>
										<div class="input-field col s12 m6">
											<!-- <span>TAHUN MULAI</span> -->
											<!-- <select class="browser-default" name="edTahunMulai" id="select-tahun-mulai"> -->
											<select name="edTahunMulai" id="select-tahun-mulai">
												<?php
													for( $i= date("Y") ; $i >= 1970 ; $i-- ){
														echo '<option value="' . $i . '" >' . $i . '</option>';
													}
												?>
											</select>
											<label>TAHUN MULAI</label>
										</div>
										<div class="input-field col s12 m6">
											<!-- <span>TAHUN SELESAI</span> -->
											<!-- <select class="browser-default" name="edTahunSelesai" id="select-tahun-selesai"> -->
											<select name="edTahunSelesai" id="select-tahun-selesai">
												<?php
													for( $i= date("Y") + 10 ; $i >= 1970 ; $i-- ){
														echo '<option value="' . $i . '" >' . $i . '</option>';
													}
												?>
											</select>
											<label>TAHUN SELESAI/ DIPERKIRAKAN SELESAI</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<input type="text" id="textfield-tingkat" name="edTingkat" class="validate">
											<label for="textfield-tingkat">TINGKAT PENDIDIKAN</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<input type="text" id="textfield-jurusan" name="edJurusan" class="validate">
											<label for="textfield-jurusan">JURUSAN</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<input type="text" id="textfield-nilai" name="edNilai" class="validate">
											<label for="textfield-nilai">NILAI</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<textarea type="text" id="textarea-kegiatan" name="edKegiatan" class="materialize-textarea"></textarea>
											<label for="textarea-kegiatan">KEGIATAN</label>
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col s12">
									<div class="row">
										<div class="input-field col s12">
											<textarea type="text" id="textarea-deskripsi" name="edDeskripsi" class="materialize-textarea"></textarea>
											<label for="textarea-deskripsi">DESKRIPSI</label>
										</div>
									</div>
								</div>
							</div>

							<!-- <div class="row" style="padding-bottom:10px;padding-left:10px;">
								<div class="col s12">
									<div class="row">
										MEDIA
									</div>
									<div class="row" style="padding-top:10px">
										<button class="btn blue darken-4" style="font-color:white;">Upload</button>
									</div>
								</div>
							</div> -->

						</div>

						<!-- Selesai modal content -->
						<div class="modal-footer">
							<button id="submitTambahEdukasi" class="modal-close btn blue darken-4" type="submit" name="action">TAMBAHKAN</button>
							<button id="submitEditEdukasi" style="display:none;" class="modal-close btn blue darken-4" type="submit" name="action">EDIT</button>
							<button id="hapusEdukasi" style="display:none;" class="modal-close btn blue darken-4 left" type="button">HAPUS</button>
						</div>

					</div>
					<!-- Selesai modal edukasi -->
				</form>

				<!--  Modal pemberitahuan-->
				<div id="modalPemberitahuan" class="modal modal-fixed-footer" style="height:200px;">
					<div id="header-modal-pemberitahuan" class="modal-footer" style="top:0; border-radius:2px 2px 0 0;padding:4px 20px;height:56px;text-align:left;border-bottom:1px solid rgba(0,0,0,0.1)">
						<h6>PEMBERITAHUAN</h6>
					</div>
					<div id="isiPemberitahuan" class="modal-content" style="top:56px; height:calc(100% - 84px);max-height:calc(100% - 84px);">

					</div>
					<div class="modal-footer">
						<button class="modal-close btn blue darken-4" type="button">OK</button>
					</div>
				</div>      
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script>
		$(document).ready(function(){
			// inisialisasi class modal
			$('.modal').modal();
			// inisialisasi elemen select
			$('select').formSelect();
			// pembatasan sugestion untuk class autocomplete
			$('#autocomplete-skill').autocomplete({
				limit: 3,
			});
			$('#autocomplete-perusahaan').autocomplete({
				limit: 3,
			});
			$('#autocomplete-sekolah').autocomplete({
				limit: 3,
			});

			$('.datepicker').datepicker({
				// mengatur elemen sebagai parent dari date picker
				container: 'body',
				// mengatur format penulisan datepicker diinputfield
				format: 'yyyy-mm-dd'
			});

			//menyembunyikan/memunculkan komponen div selesai kerja dalam modal tambah/edit pengalaman kerja sesuai status checkbox
			$("#checkbox-sedang-bekerja").change(function() {
				if(this.checked) {
					$('#div-selesai-kerja').hide();
				}else{
					$('#div-selesai-kerja').show();
				}
			});

			//me-redirect halaman profil ke halaman message
			$("#button-message").click(function(){
				window.location = "<?php echo base_url('CMessages/startConversation/').$profileID; ?>";
			});

			//mendapatkan hasil sugestion untuk autocomplete-skill saat user melepas key(keyup)
			$('#autocomplete-skill').keyup(function(){
				var skillName = $(this).val();
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/getSkill") ?>',
					data:{
						skillName: skillName
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					var array = {};
					for(var i=0; i < result.length; i++){
						array[result[i].skill_name] = null;
					}
					$('#autocomplete-skill').autocomplete('updateData', array);
				});
			});

			//mendapatkan hasil sugestion untuk autocomplete-sekolah saat user melepas key(keyup)
			$('#autocomplete-sekolah').keyup(function(){
				var universityName = $(this).val();
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/getSekolah") ?>',
					data:{
						universityName: universityName
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					var array = {};
					for(var i=0; i < result.length; i++){
						array[result[i].company_name] = null;
					}
					console.log(array);
					$('#autocomplete-sekolah').autocomplete('updateData', array);
				});
			});

			//mendapatkan hasil sugestion untuk autocomplete-perusahaan saat user melepas key(keyup)
			$('#autocomplete-perusahaan').keyup(function(){
				var companyName = $(this).val();
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/getPerusahaan") ?>',
					data:{
						companyName: companyName
						},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					var array = {};
					for(var i=0; i < result.length; i++){
						array[result[i].company_name] = null;
					}
					$('#autocomplete-perusahaan').autocomplete('updateData', array);
				});
			});

			//mengatur modal untuk tambah pengalaman kerja saat button tambah pengalaman diklik
			$('#tambahPengalaman').click(function(){
				$('#header-modal-pengalaman').html('<h6>TAMBAH PENGALAMAN<h6/>');
				$('input[name="edTipeFormPengalaman"]').val("tambah");
				$('#autocomplete-perusahaan').val('');
				$('#textfield-lokasi').val('');
				$('#textfield-jabatan').val('');
				$('#checkbox-sedang-bekerja').prop('checked', false);
				$('#picker-mulai-kerja').datepicker({
					container: 'body',
					format: 'yyyy-mm-dd',
				});
				$('#picker-selesai-kerja').datepicker({
					container: 'body',
					format: 'yyyy-mm-dd',
				});
				$('#div-selesai-kerja').show();
				
				M.updateTextFields();

				$('#submitTambahPengalaman').show();
				$('#submitEditPengalaman').hide();
				$('#hapusPengalaman').hide();
				$('#formPengalman').attr("action","<?php echo base_url('CProfile/tambahPengalaman');?>");
			});

			$('#formPengalaman').submit(function(event){
				if($('input[name="edTipeFormPengalaman"]').val() == "tambah"){
					var inputName = "position-company-"+$("#autocomplete-perusahaan").val();
					inputName = inputName.toLowerCase();
					if($('input[name="'+inputName+'"]').length){
						event.preventDefault();
						$('#isiPemberitahuan').html(
							'Pengalaman kerja anda di "'+$('#autocomplete-perusahaan').val()+'" telah terdaftar, silahkan edit, atau tambah pengalaman kerja di perusahaan lain. '
						);
						$('#modalPemberitahuan').modal('open');
					}else{
						console.log('non-exist');
					}
				}
			});

			//mengatur modal untuk tambah sejarah pendidikan saat button tambah edukasi diklik
			$('#tambahEdukasi').click(function(){
				$('#header-modal-edukasi').html('<h6>TAMBAH EDUKASI<h6/>');

				$('#select-tahun-mulai').val("<?php echo date("Y") ?>");
				$('#select-tahun-mulai').siblings('input.select-dropdown').val("<?php echo date("Y") ?>");
				$('#select-tahun-selesai').val("<?php echo date("Y") ?>");
				$('#select-tahun-selesai').siblings('input.select-dropdown').val("<?php echo date("Y") ?>");

				$('#autocomplete-sekolah').val('');
				$('#textfield-tingkat').val('');
				$('#textfield-jurusan').val('');
				$('#textfield-nilai').val('');
				$('#textarea-kegiatan').val('');
				$('#textarea-deskripsi').val('');
				
				M.updateTextFields();
				M.textareaAutoResize($('#textarea-kegiatan'));
				M.textareaAutoResize($('#textarea-deskripsi'));

				$('#submitTambahEdukasi').show();
				$('#submitEditEdukasi').hide();
				$('#hapusEdukasi').hide();
				$('#formEdukasi').attr("action","<?php echo base_url('CProfile/tambahEdukasi');?>");
			});

			//memunculkan modal hapus pengalaman kerja saat button hapus pengalaman diklik
			$('#hapusPengalaman').click(function(){
				$('#modalHapusPengalaman').modal('open');
				$('#input-hapus-pengalaman-id').val($('#input-company-id').val());
			});

			//mengembaikan modal ke modal tambah/edit pengalaman kerja saat button batal hapus pengalaman diklik
			$('#batalHapusPengalaman').click(function(){
				$('#modalPengalaman').modal('open');
			});

			//memunculkan modal hapus sejarah edukasi saat button hapus edukasi diklik
			$('#hapusEdukasi').click(function(){
				$('#modalHapusEdukasi').modal('open');
				$('#input-hapus-edukasi-order').val($('#input-edukasi-order').val());
			});

			//mengembaikan modal ke modal tambah/edit sejarah edukasi saat button batal hapus edukasi diklik
			$('#batalHapusEdukasi').click(function(){
				$('#modalEdukasi').modal('open');
			});

			//memunculkan modal konfirmasi hapus skill saat button hapus skill diklik
			$('.hapus-skill').click(function(){
				var skillID = $(this).siblings('input[type=hidden]').val();
				$.ajax({
					method: 'post',
					url: '<?= base_url("CProfile/getSkillById") ?>',
					data:{
						skillID : skillID,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					$('#konfirmasiHapusSkill').html('Apakah Anda yakin akan menghapus skill "'+data+'" ?');
					$('#input-hapus-skill-id').val(skillID);
				})
			});

			//mengatur modal edit pengalaman kerja saat button edit pengalaman diklik
			$('.edit-pengalaman').click(function() {
				var companyID = $(this).siblings('input[name="position-company-id"]').val();
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/getPengalaman") ?>',
					data: {
						companyID : companyID
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					var from_date = new Date(result.from_date);
					$('#header-modal-pengalaman').html('<h6>EDIT PENGALAMAN<h6/>');
					$('input[name="edTipeFormPengalaman"]').val("edit");
					$('#input-company-id').val(companyID);
					$('#autocomplete-perusahaan').val(result.company_name);
					$('#textfield-lokasi').val(result.location);
					$('#textfield-jabatan').val(result.title);
					if(result.currently_work_here = '1'){
						$('#checkbox-sedang-bekerja').prop('checked', true);
						$('#div-selesai-kerja').hide();
						$('#picker-selesai-kerja').datepicker({
							container: 'body',
							format: 'yyyy-mm-dd',
						});
					}else{
						var to_date = new Date(result.to_date);
						$('#checkbox-sedang-bekerja').prop('checked', false);
						$('#div-selesai-kerja').show();	
						$('#picker-selesai-kerja').datepicker({
							container: 'body',
							format: 'yyyy-mm-dd',
							defaultDate: to_date,
							setDefaultDate: true,
						});
					}
					$('#picker-mulai-kerja').datepicker({
						container: 'body',
						format: 'yyyy-mm-dd',
						defaultDate: from_date,
						setDefaultDate: true,
					});

					M.updateTextFields();

					$('#submitTambahPengalaman').hide();
					$('#submitEditPengalaman').show();
					$('#hapusPengalaman').show();
					$('#formPengalaman').attr("action","<?php echo base_url('CProfile/editPengalaman');?>");
				});
			});

			//mengatur modal edit profil kerja saat button edit profil diklik
			$('#edit-profil').click(function() {
				var profileID = <?php echo $profileID ?>;
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/getProfil") ?>',
					data:{
						profileID : profileID,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					$('#textfield-nama-depan').val(result.user_first_name);
					$('#textfield-nama-belakang').val(result.user_last_name);
					$('#textfield-headline').val(result.headline);
					$('#textfield-email').val(result.user_email);
					$('#textfield-zipcode').val(result.zip_code);
					$('#textarea-ringkasan').val(result.summary);
					
					M.updateTextFields();
					M.textareaAutoResize($('#textarea-ringkasan'));
				});
			});

			//fungi untuk mengendorse skill user lain
			$(".span-endorse-skill").on('click','.endorse-skill', function(){
				var parent = $(this).parent();
				var label = $(this).parent().siblings("span").children(".total-endorsement");
				var is_endorsed = $(this).siblings("input[name='is-endorsed']").val();
				var skill_id = $(this).parent().siblings("input[name='skill-id']").val();
				var profileID = "<?php echo $profileID;?>";
				$.ajax({
					method:"post",
					url: '<?= base_url("CProfile/endorseSkill")?>',
					data:{
						is_endorsed: is_endorsed,
						skill_id: skill_id,
						profileID: profileID,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					$(parent).html(result[0]);
					$(label).html(result[1]);
				});
			});

			//fungi untuk tambah/batal/terima/hapus koneksi button koneksi 1 diklik
			$("#div-button-koneksi").on('click', '#koneksi-1', function(){
				var elemen = $(this).parent();
				var status = $('#status-koneksi').val();
				var new_status = -1;
				var profileID = "<?php echo $profileID;?>";
				var loginID = "<?php echo $loginID;?>";
				if(status == -1){
					new_status = 0;
				}else if(status == 0){
					<?php if(!empty($connection_user_affected) && $connection_user_affected != "") { ?>
						<?php if($profileID == $connection_user_affected){ ?>
							new_status = -1;
						<?php } else { ?>
							new_status = 1;
						<?php } 
					} ?>
				}else if(status == 1){
					new_status = -1;
				}	
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/userKoneksi")?>',
					data:{
						status: new_status,
						profileID: profileID,
						loginID: loginID,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					//console.log(data);
					var result = JSON.parse(data);
					//console.log(result);
					$(elemen).html(result[0]);
					$('#jumlah-koneksi').html(result[1]);
					buttonFollowChange(result[2], result[3]);
					$('.list-item-skill').each(function(i, el){
						var skill_id = $(el).children('input[name="skill-id"]').val();
						//console.log(typeof result[4][skill_id]);
						var button_span = $(el).children('span.span-endorse-skill');
						if("undefined" == typeof result[4]){
							$(button_span).html("");
						}else{
							$(button_span).html(result[4][skill_id]);
						}
					});
				});
			});

			// fungsi untuk blokir/tolak saat button koneksi 2 diklik
			$("#div-button-koneksi").on('click', '#koneksi-2', function(){
				var elemen = $(this).parent();
				var status = $('#status-koneksi').val();
				var new_status = -1;
				var profileID = "<?php echo $profileID;?>";
				var loginID = "<?php echo $loginID;?>";
				if(status == -1){
					new_status = 2;
				}else{
					new_status = -1;
				}
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/userKoneksi")?>',
					data:{
						status: new_status,
						profileID: profileID,
						loginID: loginID,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					$(elemen).html(result[0]);
					$('#jumlah-koneksi').html(result[1]);
					buttonFollowChange(result[2], result[3]);
				});
			});

			//fungsi untuk me-follow/unfollow saat button follow diklik
			$("#div-button-follow").on('click', '#button-follow', function(){
				var elemen = $(this);
				var status = $('#status-follow').val();
				var profileID = "<?php echo $profileID;?>";
				var loginID = "<?php echo $loginID;?>";
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/akunFollow")?>',
					data:{
						status: status,
						profileID: profileID,
						loginID: loginID,
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					var result = JSON.parse(data);
					$(elemen).html(result[0]);
					$('#status-follow').val(result[1]);
				});
			});
			
			//fungsi untuk menyembunyikan/memunculkan button follow saat button koneksi 1 atau button koneksi 2 diklik
			function buttonFollowChange(connection_status, follow_status){
				$('#status-follow').val(follow_status);
				if(connection_status == 0 || connection_status == -1){
					$('#button-follow').show();
					if(follow_status == 1){
						$('#button-follow').html("UNFOLLOW");
					}else{
						$('#button-follow').html("FOLLOW");
					}
				}else{
					$('#button-follow').hide();
				}
			}
			
			//untuk memasukkan data ke modal edit edukasi saat button edit edukasi diklik
			$('.edit-edukasi').click(function() {
				var universityID = $(this).siblings('input[type=hidden]').val();
				var order = $(this).siblings('input[type=hidden]').attr("order");
				$.ajax({
					method: "post",
					url: '<?= base_url("CProfile/getEdukasi") ?>',
					data:{
						universityID: universityID,
						order: order
					},
				}).fail(function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}).done(function(data) {
					
					var result = JSON.parse(data);

					// jQuery.each (result, function(i, val){
					// 	console.log("company_name = " + val.company_name);
					// 	console.log("company_id = " + val.company_id);
					// });
					
					$('#header-modal-edukasi').html('<h6>EDIT EDUKASI<h6/>');
					$('#input-university-id').val(universityID);
					$('#input-edukasi-order').val(order);

					$('#select-tahun-mulai').val(result.from_year);
					$('#select-tahun-mulai').siblings('input.select-dropdown').val(result.from_year);
					$('#select-tahun-selesai').val(result.to_year);
					$('#select-tahun-selesai').siblings('input.select-dropdown').val(result.to_year);

					$('#autocomplete-sekolah').val(result.company_name);
					$('#textfield-tingkat').val(result.academic_degree);
					$('#textfield-jurusan').val(result.field_of_study);
					$('#textfield-nilai').val(result.grade);
					$('#textarea-kegiatan').val(result.activities_societies);
					$('#textarea-deskripsi').val(result.education_description);
					
					M.updateTextFields();
					M.textareaAutoResize($('#textarea-kegiatan'));
					M.textareaAutoResize($('#textarea-deskripsi'));
				});
				
				$('#formEdukasi').attr("action","<?php echo base_url('CProfile/editEdukasi');?>");

				$('#submitTambahEdukasi').hide();
				$('#submitEditEdukasi').show();
				$('#hapusEdukasi').show();
			});
		});

		//menginisialisasi textarea
		M.textareaAutoResize($('#textarea-kegiatan'));
		M.textareaAutoResize($('#textarea-deskripsi'));
	</script>
</body>
</html>