<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    height: auto !important;
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}

.message-container{
	height:500px;
	overflow:auto;
	overflow-x: hidden;
}
.message-container-body{
	height:500px;
}

.section {
    padding-top: 0px !important;
	margin-top: -15px;
}
.message-head{
	margin:0px !important;
	cursor: pointer;
	border-bottom: 1px grey solid;
}

.message-head-body{
	padding:0px important;
}
.message-body{
	height: 281px;
	overflow:auto;
	overflow-x: hidden;
}

.card .card-action {
	padding:24px !important;
}

.card .card-action.chat{
	padding:16px 6px !important;
}

.card .card-content.chat{
    padding: 5px !important;
	margin-top:10px;
}
.header-message{
	background-color:whitesmoke;
}
</style>
	<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 m4 l3 " style="padding:0px;">
					<div class="card message-container">
						<a id="startConv" href="#modalStartConversation" class="btn-floating btn-small modal-trigger left" style="margin: 1%;">
							<i class="material-icons">add</i>
						</a>
						<?php foreach($conversation as $item){?>
						<div class="message-head" conversation-id="<?php echo $item->conversation_id;?>" member="<?php echo $item->name; ?>">
							<div class="card-image blue darken-4 row" style="height:70px;padding-top: 24px;">
								
								<div class="" style="margin-top: -2px; margin-left: 30px; color: white; font-weight: bold;"><?php if(strlen($item->name)>26){echo substr(strip_tags($item->name),0,25)."...";}else{
									echo $item->name;
								}?></div>
							</div>
							
							<div class="card-content message-head-body row">
								<div class="col s10 m10 l10 message-content-<?php echo $item->conversation_id;?>">
									<?php if(strlen($item->name)>50){echo substr(strip_tags($item->message_content),0,49)."...";}else{
										echo $item->message_content;
									}?>
								</div>
								<?php if($item->last_seen < $item->timestamp){?>
								<i class="material-icons right col s2 m2 l2 material-icons-<?php echo $item->conversation_id;?>" style="color:green;margin-right: -15px;">fiber_manual_record</i>
								<?php }?>
							</div>	
						</div>
						<?php }?>
					</div>
				</div>
				<div class="col s12 m8 l9" style="padding:0px;">
					<!-- Untuk unggah status -->
					<div class="card post message-container-body">
						<div class="header-message">
							<div class="row" style="padding: 2%;">
								<div class="header-message-room col s8 m8 l8">
								</div>
								<div class="col s4 m4 l4 right">
									<a id="addMember" href="#modalAdd" class="btn-floating btn-small modal-trigger right" style="margin: 1%;">
										<i class="material-icons">add</i>
									</a>
								</div>
							</div>
						</div>
						<div class="message-body" style="margin:0px;">
							
						</div>
						<form method="post" action="#" id="submitChat" enctype="multipart/form-data" style="margin:0px;">
							<div class="card-content chat">
								<textarea id="textarea" name='edContent' class="materialize-textarea" placeholder="Tulis disini..." ></textarea>
								<input name="edConversationId" id="edConversationId" class="edConversationId" style="display:none">
							</div>	
							<div class="card-action post-action chat">
								<button class="btn btn-post waves-effect waves-light right indigo darken-4" type="submit" name="action">Kirim
								<i class="material-icons right">send</i></button>
							</div>
						</form>
					</div>
				</div>
				<div id="modalAdd" class="modal">
					<form method="post" action="<?php echo base_url('CMessages/addMmeber');?>" id="submitChat" enctype="multipart/form-data" style="margin:0px;">
						<div class="modal-content">
							<h4>Tambah Orang Baru</h4>
							<div class="row">
								<div class="input-field col s12">
								<i class="material-icons prefix">people</i>
								<input name="edConversationId" id="edConversationId" class="edConversationId" style="display:none">
								<input type="text" id="autocomplete-input" name="edMember"class="autocomplete">
								<label for="autocomplete-input">Cari</label>
								</div>
							</div>
						</div>
						<div class="modal-footer">
								<button class="btn btn-post waves-effect waves-light right indigo darken-4" type=	"submit" name="action">Tambah</button>
							<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
						</div>
					</form>
				</div>
				<div id="modalStartConversation" class="modal">
					<form method="post" action="<?php echo base_url('CMessages/startConv');?>" id="submitChat" enctype="multipart/form-data" style="margin:0px;">
						<div class="modal-content">
							<h4>Buat Obrolan Baru</h4>
							<div class="row">
								<div class="input-field col s12">
								<i class="material-icons prefix">people</i>
								<input type="text" id="autocomplete-connection" class="autocomplete-connection" name="edMember" class="autocomplete">
								<label for="autocomplete-input">Cari</label>
								</div>
							</div>
						</div>
						<div class="modal-footer">
								<button class="btn btn-post waves-effect waves-light right indigo darken-4" type="submit" name="action">Buat</button>
							<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script async>
	$(document).ready(function() {
		$('.modal').modal();
		$('#submitChat').hide();
		$('#addMember').hide();
		M.updateTextFields();
		xhrPool = [];
		$('#autocomplete-input').autocomplete({
		  data: {
			<?php
			foreach($connections as $item){
				if($item->user_id != $_SESSION["user_id"]){
			?>
			'<?php echo $item->name ?>':null,
			<?php
				}
				}
			?>
		},
		});
		$('.autocomplete-connection').autocomplete({
		  data: {
			<?php
			foreach($connections as $item){
				if($item->user_id != $_SESSION["user_id"]){
			?>
			'<?php echo $item->name ?>':null,
			<?php
			}}
			?>
		},
		});
		//edit comment di klik
		$(document).on('click','.message-head',function(){
			var id = $(this).attr("conversation-id");
			var member = $(this).attr("member");
			// console.log(id);
			$.ajax({
				method: "post",
				url: '<?= base_url("CMessages/loadConversation") ?>',
				data: {	id: id
					},
				beforeSend: function () {
                    $('#modal-edit-comment').html("");
					// $('.message-body').html("LOADING....");
                }
			}).fail(function(jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
			}).done(function(result) {
				$.each(xhrPool, function(idx, jqXHR) {
					  jqXHR.abort();
				});
				$('.message-body').html(result);
				$('.message-body').animate({scrollTop: $('.message-body').get(0).scrollHeight}, 1000);
				$('.message-container-body>form').attr("action", "<?php echo base_url('CMessages/submit_chat/');?>"+id);
				$('.message-container-body>form').attr("conversation-id", id);
				$('.edConversationId').val(id);
				$('.material-icons-'+id).remove();
				$('#submitChat').show();
				$('#addMember').show();
				$('.header-message-room').text(member);
				setTimeout(refresh(), 5000);
				$(".message-head-body").css("background", "");
				$(".message-head[conversation-id='"+id+"']>.message-head-body").css("background", "lightgray");
				// console.log(id);
			});
		})
		
		$("#submitChat").submit(function(event){
			var id = $(this).attr("conversation-id");
			var url = $('.message-container-body>form').attr("action");
			event.preventDefault();
			$.ajax({
				url: url,
				type: "POST",            
				data: new FormData(this),
				contentType: false,      
				cache: false,            
				processData:false, 
			}).fail(function(jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
			}).done(function(result) {
				$(".message-content-"+id).text($("#textarea").val());
				$("#textarea").val("");
				$(".message-body").append(result);
			});
		});
		
		<?php 
			if(isset($runConversationId)){
				?>
					$(".message-head[conversation-id='<?php echo $runConversationId; ?>']").click();
					$(".message-head[conversation-id='<?php echo $runConversationId; ?>']>.message-head-body").css("background", "lightgray");
				<?php
			}
		?>
	});
	
	function refresh(){
		var id = $(".message-container-body>form").attr("conversation-id");
		$.ajax({
			method: "post",
			url: '<?= base_url("CMessages/loadConversation") ?>',
			data: {	id: id
				},
			beforeSend: function (jqXHR, settings) {
				xhrPool.push(jqXHR);
				// $('.message-body').html("LOADING....");
			}
		}).fail(function(jqXHR, textStatus, errorThrown) {
			console.log(errorThrown);
		}).done(function(result) {
			$('.message-body').html(result);
			setTimeout(refresh(), 5000);
		});
	}
	</script>

</body>
</html>