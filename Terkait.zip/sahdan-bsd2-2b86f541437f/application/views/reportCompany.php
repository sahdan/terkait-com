<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<style>
.btn-post{
	margin-top : -1%;
}
.materialize-textarea{
	border: 1px solid #e0e0e0 !important;
	padding: 3% !important;
}
.post-action{
	height:54px;
}
input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    box-shadow: 0 1px 0 0 #e0e0e0 !important;
}
.img-post{
	width:60%;
	height:auto;
}
.modal.modal-fixed-footer {
    height: auto !important;
}
.card .card-reveal {
    background-color: grey !important;
    width: auto !important;
	padding: 15px !important;
    overflow-y: auto;
    left: auto !important;
    right: 0;
}
.card .card-reveal li a{
    color:white !important;
}

.card .card-reveal ul li:hover{
    background-color: black !important;
	cursor: pointer;
}

.activator{
	cursor: pointer;
}

pre{
	white-space: pre-wrap !important;
	word-wrap: break-word !important;
}
.jobs-card:hover{
	box-shadow: 0 0 0 1px rgba(0,0,0,.15), 0 2px 3px rgba(0,0,0,.2), 0 2px 3px rgba(0,0,0,.2);
	cursor: pointer;
}

</style>
	<?php include('navbar.php');?>
	<div class="section">
		<div class="container" style="width:80%">
			<div class="row" style="margin-top:50px">
				<div class="col s12 m12 l12 ">
					<div class="card">
						<?php foreach($companies as $item){?>
						<div class="card-image <?php if($item["cover_url"] == ""){echo "blue"; }; ?> darken-4" style="height:90px;<?php if($item["cover_url"] != ""){echo "background:url(".$item["cover_url"].");"; } ?>">
						</div>
						<div class="circle" style="position:absolute;height:100px;width:100px;background-color:white;top:40px;left:calc(50% - 50px)">
						<?php 
						if($item["logo_url"] != "") { ?>
								<img src="<?php echo $item["logo_url"]; ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:5px">
						<?php } else { ?>
								<img src="<?php echo base_url('assets/images/avatar.png'); ?>" class="circle responsive-img valign profile-image blue darken-2" style="width:90%;height:90%;margin:5px">
						<?php } ?>
						</div>
						<div class="card-content center" style="margin-top:12px">
							<div class="row" style="margin-bottom:10px !important;">
								<a href="http://localhost/bsd2/CProfile/index/<?php echo $company; ?>"><h5><b><?php
									//menampilkan nama
														// echo $_SESSION["user_first_name"];
														// if ($_SESSION["user_last_name"] != "") {
															// echo " " . $_SESSION["user_last_name"];
														// }
										// var_dump($item);
										echo $item["company_name"];
									?>
									
									</b></h5>
								</a>
								<div class="divider"></div>
								<p style="color:gray; padding-top:10px;"><small><?php echo $item["company_description"]; ?></small></p>
								<?php
									}
														?>
							</div>
						</div>	
					</div>
				</div>
				
				<div class="preloader-wrapper big active" style="margin-left: -43%; display:none; position: fixed;">
					<div class="spinner-layer spinner-blue-only">
						<div class="circle-clipper left">
							<div class="circle">
							</div>
						</div>
						<div class="gap-patch">
							<div class="circle">
							</div>
						</div>
						<div class="circle-clipper right">
							<div class="circle">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row card" style="text-align: center">
				<p>Jumlah Pengunjung</p>
				<h6 id="jumlah-pengunjung" style="color:gray"><?php echo $ctr_visit?></h6>
			</div>
			<div class="row">
				<div id="chartJobs" class="col s12 m6 l6 card" style="height:420px;"></div>
				<div id="chartApplier" class="col s12 m6 l6 card" style="height:420px;"></div>
			</div>
		</div>
	</div>
	
	<?php include('footer.php');?>
	<script>
	$(document).ready(function() {
		//untuk chart peningkatan job
		Highcharts.stockChart('chartJobs', {
			chart: {
				type: 'spline'
			},
			title: {
				text: 'Peningkatan Jumlah Pekerjaan yang dibuat selama 1 Tahun Terkahir'
			},
			legend: {
				align: 'left',
				verticalAlign: 'top',
				borderWidth: 0
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			},
			rangeSelector : {
				buttons: [{
					type: 'month',
					count: 1,
					text: '1m'
				}, {
					type: 'month',
					count: 3,
					text: '3m'
				}, {
					type: 'all',
					text: 'All'
				}],
				inputEnabled: false,
				selected : 2
			},

			xAxis: {
				type: 'datetime',
				dateTimeLabelFormats: {
					month: '%e. %b',
					year: '%Y'
				},
				title: {
					text: 'Tanggal'
				}
			},
			yAxis: {
				title: {
					text: 'Pekerjaan'
				},
				min: 0,
				opposite:false
			},

			plotOptions: {
				spline: {
					marker: {
						enabled: true
					}
				}
			},
			series: [{
				name: "Pekerja",
				colors: ['#6CF'],
				data: [
					<?php 
						$i = 1;
						$ctr = count($reportJobs);
						foreach($reportJobs as $item) {
							$tahun = substr($item->tgl, 0,4);
							$bulan = substr($item->tgl, 4,2);
							$bulan = $bulan - 1;
							$tgl = substr($item->tgl, 6,2);
							$date = "Date.UTC($tahun, $bulan, $tgl, 00, 00, 00)";
							echo "[$date, ".$item->jml."]";
							if($i != $ctr){echo ",";};
							$i++;
						}
					?>
				]
			}
			],
			tooltip: {
				 pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} {series.name}</b><br/>'
			}
		});
		
		Highcharts.stockChart('chartApplier', {
			chart: {
				type: 'spline'
			},
			title: {
				text: 'Peningkatan Jumlah Pendaftar Pekerjaan selama 1 Tahun Terkahir'
			},
			legend: {
				align: 'left',
				verticalAlign: 'top',
				borderWidth: 0
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			},
			rangeSelector : {
				buttons: [{
					type: 'month',
					count: 1,
					text: '1m'
				}, {
					type: 'month',
					count: 3,
					text: '3m'
				}, {
					type: 'all',
					text: 'All'
				}],
				inputEnabled: false,
				selected : 2
			},

			xAxis: {
				type: 'datetime',
				dateTimeLabelFormats: {
					month: '%e. %b',
					year: '%Y'
				},
				title: {
					text: 'Tanggal'
				}
			},
			yAxis: {
				title: {
					text: 'Pekerja'
				},
				min: 0,
				opposite:false
			},

			plotOptions: {
				spline: {
					marker: {
						enabled: true
					}
				}
			},
			series: [{
				name: "Pekerja",
				colors: ['#6CF'],
				data: [
					<?php 
						$i = 1;
						$ctr = count($reportApplier);
						foreach($reportApplier as $item) {
							$tahun = substr($item->tgl, 0,4);
							$bulan = substr($item->tgl, 4,2);
							$bulan = $bulan - 1;
							$tgl = substr($item->tgl, 6,2);
							$date = "Date.UTC($tahun, $bulan, $tgl, 00, 00, 00)";
							echo "[$date, ".$item->jml."]";
							if($i != $ctr){echo ",";};
							$i++;
						}
					?>
				]
			}
			],
			tooltip: {
				 pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y} {series.name}</b><br/>'
			}
		});
	});
	</script>

</body>
</html>