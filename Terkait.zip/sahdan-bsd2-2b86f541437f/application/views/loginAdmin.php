<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	require('header.php');
?>
<style>
	#logo{
		margin-left:5px;
		font-family: 'Chela One';
	}
	.input-field input:focus {
		 border-bottom: 1px solid black !important;
		 box-shadow: 0 1px 0 0 black !important;
	}
	#regis-title{
		margin:0px;
		font-size:50px;
		text-align:center;
		font-weight:bold;
		font-family: 'Chela One';
	}
	.cont{
		margin-left:30%;
		margin-right:30%;
		width:40%;
		padding-top:2%;
		padding-bottom:5%;
	}
	.form-title{
		margin-top:30px;
	}
	.form-group{
		margin:2%;
		padding-left:10%;
		padding-right:10%;
	}
	#form-regis{
		padding:2%;	
		background-color:white;
	}
	@media only screen and (max-width: 601px){
		.cont{
			width:80%;
			margin-left:10%;
			margin-right:10%;
			padding-bottom:15% !important;
		}
		#form-regis{
			padding-bottom:12%;
		}
	}
	.bio{
		margin-top:0px;
		height:65px;
		padding-top:5px;
	}
	.bio #nama a{
		text-align:center;
		font-weight:600;
		font-size:24pt;
	}
	nav ul li.active{
		border-bottom:1px solid white;
	}
	.container{
		margin-left: -20px;
	}
	@media only screen and (max-width: 768px) {
		.container{
			margin-left: 0px;
		}
	}
	.sidenav .collapsible-body>ul:not(.collapsible)>li.active, .sidenav.sidenav-fixed .collapsible-body>ul:not(.collapsible)>li.active {
		background-color: grey;
	}
	.login input{
		background-color:white !important;
		padding-left:7% !important;
		border-radius: 25px !important;
	}
	.login{
		margin-right:20px;
	}
	.btn-login:hover{
		background-color:white !important;
		color:black;
	}
	#container{
		padding-top: 2%;
	}
</style>
<body>
	<div class="navbar-fixed">
		<nav class="blue darken-4">
			<div class="nav-wrapper container" style="width:100%; text-align: center;">
				<a href="<?php echo base_url('CLogin/loginAdmin'); ?>" id="idLogo" class="brand-logo">
				<b><span class="blue darken-1" style="padding: 0px 5px;border-radius:5px;">Ter</span>kait</b>
				</a>
			</div>
		</nav>
	</div>
	<div id="container">
		<div class="cont card" >
			<div id="regis-title">
				LOGIN ADMIN
			</div>
			<div id="form-regis card-content" style="margin:5%;">
				<form method="post" action="<?php echo base_url('CLogin/checkLoginAdmin');?>">
					<div class="input-field col s12">
						<input id="emailLogin" type="text" name="edEmail" required oninvalid="this.setCustomValidity('Masukkan Nama Depan Anda')" oninput="setCustomValidity('')">
						<label for="emailLogin" >Email</label>
					</div>
					<div class="input-field col s12">
						<input id="passwordLogin" type="password" name="edPassword">
						<label for="passwordLogin" >Kata Sandi</label>
					</div>
					<div style="padding-bottom: 20px; padding-right: 5%;">
						<button class="btn waves-effect waves-light right" type="submit" name="action">Masuk
						</button>
					</div>
				</form>
			</div>
		</div>
		
	</div>
	<!-- Modal yang muncul kalau gagal login-->
	<div id="modal-gagal-login" class="modal modal-fixed-footer" style="height:150px">
                        <div class="modal-content" style="position: relative;height:100px;text-align: center;">
                            <h6>Kombinasi Email/Password tidak ditemukan</h6>
                        </div>
                        <div class="modal-footer">
                            <a href="#" class="modal-close waves-effect waves-green btn indigo darken-4">OK</a>
                        </div>
                    </div>
	<script async>
		$(document).ready(function() {
			
			$('.sidenav').sidenav();
			$('.collapsible').collapsible();
			$(".dropdown-trigger").dropdown({
				coverTrigger: false,
				constrainWidth:false,
				alignment:"right"
			});
			M.updateTextFields();
			$('select').formSelect();
			$("#confPassword").keyup(function() {
				if($("#password").val() != $("#confPassword").val()){
					$(".validErr").show();
				}
				else{
					$(".validErr").hide();
				}
			});
			$(".regis").submit(function(e){
				if($(".validErr").is( ':visible' )){
					e.preventDefault();
				}
			});
			// Jika gagal login akan muncul popup
			var url = window.location.href;
			if(url.indexOf("loginFail") != -1){
				$('#modal-gagal-login').modal();
				$('#modal-gagal-login').modal('open'); 
			}
		});
	</script>
</body>
</html>