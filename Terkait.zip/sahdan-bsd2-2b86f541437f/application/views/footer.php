<footer class="page-footer blue darken-4">
    <div class="footer-copyright hide-on-small-only">
        <p style="margin:auto;">© 2018 Terkait.com | All rights reserved.</p>
    </div>
</footer>