<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MUser_Skills extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectUserSkills($profileID = FALSE)
	{
	$select = $this->db
					->select("t_user_skills.skill_id, t_user_skills.account_id, t_user_skills.status, t_skills.skill_name")
					->from("t_user_skills")
					->join("t_skills","t_user_skills.skill_id = t_skills.skill_id")
					->where("account_id", $profileID)
					->get();
		return $select->result();
	}

	function selectUserSkillsEndorsementCount($profileID)
	{
		$select = $this->db
					->select("t_user_skills.skill_id, t_user_skills.account_id, t_skills.skill_name, COUNT(t_endorsement.skill_id) AS ctr")
					->from("t_user_skills")
					->join("t_skills","t_user_skills.skill_id = t_skills.skill_id")
					->join("t_endorsement","t_user_skills.skill_id = t_endorsement.skill_id AND t_user_skills.account_id = t_endorsement.user_affected_id",'left')
					->where("t_user_skills.account_id", $profileID)
					->group_by("t_user_skills.skill_id, t_user_skills.account_id")
					->get();
		return $select->result();
	}
	
	function selectUserSkillsId($profileID)
	{
		$select = $this->db
					->select("skill_id")
					->from("t_user_skills")
					->where("account_id", $profileID)
					->get();
		return $select->result();
	}
	
	function selectByIdUsers($id)
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->where("user_id", $id)
					->get();
		return $select->result();
	}

	function isSkillOwned($skillId, $accountId)
	{
		$select = $this->db
					->select("skill_id")
					->from("t_user_skills")
					->where("skill_id", $skillId)
					->where("account_id", $accountId)
					->get();
		$result = $select->result_array();
		if(!empty($result)){
			return $result[0]['skill_id'];
		}
	}
	
	function checkLogin($email, $password)
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->where("user_email", $email)
					->where("password", $password)
					->get();
		return $select->result();
	}
	
	function insertSkillUser($dataInsert)
	{
		$this->db->insert("t_user_skills", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateSkillUser($userID, $skillID, $dataUpdate)
	{
		$this->db->where('user_id', $userID);
		$this->db->where('skill_id', $skillID);
		$this->db->update("t_user_skills", $dataUpdate);
		return $this->db->affected_rows();
	}

	function  deleteSkillUser($accountID, $skillID)
	{
		$this->db->where('account_id', $accountID);
		$this->db->where('skill_id', $skillID);
		$this->db->delete('t_user_skills');
		return $this->db->affected_rows();
	}
}