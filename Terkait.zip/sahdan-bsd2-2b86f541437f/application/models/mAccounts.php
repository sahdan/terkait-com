<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MAccounts extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllAccounts()
	{
		$select = $this->db
					->select('*')
					->from("t_accounts")
					->order_by("account_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_accounts")
					->get();
		return $select->result();
	}
	
	function selectByIdAccounts($id)
	{
		$select = $this->db
					->select('*')
					->from("t_accounts")
					->where("account_id", $id)
					->get();
		return $select->result();
	}
	
	function selectAccountType($id)
	{
		$select = $this->db
					->select('account_type')
					->from("t_accounts")
					->where("account_id", $id)
					->get();
		return $select->row()->account_type;
	}
	
	function selectReport($type)
	{
		$select = $this->db
					->select('DATE_FORMAT(created_at2, "%Y%m%d") AS tgl, COUNT(*) AS jml')
					->from("t_accounts")
					->where('account_type = "'.$type.'" AND created_at2 > DATE_SUB(CURDATE(), INTERVAL 1 YEAR)')
					->group_by('DATE_FORMAT(created_at2, "%Y%m%d")')
					->get();
		return $select->result();
	}
	
	function selectReportMontly($bln)
	{
		if($bln == "0"){
			$select = $this->db
						->select('account_type, count(account_type) as jml')
						->from("t_accounts")
						->where('DATE_FORMAT(created_at2, "%Y%m")= DATE_FORMAT(now(), "%Y%m")')
						->group_by('account_type')
						->order_by('account_type', 'DESC')
						->get();
			return $select->result();
		}else{
			$select = $this->db
						->select('account_type, count(account_type) as jml')
						->from("t_accounts")
						->where('DATE_FORMAT(created_at2, "%Y%m")= DATE_FORMAT("'.$bln.'", "%Y%m")')
						->group_by('account_type')
						->order_by('account_type', 'DESC')
						->get();
			return $select->result();
		}
		
	}
	
	function selectCtrVisit($id)
	{
		$select = $this->db
					->select('ctr_visit')
					->from("t_accounts")
					->where("account_id", $id)
					->get();
		return $select->row()->ctr_visit;
	}
	
	function insertAccounts($dataInsert)
	{
		$this->db->insert("t_accounts", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateAccounts($id, $dataInsert)
	{
		$this->db->where('account_id', $id);
		$this->db->update("t_accounts", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateCtrAccount($id)
	{
		// $this->db->where('account_id', $id);
		// $this->db->set('ctr_visit', 'ctr_visit+1');
		// $this->db->update("t_accounts");
		// return $this->db->affected_rows();
		return $this->db->query("UPDATE t_accounts SET ctr_visit=ctr_visit+1 WHERE account_id = " .$id );
	}

	function delete($accountId){
		$this->db->where('account_id', $accountId);
		$this->db->set('status2', "0");
		$this->db->update("t_accounts");
		return $this->db->affected_rows();
	}
}