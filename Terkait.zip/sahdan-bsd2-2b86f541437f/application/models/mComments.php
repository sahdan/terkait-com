<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MComments extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllComment()
	{
		$select = $this->db
					->select('*')
					->from("t_comments c")
					->join('t_users u', 'u.user_id = p.account_id')
					->join('t_activities a', 'a.activity_id = comment_id')
                    ->where("a.status", 1)
					->order_by("comment_id", "desc")
					->get();
		return $select->result();
	}
	
	function selectByIdPost($id)
	{
		$select = $this->db
					->select('c.comment_id, c.image_link, c.comment_content, c.account_id, u.user_first_name, u.user_last_name, u.photo_url, cp.company_name, cp.logo_url')
					->from("t_comments c")
					->join('t_users u', 'u.user_id = c.account_id', 'left')
					->join('t_companies cp', 'cp.company_id = c.account_id', 'left')
					->join('t_activities a', 'a.activity_id = comment_id')
                    ->where("a.status", 1)
					->where("parent_activity_id", $id)
					->order_by("comment_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectByIdComment($id)
	{
		$select = $this->db
					->select('c.comment_id, c.image_link, c.comment_content, c.account_id, u.user_first_name, u.user_last_name, u.photo_url, cp.company_name, cp.logo_url')
					->from("t_comments c")
					->join('t_users u', 'u.user_id = c.account_id', 'left')
					->join('t_companies cp', 'cp.company_id = c.account_id', 'left')
					->join('t_activities a', 'a.activity_id = comment_id')
                    ->where("a.status", 1)
					->where("comment_id", $id)
					->get();
		return $select->result();
	}
	
	function selectByIdUser($id, $idUser)
	{
		$select = $this->db
					->select('c.comment_id, c.image_link, c.comment_content, c.account_id, u.user_first_name, u.user_last_name, u.photo_url, cp.company_name, cp.logo_url')
					->from("t_comments c")
					->join('t_users u', 'u.user_id = c.account_id', 'left')
					->join('t_companies cp', 'cp.company_id = c.account_id', 'left')
					->join('t_activities a', 'a.activity_id = comment_id')
                    ->where("a.status", 1)
					->where("parent_activity_id", $id)
					->where("c.account_id", $idUser)
					->order_by("comment_id", "desc")
					->limit(1)
					->get();
		// $select = $this->db->query("SELECT `c`.`comment_id`, `c`.`image_link`, `c`.`comment_content`, `c`.`account_id`, `u`.`user_first_name`, `u`.`user_last_name` FROM `t_comments` `c` JOIN `t_users` `u` ON `u`.`user_id` = `c`.`account_id` WHERE `parent_activity_id` = '23' AND `account_id` = '2' ORDER BY `comment_id` DESC LIMIT 1");
		return $select->result();
	}
	
	function insertComment($dataInsert)
	{
		$this->db->insert("t_comments", $dataInsert);
		return $this->db->affected_rows();
	}
	function updateComment($id, $dataInsert)
	{
		$this->db->where('comment_id', $id);
		$this->db->update("t_comments", $dataInsert);
		return $this->db->affected_rows();
	}
}