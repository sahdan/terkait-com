<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MActivities extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllActivities()
	{
		$select = $this->db
					->select('*')
					->from("t_activities")
					->order_by("activity_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_activities")
					->get();
		return $select->result();
	}
	
	function selectByIdActivities($id)
	{
		$select = $this->db
					->select('*')
					->from("t_activities")
					->where("activity_id", $id)
					->get();
		return $select->result();
	}
	
	function selectReportActivity($type)
	{
		$select = $this->db
					->select('DATE_FORMAT(created_at, "%Y%m%d") AS tgl, COUNT(*) AS jml')
					->from("t_activities")
					->where("activity_type = '$type' AND created_at > DATE_SUB(CURDATE(), INTERVAL 1 YEAR)")
					->group_by('DATE_FORMAT(created_at, "%Y%m%d")')
					->get();
		return $select->result();
	}
	
	function insertActivities($dataInsert)
	{
		$this->db->insert("t_activities", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateActivities($id, $dataInsert)
	{
		$this->db->where('activity_id', $id);
		$this->db->update("t_activities", $dataInsert);
		return $this->db->affected_rows();
	}

	function disableActivities($id)
    {
        $status = array(
            'status' => '0'
    );
        $this->db->where('activity_id', $id);
        $this->db->update("t_activities", $status);
    }
}