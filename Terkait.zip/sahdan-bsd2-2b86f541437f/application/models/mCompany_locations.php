<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MCompany_locations extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectCompanyLocations($companyId)
	{
		$select = $this->db
					->select("company_location_id, account_id, company_address, suite_apt, city, state, zip_code2, building_name, is_main_office, status3")
					->from("t_company_locations")
					->where("account_id", $companyId)
					->where("status3", "1")
					->order_by("is_main_office", 'desc')
					->get();
		return $select->result();
	}

	function selectCompanyLocation($companyLocationId)
	{
		$select = $this->db
					->select("company_location_id, account_id, company_address, suite_apt, city, state, zip_code2, building_name, is_main_office, status3")
					->from("t_company_locations")
					->where("company_location_id", $companyLocationId)
					->get();
		return $select->result();
	}

	function selectMaxId()
	{
		$select = $this->db
		->select_max("company_location_id")
		->from('t_company_locations')
		->get();
		return $select->result_array();
	}

	function mainOfficeId($companyId)
	{
		$select = $this->db
		->select("company_location_id")
		->from('t_company_locations')
		->where('account_id', $companyId)
		->where('is_main_office', '1')
		->get();
		return $select->result_array();
	}

	function removeMainOffice($companyId, $data)
	{
		$this->db->where('account_id', $companyId);
		$this->db->where('is_main_office', "1");
		$this->db->update('t_company_locations', $data);
		return $this->db->affected_rows();
	}

	function insert($data){
		$this->db->insert("t_company_locations", $data);
		return $this->db->affected_rows();
	}

	function update($locationId, $data){
		$this->db->where('company_location_id', $locationId);
		$this->db->update("t_company_locations", $data);
		return $this->db->affected_rows();
	}

	function deleteLocation($locationId)
	{
		$this->db->where('company_location_id', $locationId);
		$this->db->where('is_main_office !=', '1');
		$this->db->delete("t_company_locations");
		return $this->db->affected_rows();
	}
}