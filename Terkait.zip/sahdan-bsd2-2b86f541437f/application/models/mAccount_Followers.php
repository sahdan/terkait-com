<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MAccount_Followers extends CI_Model {
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }
    
    function isFollowing($loginId, $profileId){
        $select = $this->db
            ->select("user_following_id","account_followed_id")
            ->from("t_account_followers")
            ->where("user_following_id", $loginId)
            ->where("account_followed_id", $profileId)
            ->get();
        return $select->num_rows();
    }

    function followCount($accountId){
        $select = $this->db
            ->select("user_following_id","account_followed_id")
            ->from("t_account_followers")
            ->where("account_followed_id", $accountId)
            ->get();
        return $select->num_rows();
    }

    function insertFollow($dataInsert){
        $this->db->insert("t_account_followers", $dataInsert);
		return $this->db->affected_rows();
    }

    function deleteFollow($loginId, $profileId)
	{
        $this->db->where("user_following_id", $loginId);
        $this->db->where("account_followed_id", $profileId);
		$this->db->delete("t_account_followers");
		return $this->db->affected_rows();
	}
}