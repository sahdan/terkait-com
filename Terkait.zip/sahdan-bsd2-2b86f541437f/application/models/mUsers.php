<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MUsers extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllUsers()
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->order_by("user_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_users")
					->get();
		return $select->result();
	}
	
	function selectByIdUsers($id)
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->where("user_id", $id)
					->get();
		return $select->result();
	}

	function selectSearchUser($keyword)
	{
		$select = $this->db			
		->select("user_id, headline, user_first_name, user_former_name, user_last_name, user_email, media_url, photo_url, summary, zip_code")
		->from("t_users")
		->group_start()
			->where("'".$keyword[0]."' LIKE CONCAT('%', user_first_name, '%')")
			->or_where("'".$keyword[0]."' LIKE CONCAT('%', user_last_name, '%')")
			->or_where("'".$keyword[0]."' LIKE CONCAT('%', user_former_name, '%')")
		->group_end()
		->or_group_start()
			->like("user_first_name", $keyword[0])
			->or_like("user_last_name", $keyword[0])
			->or_like("user_former_name", $keyword[0])
		->group_end();
		if(count($keyword) > 1){
			foreach($keyword as $word){
				$this->db
				->or_group_start()
					->where("'".$keyword[0]."' LIKE CONCAT('%', user_first_name, '%')")
					->or_where("'".$keyword[0]."' LIKE CONCAT('%', user_last_name, '%')")
					->or_where("'".$keyword[0]."' LIKE CONCAT('%', user_former_name, '%')")
				->group_end()
				->or_group_start()
					->like("user_first_name", $keyword[0])
					->or_like("user_last_name", $keyword[0])
					->or_like("user_former_name", $keyword[0])
				->group_end();
			}
		}
		// ->like("CONCAT(user_first_name,user_last_name)", $keyword[0]);
		// if(count($keyword) > 1){
		// 	foreach($keyword as $word){
		// 		$this->db->or_like("CONCAT(user_first_name,user_last_name)", $word);
		// 	}
		// }
		$select = $this->db->get();
		return $select->result();
	}

	function selectSearchUsersName($param){
		$select = $this->db
					->select("concat(user_first_name,' ',user_last_name) AS suggestion")
					->from("t_users")
					->like("user_first_name", $param)
					->or_like("user_last_name", $param)
					->or_like("user_former_name", $param)
					->get();
		return $select->result();
	}

	function selectUser($id)
	{
		$select = $this->db
					->select("user_id, headline, user_first_name, user_former_name, user_last_name, user_email, media_url, photo_url, summary, zip_code")
					->from("t_users")
					->where("user_id", $id)
					->get();
		return $select->row();
	}

	function selectIdByName($name)
	{
		$select = $this->db
					->select("user_id, headline, user_first_name, user_former_name, user_last_name, user_email, media_url, photo_url, summary, zip_code")
					->from("t_users")
					->where("CONCAT(user_first_name,' ',user_last_name) = ", $name)
					->get();
		return $select->result_array();
	}
	
	function checkLogin($email, $password)
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->where("user_email", $email)
					->where("password", $password)
					->get();
		return $select->result();
	}
	
	function insertUsers($dataInsert)
	{
		$this->db->insert("t_users", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateUsers($id, $dataUpdate)
	{
		$this->db->where('user_id', $id);
		$this->db->update("t_users", $dataUpdate);
		return $this->db->affected_rows();
	}
}