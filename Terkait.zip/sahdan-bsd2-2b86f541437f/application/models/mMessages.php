<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MMessages extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllMessage()
	{
		$select = $this->db
					->select('*')
					->from("t_messages")
					->order_by("message_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectAllMessageByConversationId($id)
	{
		$select = $this->db
					->select('message_id, message_content, conversation_id, user_id, CONCAT(user_first_name, " " ,user_last_name) as name')
					->from("t_messages m")
					->join('t_users u', 'u.user_id = m.sender_user_id')
					->where("conversation_id", $id)
					->order_by("message_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectByIdUser($id, $idUser)
	{
		$select = $this->db
					->select('message_id, message_content, conversation_id, user_id, CONCAT(user_first_name, " " ,user_last_name) as name')
					->from("t_messages m")
					->join('t_users u', 'u.user_id = m.sender_user_id')
					->where("conversation_id", $id)
					->where("m.sender_user_id", $idUser)
					->order_by("message_id", "desc")
					->limit(1)
					->get();
		return $select->result();
	}
	
	function selectAllMessageByIdUserLastSeen($idUser)
	{
		$this->db->cache_off();
		$select = $this->db
					->select('message_content, c.conversation_id, (SELECT GROUP_CONCAT(" ", `user_first_name`, " ", user_last_name) AS nama FROM t_conversation_participants tp JOIN `t_users` `u` ON `u`.`user_id` = `tp`.`user_id` WHERE tp.conversation_id = c.conversation_id GROUP BY `tp`.`conversation_id`) AS name, timestamp, (SELECT tp.last_seen FROM t_conversation_participants tp WHERE tp.user_id = '.$idUser.' AND tp.conversation_id = c.conversation_id) AS last_seen')
					->from("t_conversation_participants c")
					->join('t_users u', 'u.user_id = c.user_id')
					->join('t_activities a', 'a.activity_id = c.conversation_id')
					->join('t_messages m', 'm.conversation_id = c.conversation_id', 'left')
					->where("c.conversation_id in (SELECT conversation_id FROM t_conversation_participants WHERE user_id = $idUser)")
					->where("a.status", 1)
					->group_by("c.conversation_id")
					->order_by("m.message_id", "desc")
					->order_by("c.conversation_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_messages")
					->get();
		return $select->result();
	}
	
	function selectByIdMessage($id)
	{
		$select = $this->db
					->select('*')
					->from("t_messages")
					->where("message_id", $id)
					->get();
		return $select->result();
	}
	
	function insertMessage($dataInsert)
	{
		$this->db->insert("t_messages", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateMessage($id, $dataInsert)
	{
		$this->db->where('message_id', $id);
		$this->db->update("t_messages", $dataInsert);
		return $this->db->affected_rows();
	}
}