<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MUser_Connections extends CI_Model {
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }
    
    function countConnection($userId){
        // $select = $this->db
        //     ->select("user_affected_id")
        //     ->from("t_user_connections")
        //     ->where("user_in_action_id", $userId)
        //     ->where("status2", "1")
        //     ->get();
        // $result = array();
        // foreach ($select->result_array() as $i)
        // {
        //     $result[] = $i["user_affected_id"];
        // }
        // $select = $this->db->distinct()
        //     ->select("user_in_action_id, user_affected_id")
        //     ->from("t_user_connections")
        //     ->group_start()
        //         ->where("user_in_action_id", $userId)
        //         ->or_where("user_affected_id",$userId)
        //     ->group_end()
        //     ->where("status2", "1")
        //     ->where_not_in("user_in_action_id", $result)
        //     ->get();
        $select = $this->db
            ->select("user_in_action_id, user_affected_id, status2, timestamp2")
            ->from("t_user_connections")
			->join('t_users u', 'u.user_id = user_affected_id or u.user_id = user_in_action_id')
            ->where("status2", "1")
            ->where("user_id !=", $userId)
            ->group_start()
                ->where("user_in_action_id", $userId)
                ->or_where("user_affected_id", $userId)
            ->group_end()
			->group_by('user_id')
            ->get();
        return $select->num_rows();
    }
    
    function getRequestCount($loginId) {
        $select = $this->db
            ->select("user_in_action_id, user_affected_id, status2, timestamp2")
            ->from("t_user_connections")
            ->where("status2", "0")
            ->where("user_affected_id", $loginId)
            ->get();
        return $select->num_rows();
    }

    function selectUsersPendingRequest($user_id)
	{
        $select = $this->db
            ->select("user_in_action_id AS user_id, CONCAT(u.user_first_name, ' ', u.user_last_name) AS name, photo_url, headline, timestamp2")
            ->from("t_user_connections uc")
            ->join('t_users u', 'u.user_id = uc.user_in_action_id')
            ->where("uc.status2", "0")
            ->where("uc.user_affected_id", $user_id)
            ->get();
        return $select->result();
        
        
	}

    function getStatusConnection($loginId, $profileId){
        $select = $this->db
            ->select("user_in_action_id, user_affected_id, status2, timestamp2")
            ->from("t_user_connections")
            ->group_start()
                ->where("user_in_action_id", $loginId)
                ->where("user_affected_id", $profileId)
            ->group_end()
            ->or_group_start()
                ->where("user_in_action_id", $profileId)
                ->where("user_affected_id",$loginId)
            ->group_end()
            ->order_by('timestamp2','desc')
            ->limit(1)
            ->get();
        return $select->result_array();
    }

    function insertConnection($dataInsert){
        $this->db->insert("t_user_connections", $dataInsert);
		return $this->db->affected_rows();
    }

    function updateConnection($loginId, $profileId, $dataUpdate)
	{
        $this->db
            ->group_start()
                ->where("user_in_action_id", $loginId)
                ->where("user_affected_id", $profileId)
            ->group_end()
            ->or_group_start()
                ->where("user_in_action_id", $profileId)
                ->where("user_affected_id",$loginId)
            ->group_end();
		// $this->db->where('user_in_action_id', $loginId);
		// $this->db->where('user_affected_id', $profileId);
		$this->db->update("t_user_connections", $dataUpdate);
		return $this->db->affected_rows();
    }
    
    function deleteConnection($loginId, $profileId)
	{
        $this->db
            ->group_start()
                ->where("user_in_action_id", $loginId)
                ->where("user_affected_id", $profileId)
            ->group_end()
            ->or_group_start()
                ->where("user_in_action_id", $profileId)
                ->where("user_affected_id",$loginId)
            ->group_end();
		$this->db->delete("t_user_connections");
		return $this->db->affected_rows();
    }
    
    function selectAllConnections($id)
	{
		// $select = $this->db
					// ->select('user_id, concat(user_first_name, " ", user_last_name) as name')
					// ->from("t_user_connections uc")
					// ->join('t_users u', 'u.user_id = uc.user_affected_id or u.user_id = uc.user_in_action_id')
					// ->where("user_in_action_id = $id or user_affected_id = $id")
					// ->where("u.user_id = $id")
					// ->order_by("user_id", "asc")
					// ->get();
		$select = $this->db
            ->select('user_id, concat(user_first_name, " ", user_last_name) as name, u.photo_url, u.headline')
            ->from("t_user_connections")
			->join('t_users u', 'u.user_id = user_affected_id or u.user_id = user_in_action_id')
            ->where("status2", "1")
            ->where("user_id !=", $id)
					
            ->group_start()
                ->where("user_in_action_id", $id)
                ->or_where("user_affected_id", $id)
            ->group_end()
			->group_by('user_id')
            ->get();
		return $select->result();
    }
    
    function selectSugestionByIdUser($user_id)
	{
		$select = $this->db
            ->select("user_affected_id AS user_id, CONCAT(u.user_first_name, ' ', u.user_last_name) AS name, count(*) as ctr, photo_url")
            ->from("t_user_connections uc")
			->join('t_users u', 'u.user_id = uc.user_affected_id')
            ->where("user_in_action_id IN (SELECT user_id FROM t_user_connections uc JOIN t_users u ON (u.user_id = uc.user_affected_id) WHERE user_in_action_id = '$user_id' GROUP BY user_id)")
            ->where("user_id NOT IN (SELECT user_id FROM t_user_connections uc JOIN t_users u ON (u.user_id = uc.user_affected_id OR u.user_id = uc.user_in_action_id) WHERE user_affected_id = '$user_id' OR user_in_action_id = '$user_id' GROUP BY user_id)")
			->group_by('user_affected_id')
			->order_by("count(*)", "desc")
			->limit(5)
            ->get();
		return $select->result();
    }
    
    function selectAllSugestionByIdUser($user_id)
	{
		$select = $this->db
            ->select("user_affected_id AS user_id, CONCAT(u.user_first_name, ' ', u.user_last_name) AS name, count(*) as ctr, photo_url, headline")
            ->from("t_user_connections uc")
			->join('t_users u', 'u.user_id = uc.user_affected_id')
            ->where("user_in_action_id IN (SELECT user_id FROM t_user_connections uc JOIN t_users u ON (u.user_id = uc.user_affected_id) WHERE user_in_action_id = '$user_id' GROUP BY user_id)")
            ->where("user_id NOT IN (SELECT user_id FROM t_user_connections uc JOIN t_users u ON (u.user_id = uc.user_affected_id OR u.user_id = uc.user_in_action_id) WHERE user_affected_id = '$user_id' OR user_in_action_id = '$user_id' GROUP BY user_id)")
			->group_by('user_affected_id')
			->order_by("count(*)", "desc")
            ->get();
		return $select->result();
	}
}