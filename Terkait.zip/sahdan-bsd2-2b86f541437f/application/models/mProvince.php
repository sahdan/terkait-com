<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MProvince extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllProvinces()
	{
		$select = $this->db
					->select("p.province_id, p.province_name, p.province_status")
                    ->from("t_province p")
                    ->where("p.province_status", "1")
					->get();
		return $select->result();
	}
}