<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MCompanies_users extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectByUserId($userId)
	{
		$select = $this->db
					->select("c.company_id, c.company_name, u.user_id, concat(u.user_first_name,' ',u.user_last_name) user_name, cu.status, c.logo_url, a.created_at2")
                    ->from("t_companies_users cu")
                    ->join("t_users u", "u.user_id = cu.user_id")
					->join("t_companies c", "c.company_id = cu.company_id")
					->join("t_accounts a", "a.account_id = cu.company_id")
					->where("u.user_id", $userId)
					->group_start()
						->where("cu.status", "1")
						->or_where("cu.status", "0")
					->group_end()
					->order_by("a.created_at2", "desc")
					->get();
		return $select->result();
	}

	function selectByCompanyId($companyId){
		$select = $this->db
					->select("c.company_id, c.company_name, u.user_id, concat(u.user_first_name,' ',u.user_last_name) user_name, cu.status, c.logo_url")
                    ->from("t_companies_users cu")
                    ->join("t_users u", "u.user_id = cu.user_id")
                    ->join("t_companies c", "c.company_id = cu.company_id")
					->where("cu.company_id", $companyId)
					->where("cu.status", "1")
					->or_where("cu.status", "0")
					->get();
		return $select->result_array();
	}

	function selectAdmin($companyId){
		$select = $this->db
					->select("c.company_id, c.company_name, u.user_id, concat(u.user_first_name,' ',u.user_last_name) user_name, cu.status, c.logo_url, u.photo_url")
                    ->from("t_companies_users cu")
                    ->join("t_users u", "u.user_id = cu.user_id")
                    ->join("t_companies c", "c.company_id = cu.company_id")
					->where("cu.company_id", $companyId)
					->where("cu.status", "0")
					->get();
		return $select->result_array();
	}

	function selectSuperAdmin($companyId){
		$select = $this->db
					->select("c.company_id, c.company_name, u.user_id, concat(u.user_first_name,' ',u.user_last_name) user_name, cu.status, c.logo_url")
                    ->from("t_companies_users cu")
                    ->join("t_users u", "u.user_id = cu.user_id")
                    ->join("t_companies c", "c.company_id = cu.company_id")
					->where("cu.company_id", $companyId)
					->where("cu.status", "1")
					->get();
		return $select->result_array();
	}

	function selectByBothId($userId, $companyId){
		$select = $this->db
					->select("c.company_id, c.company_name, u.user_id, concat(u.user_first_name,' ',u.user_last_name) user_name, cu.status, a.created_at2")
                    ->from("t_companies_users cu")
                    ->join("t_users u", "u.user_id = cu.user_id")
					->join("t_companies c", "c.company_id = cu.company_id")
					->join("t_accounts a", "a.account_id = cu.company_id")
					->where("cu.user_id", $userId)
					->where("cu.company_id", $companyId)
					->get();
		return $select->result_array();
	}

	function insert($data){
		$this->db->insert("t_companies_users", $data);
		return $this->db->affected_rows();
	}

	function deleteByCompany($companyId){
		$this->db->where('company_id', $companyId);
		$this->db->set('status', "-1");
		$this->db->update("t_companies_users");
		return $this->db->affected_rows();
	}

	function delete($userId, $companyId){
		$this->db->where('user_id', $userId);
		$this->db->where('company_id', $companyId);
		$this->db->delete('t_companies_users');
		return $this->db->affected_rows();
	}
}