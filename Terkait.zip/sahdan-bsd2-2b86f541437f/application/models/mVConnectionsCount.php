<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MVConnectionsCount extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectJumKoneksi($id)
	{
		$select = $this->db
					->select("COUNT(*) as jum")
                    ->from("v_connections_count")
                    ->where("USER_IN_ACTION_ID", $id)
					->get();
		return $select->result();
	}
}