<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MJobsSkills extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllJobSkill()
	{
		$select = $this->db
					->select('*')
					->from("t_jobs_skills")
					->get();
		return $select->result();
	}
	
	function selectJobSkillById($id)
	{
		$select = $this->db
					->select('js.job_id, js.skill_id, s.skill_name')
					->from("t_jobs_skills js")
					->join("t_skills s", "js.skill_id = s.skill_id")
					->where("js.job_id", $id)
					->get();
		return $select->result();
	}
	
	function selectJobSkillOwnedByUser($userId, $jobId)
	{
		$select = $this->db
			->select('js.job_id, js.skill_id, s.skill_name, IF(sub_us.account_id IS NULL, 0, 1) is_skill_owned')
			->from("t_jobs_skills js")
			->join("t_skills s", "js.skill_id = s.skill_id")
			->join("(SELECT us.account_id,us.skill_id FROM t_user_skills us WHERE us.account_id = $userId) sub_us", "js.skill_id = sub_us.skill_id", "left")
			->where("js.job_id", $jobId)
			->get();
		return $select->result();
	}

	function insertJobSkill($dataInsert)
	{
		$this->db->insert("t_jobs_skills", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function deleteJobSkill($id)
	{
		$this->db->where('job_id', $id);
		$this->db->delete('t_jobs_skills');
		return $this->db->affected_rows();
	}

	function selectUsersByJobSkills($jobId) {
		$select = $this->db
			->select("us.ACCOUNT_ID as user_id, COUNT(us.SKILL_ID) as 'num'")
			->from("t_jobs_skills js")
			->join("t_user_skills us", "js.skill_id = us.skill_id")
			->group_by("us.ACCOUNT_ID")
			->where("js.job_id", $jobId)
			->get();
		return $select->result();
	}
	
}