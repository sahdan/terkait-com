<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MLikes extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllLikes()
	{
		$select = $this->db
					->select('*')
					->from("t_likes")
					->get();
		return $select->result();
	}
	
	function insertLikes($dataInsert)
	{
		$this->db->insert("t_likes", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateLikes($id, $dataInsert)
	{
		$this->db->where('like_id', $id);
		$this->db->update("t_likes", $dataInsert);
		return $this->db->affected_rows();
	}
}