<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MConversation extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllConversation()
	{
		$select = $this->db
					->select('*')
					->from("t_conversation_participants")
					->order_by("conversation_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectAllConversationByIdUser($idUser)
	{
		$this->db->cache_off();
		$select = $this->db
					->select('(SELECT message_id FROM t_messages tm WHERE tm.conversation_id = c.conversation_id ORDER BY message_id DESC LIMIT 1) AS message_ids,(SELECT message_content FROM t_messages tm WHERE tm.conversation_id = c.conversation_id ORDER BY message_id DESC LIMIT 1) AS message_content, c.conversation_id, (SELECT GROUP_CONCAT(" ", `user_first_name`, " ", user_last_name) AS nama FROM t_conversation_participants tp JOIN `t_users` `u` ON `u`.`user_id` = `tp`.`user_id` WHERE tp.conversation_id = c.conversation_id GROUP BY `tp`.`conversation_id`) AS name, (SELECT timestamp FROM t_messages m WHERE conversation_id = c.conversation_id ORDER BY timestamp DESC LIMIT 1) AS timestamp, (SELECT tp.last_seen FROM t_conversation_participants tp WHERE tp.user_id = '.$idUser.' AND tp.conversation_id = c.conversation_id) AS last_seen')
					->from("t_conversation_participants c")
					->join('t_users u', 'u.user_id = c.user_id')
					->join('t_activities a', 'a.activity_id = c.conversation_id')
					->join('t_messages m', 'm.conversation_id = c.conversation_id', 'left')
					->where("c.conversation_id in (SELECT conversation_id FROM t_conversation_participants WHERE user_id = $idUser)")
					->where("a.status", 1)
					->group_by("c.conversation_id")
					->order_by("timestamp", "desc")
					->order_by("message_ids", "desc")
					->order_by("c.conversation_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectCountMsg($idUser){
		$this->db->cache_off();
		$select = $this->db
					->select('(SELECT timestamp FROM t_messages m WHERE conversation_id = c.conversation_id ORDER BY timestamp DESC LIMIT 1) AS timestamp, (SELECT tp.last_seen FROM t_conversation_participants tp WHERE tp.user_id = '.$idUser.' AND tp.conversation_id = c.conversation_id) AS last_seen')
					->from("t_conversation_participants c")
					->join('t_activities a', 'a.activity_id = c.conversation_id')
					->where("c.conversation_id in (SELECT conversation_id FROM t_conversation_participants WHERE user_id = $idUser)")
					->where("a.status", 1)
					->group_by("c.conversation_id")
					->get();
		return $select->result();
	}
	
	function selectConversationIfExistByIdUser($user_id, $other_user){
		$this->db->cache_off();
		$this->db->distinct();
		$select = $this->db
					->select('conversation_id, (SELECT COUNT(*) AS USER FROM t_conversation_participants t WHERE t.conversation_id = tcp.conversation_id GROUP BY conversation_id) AS count')
					->from("t_conversation_participants tcp")
					->join('t_activities a', 'a.activity_id = tcp.conversation_id')
					->where("conversation_id IN (SELECT conversation_id AS USER FROM t_conversation_participants WHERE user_id = $user_id GROUP BY conversation_id)")
					->where("conversation_id IN (SELECT conversation_id AS USER FROM t_conversation_participants WHERE user_id = $other_user GROUP BY conversation_id)")
					->where("a.status", 1)
					->where("(SELECT COUNT(*) FROM t_conversation_participants t WHERE t.conversation_id = tcp.conversation_id GROUP BY conversation_id) = 2")
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_conversation_participants")
					->get();
		return $select->result();
	}
	
	function selectByIdConversation($id)
	{
		$select = $this->db
					->select('*')
					->from("t_conversation_participants")
					->where("conversation_id", $id)
					->get();
		return $select->result();
	}
	
	function selectByIdConversationAndUser($id, $user_id)
	{
		$select = $this->db
					->select('*')
					->from("t_conversation_participants")
					->where("conversation_id", $id)
					->where("user_id", $user_id)
					->get();
		return $select->result();
	}
	
	function insertConversation($dataInsert)
	{
		$this->db->insert("t_conversation_participants", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateConversation($id, $dataInsert)
	{
		$this->db->where('conversation_id', $id);
		$this->db->update("t_conversation_participants", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateConversationLastSeen($id, $idUser, $dataInsert)
	{
		$this->db->where('conversation_id', $id);
		$this->db->where('user_id', $idUser);
		$this->db->update("t_conversation_participants", $dataInsert);
		return $this->db->affected_rows();
	}

	function disableConversation($id)
    {
        $status = array(
            'status' => '0'
    );
        $this->db->where('conversation_id', $id);
        $this->db->update("t_conversation_participants", $status);
    }
}