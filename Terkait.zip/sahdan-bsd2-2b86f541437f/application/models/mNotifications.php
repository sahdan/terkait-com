<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MNotifications extends CI_Model {
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }

    function selectNewNotifications($loginID) {
		$this->db->cache_off();
        $select = $this->db
                    ->select('*')
                    ->from('v_new_notif_act')
                    ->where('owner_id', $loginID)
                    ->get();
		return $select->result();
    }

    function selectOldNotifications($loginID) {
		$this->db->cache_off();
        $select = $this->db
                    ->select('*')
                    ->from('v_old_notif_act')
                    ->where('owner_id', $loginID)
                    ->limit(10)
                    ->get();
		return $select->result();
    }
    
    function updateLastSeen($loginID) {
        $this->db->cache_off();
		$update = $this->db->query('UPDATE t_notifications tn JOIN t_notification_objects tno 
            ON tn.notif_obj_id = tno.notif_obj_id 
        SET tn.LAST_SEEN = NOW() WHERE tn.USER_ID ='.$loginID.' AND tno.OBJECT_TYPE != "Lowongan Kerja"');
		return $update;
        
    }

    function updateLastSeenJob($loginID) {
        $this->db->cache_off();
		$update = $this->db->query('UPDATE t_notifications tn JOIN t_notification_objects tno 
            ON tn.notif_obj_id = tno.notif_obj_id 
        SET tn.LAST_SEEN = NOW() WHERE tn.USER_ID ='.$loginID.' AND tno.OBJECT_TYPE = "Lowongan Kerja"');
		return $update;
        
    }
    
    function selectCountNotif($loginID) {
        $this->db->cache_off();
		$select = $this->db->query('SELECT sna.NOTIF_ACT_ID, sn.NOTIFICATION_ID
        FROM t_notification_actions sna 
        JOIN t_notification_objects sno 
            ON sna.NOTIF_OBJ_ID = sno.NOTIF_OBJ_ID 
        JOIN t_notifications sn 
            ON sno.NOTIF_OBJ_ID = sn.NOTIF_OBJ_ID
        WHERE USER_ID ='.$loginID.' AND sn.LAST_SEEN < sna.TIMESTAMP2 AND sno.OBJECT_TYPE != "Lowongan Kerja"
        ORDER BY NOTIF_ACT_ID');
		return $select->num_rows();
    }

    function selectCountNotifJob($loginID) {
        $this->db->cache_off();
		$select = $this->db->query('SELECT sna.NOTIF_ACT_ID, sn.NOTIFICATION_ID
        FROM t_notification_actions sna 
        JOIN t_notification_objects sno 
            ON sna.NOTIF_OBJ_ID = sno.NOTIF_OBJ_ID 
        JOIN t_notifications sn 
            ON sno.NOTIF_OBJ_ID = sn.NOTIF_OBJ_ID
        WHERE USER_ID ='.$loginID.' AND sn.LAST_SEEN < sna.TIMESTAMP2 AND sno.OBJECT_TYPE = "Lowongan Kerja"
        ORDER BY NOTIF_ACT_ID');
		return $select->num_rows();
    }

    function insertNotifObject($dataInsert) {
        $this->db->insert("t_notification_objects", $dataInsert);
		return $this->db->affected_rows();
    }

    function insertNotif($dataInsert) {
        $this->db->insert("t_notifications", $dataInsert);
		return $this->db->affected_rows();
    }

    function insertNotifAction($dataInsert) {
        $this->db->insert("t_notification_actions", $dataInsert);
		return $this->db->affected_rows();
    }

    function selectMaxNotifObjId() {
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_notification_objects")
					->get();
		return $select->row()->jumlah;
    }
    
    function selectMaxNotifId() {
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_notifications")
					->get();
		return $select->row()->jumlah;
    }

    function selectMaxNotifActId() {
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_notification_actions")
					->get();
		return $select->row()->jumlah;
    }
}