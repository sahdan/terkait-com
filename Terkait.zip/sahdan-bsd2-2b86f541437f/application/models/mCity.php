<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MCity extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllCities()
	{
		$select = $this->db
					->select("c.city_id, c.city_name, c.province_id, c.city_status, p.province_name, p.province_status")
                    ->from("t_city c")
                    ->join("t_province p", "p.province_id = c.province_id")
                    ->where("c.city_status", "1")
                    ->where("p.province_status", "1")
					->get();
		return $select->result();
    }
    
    function selectCities($provinceName){
        $select = $this->db
					->select("c.city_id, c.city_name, c.province_id, c.city_status, p.province_name, p.province_status")
                    ->from("t_city c")
                    ->join("t_province p", "p.province_id = c.province_id")
                    ->where("c.city_status", "1")
                    ->where("p.province_status", "1")
                    ->where("p.province_name", $provinceName)
					->get();
		return $select->result();
    }
}