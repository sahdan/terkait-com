<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MUser_Positions extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectUserPositions($profileID = FALSE)
	{
	$select = $this->db
					->select("t_user_positions.company_id, t_user_positions.user_id, t_user_positions.location, t_user_positions.title, t_user_positions.from_date, t_user_positions.to_date, t_user_positions.currently_work_here, t_user_positions.status, t_companies.company_name, t_companies.logo_url")
					->from("t_user_positions")
					->join("t_companies","t_user_positions.company_id = t_companies.company_id")
					->where("t_user_positions.user_id", $profileID)
					->order_by("from_date", "asc")
					->get();
		return $select->result();
	}

	function selectPosition($profileID = FALSE, $companyID = FALSE)
	{
		$select = $this->db
					->select("t_user_positions.company_id, t_user_positions.user_id, t_user_positions.location, t_user_positions.title, t_user_positions.from_date, t_user_positions.to_date, t_user_positions.currently_work_here, t_user_positions.status, t_companies.company_name")
					->from("t_user_positions")
					->join("t_companies","t_user_positions.company_id = t_companies.company_id")
					->where("t_user_positions.user_id", $profileID)
					->where("t_user_positions.company_id", $companyID)
					->get();
		return $select->row();
	}
	
	function selectByIdUsers($id)
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->where("user_id", $id)
					->get();
		return $select->result();
	}
	
	function checkLogin($email, $password)
	{
		$select = $this->db
					->select('*')
					->from("t_users")
					->where("user_email", $email)
					->where("password", $password)
					->get();
		return $select->result();
	}
	
	function insertPosition($dataInsert)
	{
		$this->db->insert("t_user_positions", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updatePosition($userId, $companyId, $dataUpdate)
	{
		$this->db->where('user_id', $userId);
		$this->db->where('company_id', $companyId);
		$this->db->update("t_user_positions", $dataUpdate);
		return $this->db->affected_rows();
	}

	function deletePosition($userId, $companyId){
		$this->db->where('user_id', $userId);
		$this->db->where('company_id', $companyId);
		$this->db->delete('t_user_positions');
		return $this->db->affected_rows();
	}
}