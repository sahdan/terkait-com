<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MEndorsement extends CI_Model {
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }

    function selectSkillEndorsed($loginID, $profileID)
	{
		$select = $this->db
				->select("skill_id")
				->from("t_endorsement")
				->where("user_in_action_id", $loginID)
				->where("user_affected_id", $profileID)
				->get();
		return $select->result();
	}

	function countEndorsement($userId, $skillId){
		$select = $this->db
				->select("count(*) as ctr")
				->from("t_endorsement")
				->where("user_affected_id", $userId)
				->where("skill_id", $skillId)
				->group_by("user_affected_id","skill_id")
				->get();
		return $select->row("ctr");
	}

    function insertEndorsement($dataInsert){
        $this->db->insert("t_endorsement", $dataInsert);
		return $this->db->affected_rows();
    }
    
    function deleteEndorsement($loginId, $profileId, $skillId)
	{
        $this->db
        ->where("user_in_action_id", $loginId)
		->where("user_affected_id", $profileId)
		->where("skill_id", $skillId);
		$this->db->delete("t_endorsement");
		return $this->db->affected_rows();
    }
}