<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MUser_Educations extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectUserEducations($profileID = FALSE)
	{
		$select = $this->db
					// ->select("t_companies.company_id, t_companies.logo_url, t_companies.company_name, t_user_educations.from_year , t_user_educations.to_year , t_user_educations.academic_degree , t_user_educations.field_of_study, t_user_educations.education_description, t_user_educations.activities_societies")
					->select("t_companies.company_id, t_companies.logo_url, t_companies.company_name, t_user_educations.from_year , t_user_educations.to_year , t_user_educations.academic_degree, t_user_educations.grade, t_user_educations.field_of_study, t_user_educations.education_description, t_user_educations.activities_societies, t_user_educations.education_order, t_universities.status")
					->from("t_user_educations")
					->join("t_companies","t_companies.company_id = t_user_educations.university_id")
					->join("t_universities","t_companies.company_id = t_universities.university_id")
					->where("user_id", $profileID)
					->order_by("from_year", "asc")
					->get();
		return $select->result();
	}

	function selectEducation($profileID = FALSE, $universityID = FALSE, $educationOrder = FALSE)
	{
		//no t_companies.logo_url,
		$select = $this->db
					//->select("t_companies.company_id, t_companies.company_name, t_user_educations.from_year , t_user_educations.to_year , t_user_educations.academic_degree, t_user_educations.grade, t_user_educations.field_of_study, t_user_educations.education_description, t_user_educations.activities_societies")
					->select("t_companies.company_id, t_companies.logo_url, t_companies.company_name, t_user_educations.from_year , t_user_educations.to_year , t_user_educations.academic_degree, t_user_educations.grade, t_user_educations.field_of_study, t_user_educations.education_description, t_user_educations.activities_societies, t_user_educations.education_order, t_universities.status")
					->from("t_user_educations")
					->join("t_companies","t_companies.company_id = t_user_educations.university_id")
					->join("t_universities","t_companies.company_id = t_universities.university_id")
					->where("t_user_educations.user_id", $profileID)
					->where("t_user_educations.university_id", $universityID)
					->where("t_user_educations.education_order", $educationOrder)
					->order_by("from_year", "asc")
					->get();
		return $select->row();
	}

	function selectMaxEducationOrder($profileID = FALSE)
	{
		$select = $this->db
					->select("ifnull(max(education_order), 0) AS `MEO`")
					->from("t_user_educations")
					->where("user_id", $profileID)
					->get();
		$result = $select->result_array();
		return (int)$result[0]['MEO'] + 1;
	}

	function insertEdukasi($dataInsert)
	{
		$this->db->insert("t_user_educations", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateEdukasi($userId, $orderEdukasi, $dataUpdate)
	{
		$this->db->where('user_id', $userId);
		$this->db->where('education_order', $orderEdukasi);
		$this->db->update("t_user_educations", $dataUpdate);
		return $this->db->affected_rows();
	}

	function deleteEdukasi($userId, $orderEdukasi)
	{
		$this->db->where('user_id', $userId);
		$this->db->where('education_order', $orderEdukasi);
		$this->db->delete("t_user_educations");
		return $this->db->affected_rows();
	}
}