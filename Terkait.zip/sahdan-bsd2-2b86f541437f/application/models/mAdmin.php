<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MAdmin extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllAdmin()
	{
		$select = $this->db
					->select('admin_id, admin_first_name, admin_last_name, admin_password, admin_email, status')
					->from("t_admin")
					->order_by("admin_id", "asc")
					->get();
		return $select->result();
	}
	
	function selectByIdAdmin($id)
	{
		$select = $this->db
					->select('admin_id, admin_first_name, admin_last_name, admin_password, admin_email, status')
					->from("t_admin")
					->where("admin_id", $id)
					->get();
		return $select->result();
	}
	
	function checkLogin($email, $password)
	{
		$select = $this->db
					->select('*')
					->from("t_admin")
					->where("admin_email", $email)
					->where("admin_password", $password)
					->where("status", 1)
					->get();
		return $select->result();
	}
	
	function selectCtrVisit()
	{
		$select = $this->db
					->select('ctr_visit')
					->from("t_admin")
					->where("admin_id", 1)
					->get();
		return $select->row()->ctr_visit;
	}
	
	function updateCtrWeb()
	{
		return $this->db->query("UPDATE t_admin SET ctr_visit=ctr_visit+1 WHERE admin_id = 1");
	}
	
	function insertAdmin($dataInsert)
	{
		$this->db->insert("t_admin", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function deleteAdmin($id)
	{
		$this->db->where('admin_id', $id);
		$this->db->set('status', "0");
		$this->db->update('t_admin');
		return $this->db->affected_rows();
	}
	
	function recoverAdmin($id)
	{
		$this->db->where('admin_id', $id);
		$this->db->set('status', "1");
		$this->db->update('t_admin');
		return $this->db->affected_rows();
	}
	
	function updateAdmin($id, $dataUpdate)
	{
		$this->db->where('admin_id', $id);
		$this->db->update("t_admin", $dataUpdate);
		return $this->db->affected_rows();
	}
}