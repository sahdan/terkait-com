<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MCompanies extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
		function selectCompany($companyName)
	{
		$select = $this->db
					->select("company_name")
					->from("t_companies")
					->like("company_name", $companyName)
					->get();
		return $select->result();
	}

	function selectSearchCompany($keyword)
	{
		$select = $this->db
		->select("company_name, company_id, company_description, company_size, company_type, cover_url, logo_url, website_url, year_founded, status")
		->from("t_companies")
		->like("company_name", $keyword[0])
		->get();
		return $select->result();
	}
	
	function getIdByName($companyName = FALSE)
	{
		$select = $this->db
					->select("company_id")
					->from("t_companies")
					->where("company_name", $companyName)
					->get();
		$result = $select->result_array();
		return $result;
	}

	function getCompanyByName($companyName = FALSE)
	{
		$select = $this->db
					->select("company_name, company_id, company_description, company_size, company_type, cover_url, logo_url, website_url, year_founded, status")
					//->select("company_name, company_id, company_description, company_size, company_type, website_url, year_founded, status")
					->from("t_companies")
					->where("lower(company_name)", $companyName)
					->get();
		$result = $select->result_array();
		return $result;
	}
	
	function getCompanyById($companyId)
	{
		$select = $this->db
					->select("company_name, company_id, company_description, company_size, company_type, cover_url, logo_url, website_url, year_founded, status")
					->from("t_companies")
					->where("company_id", $companyId)
					->where("status", "1")
					->get();
		$result = $select->result();
		return $result;
	}

	function insertCompanies($dataInsert)
	{
		$this->db->insert("t_companies", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateCompanies($id, $dataUpdate)
	{
		$this->db->where('company_id', $id);
		$this->db->update("t_companies", $dataUpdate);
		return $this->db->affected_rows();
	}
}