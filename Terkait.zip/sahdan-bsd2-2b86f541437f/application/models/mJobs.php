<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MJobs extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllJobs()
	{
		$select = $this->db
					->select('*')
					->from("t_jobs")
					->get();
		return $select->result();
	}
	
	function selectByIdJobs($id)
	{
		$select = $this->db
					->select('job_id, job_description, company_id, job_position, seniority_level, industry, employment_type, job_functions, created_at, expired_at, min_gaji, max_gaji, status')
					->from("t_jobs")
					->where("job_id", $id)
					->get();
		return $select->result();
	}

	function selectByIdCompany($id)
	{
		$select = $this->db
					->select('job_id, job_description, company_id, seniority_level, industry, employment_type, job_functions, expired_at, min_gaji, max_gaji')
					->from("t_jobs")
					->where("company_id", $id)
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_jobs")
					->get();
		return $select->row()->jumlah;
	}
	
	function insertJobs($dataInsert)
	{
		$this->db->insert("t_jobs", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateJobs($jobId,  $companyId, $dataInsert)
	{
		$this->db->where('job_id', $jobId);
		$this->db->where('company_id', $companyId);
		$this->db->where('status', "1");
		$this->db->update("t_jobs", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function deleteJobs($jobId, $companyId)
	{
		$this->db->where('company_id', $companyId);
		$this->db->where('job_id', $jobId);
		$this->db->set('status', "0");
		$this->db->update("t_jobs");
		return $this->db->affected_rows();
	}
	
	function updateCtrJob($id)
	{
		return $this->db->query("UPDATE t_jobs SET ctr_visit=ctr_visit+1 WHERE job_id = " .$id );
	}
	
	function selectReportMontly($bln)
	{
		if($bln == "0"){
			$select = $this->db
						->select('count(t.job_id) as jml')
						->from("t_jobs j")
						->where('DATE_FORMAT(created_at, "%Y%m")= DATE_FORMAT(now(), "%Y%m")')
						->group_by('DATE_FORMAT(created_at, "%Y%m%d")')
						->get();
			return $select->result();
		}else{
			$select = $this->db
						->select('account_type, count(account_type) as jml')
						->from("t_accounts")
						->where('DATE_FORMAT(created_at2, "%Y%m")= DATE_FORMAT("'.$bln.'", "%Y%m")')
						->group_by('account_type')
						->order_by('account_type', 'DESC')
						->get();
			return $select->result();
		}
			
		
	}
	
	function selectReportJobs($company_id)
	{
		$select = $this->db
					->select('DATE_FORMAT(created_at, "%Y%m%d") AS tgl, COUNT(*) AS jml')
					->from("t_jobs j")
					->where("created_at > DATE_SUB(CURDATE(), INTERVAL 1 YEAR)")
					->where("company_id = $company_id")
					->group_by('DATE_FORMAT(created_at, "%Y%m%d")')
					->get();
		return $select->result();
	}
	
	function selectReportJobsAppliers($company_id)
	{
		$select = $this->db
					->select('DATE_FORMAT(created_at, "%Y%m%d") AS tgl, COUNT(*) AS jml')
					->join('t_jobs j', 'ja.job_id = j.job_id')
					->from("t_jobs_appliers ja")
					->where("created_at > DATE_SUB(CURDATE(), INTERVAL 1 YEAR)")
					->where("company_id = $company_id")
					->group_by('DATE_FORMAT(created_at, "%Y%m%d")')
					->get();
		return $select->result();
	}

	function selectJobsOrderByOwnedSkills($userId){
		$select = $this->db
		->select('j.job_id, j.job_position, j.job_description, j.company_id, j.seniority_level, j.industry, j.employment_type, j.job_functions, j.created_at, j.expired_at, j.min_gaji, j.max_gaji, j.ctr_visit, j.status, sub_js.count_required_skill, count(sub_us.account_id) count_owned_skill, sub_us.account_id, c.company_name, c.logo_url, cl.company_address, cl.city, cl.state, cu.status admin_status')
		->from('t_jobs j')
		->join('t_jobs_skills js', 'j.job_id = js.job_id', 'left')
		->join('t_companies c', 'c.company_id = j.company_id')
		->join("(SELECT cl1.account_id, cl1.company_address, cl1.city, cl1.state FROM t_company_locations cl1 WHERE cl1.is_main_office = '1') cl" , 'cl.account_id = c.company_id', 'left')
		->join('(SELECT js1.JOB_ID, COUNT(1) COUNT_REQUIRED_SKILL FROM t_jobs_skills js1 GROUP BY js1.JOB_ID) sub_js', 'js.job_id = sub_js.job_id', 'left')
		->join("(SELECT us.ACCOUNT_ID, us.SKILL_ID FROM t_user_skills us WHERE us.ACCOUNT_ID = $userId) sub_us", 'sub_us.SKILL_ID = js.SKILL_ID', 'left')
		->join('t_companies_users cu', 'cu.user_id = sub_us.account_id AND cu.company_id = j.company_id', 'left')
		->where('j.status', '1')
		->group_by('j.JOB_ID')
		->order_by('COUNT_OWNED_SKILL', 'desc')
		->get();
		return $select->result();
	}

	function selectJobsByCompanyId($userId, $companyId){
		$select = $this->db
		->select('j.job_id, j.job_position, j.job_description, j.company_id, j.seniority_level, j.industry, j.employment_type, j.job_functions, j.created_at, j.expired_at, j.min_gaji, j.max_gaji, j.ctr_visit, j.status, sub_js.count_required_skill, count(sub_us.account_id) count_owned_skill, sub_us.account_id, c.company_name, c.logo_url, cl.company_address, cl.city, cl.state, cu.status admin_status')
		->from('t_jobs j')
		->join('t_jobs_skills js', 'j.job_id = js.job_id', 'left')
		->join('t_companies c', 'c.company_id = j.company_id')
		->join("(SELECT cl1.account_id, cl1.company_address, cl1.city, cl1.state FROM t_company_locations cl1 WHERE cl1.is_main_office = '1') cl" , 'cl.account_id = c.company_id', 'left')
		->join('(SELECT js1.JOB_ID, COUNT(1) COUNT_REQUIRED_SKILL FROM t_jobs_skills js1 GROUP BY js1.JOB_ID) sub_js', 'js.job_id = sub_js.job_id', 'left')
		->join("(SELECT us.ACCOUNT_ID, us.SKILL_ID FROM t_user_skills us WHERE us.ACCOUNT_ID = $userId) sub_us", "sub_us.SKILL_ID = js.SKILL_ID", 'left')
		->join('t_companies_users cu', 'cu.user_id = sub_us.account_id AND cu.company_id = j.company_id', 'left')
		->where('j.company_id', $companyId)
		->group_by('j.JOB_ID')
		->order_by('COUNT_OWNED_SKILL', 'desc')
		->get();
		return $select->result();
	}

	function selectJobDetail($userId, $jobId){
		$select = $this->db
		->select("j.job_id, j.job_position, j.job_description, j.company_id, j.seniority_level, j.industry, j.employment_type, j.job_functions, j.created_at, j.expired_at, j.min_gaji, j.max_gaji, j.ctr_visit, j.status, c.company_name, c.logo_url, cl.company_address, cl.city, cl.state, IF(cu.status IS NULL, '-1', cu.status) admin_status")
		->from('t_jobs j')
		->join('t_companies c', 'c.company_id = j.company_id')
		->join("(SELECT cl1.account_id, cl1.company_address, cl1.city, cl1.state FROM t_company_locations cl1 WHERE cl1.is_main_office = '1') cl" , 'cl.account_id = c.company_id', 'left')
		->join("(SELECT cu1.user_id, cu1.company_id, cu1.status FROM t_companies_users cu1 WHERE cu1.user_id = $userId) cu", 'cu.company_id = j.company_id', 'left')
		->where('j.job_id', $jobId)
		->get();
		return $select->result();
	}

	function selectJobsOrderByOwnedSkillsWithKeyword($userId, $keyword){
		$select = $this->db
		->select('j.job_id, j.job_position, j.job_description, j.company_id, j.seniority_level, j.industry, j.employment_type, j.job_functions, j.created_at, j.expired_at, j.min_gaji, j.max_gaji, j.ctr_visit, j.status, sub_js.count_required_skill, count(sub_us.account_id) count_owned_skill, sub_us.account_id, c.company_name, c.logo_url, cl.company_address, cl.city, cl.state, cu.status admin_status')
		->from('t_jobs j')
		->join('t_jobs_skills js', 'j.job_id = js.job_id', 'left')
		->join('t_companies c', 'c.company_id = j.company_id')
		->join("(SELECT cl1.account_id, cl1.company_address, cl1.city, cl1.state FROM t_company_locations cl1 WHERE cl1.is_main_office = '1') cl" , 'cl.account_id = c.company_id', 'left')
		->join('(SELECT js1.JOB_ID, COUNT(1) COUNT_REQUIRED_SKILL FROM t_jobs_skills js1 GROUP BY js1.JOB_ID) sub_js', 'js.job_id = sub_js.job_id', 'left')
		->join("(SELECT us.ACCOUNT_ID, us.SKILL_ID FROM t_user_skills us WHERE us.ACCOUNT_ID = $userId) sub_us", 'sub_us.SKILL_ID = js.SKILL_ID', 'left')
		->join('t_companies_users cu', 'cu.user_id = sub_us.account_id AND cu.company_id = j.company_id', 'left')
		->group_start()
			->where("'".$keyword."' LIKE CONCAT('%', j.job_position, '%')")
			->or_like("j.job_position", $keyword)
		->group_end()
		->group_by('j.JOB_ID')
		->order_by('COUNT_OWNED_SKILL', 'desc')
		->get();
		return $select->result();
	}
}