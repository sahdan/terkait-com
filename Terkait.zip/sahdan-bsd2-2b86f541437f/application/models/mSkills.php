<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MSkills extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectSkill($skillName = FALSE)
	{
	    $select = $this->db
					->select("skill_name,skill_id")
					->from("t_skills")
					->like("skill_name", $skillName)
					->get();
		return $select->result();
    }
    
    function selectAllSkills(){
        $select = $this->db
					->select("skill_name,skill_id")
					->from("t_skills")
					->get();
		return $select->result();
    }
    
    function getIdByName($skillName = FALSE)
	{
		$select = $this->db
					->select("skill_id")
					->from("t_skills")
					->where("LOWER(skill_name)", $skillName)
					->get();
		$result = $select->result_array();
		if(!empty($result)){
			return $result[0]['skill_id'];
		}
	}
	
	function getNameById($skillID = FALSE)
	{
		$select = $this->db
					->select("skill_name")
					->from("t_skills")
					->where("skill_id", $skillID)
					->get();
		$result = $select->result_array();
		return $result[0]['skill_name'];
	}
    
	function insertSkill($dataInsert)
	{
		$this->db->insert("t_skills", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateSkill($id, $dataUpdate)
	{
		$this->db->where('skill_id', $id);
		$this->db->update("t_skills", $dataUpdate);
		return $this->db->affected_rows();
	}
}