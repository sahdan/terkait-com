<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MUniversities extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllUniversities()
	{
		$select = $this->db
					->select("company_name, logo_url")
					->from("t_universities")
					->join("t_companies","t_companies.company_id = t_universities.university_id")
					->get();
		return $select->result();
	}

	function selectUniversity($universityName)
	{
		$select = $this->db
					->select("t_companies.company_name, t_companies.company_id")
					->from("t_universities")
					->join("t_companies","t_companies.company_id = t_universities.university_id")
					//->where("t_universities.status", '1')
					->like("t_companies.company_name", $universityName)
					->get();
		return $select->result();
	}

	function checkExist($universityId)
	{
		$select = $this->db
					->select("university_id")
					->from("t_universities")
					->where("university_id", $universityId)
					->get();
		return $select->result();
	}

	function insertUniversity($dataInsert)
	{
		$this->db->insert("t_universities", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updateUsers($id, $dataInsert)
	{
		$this->db->where('user_id', $id);
		$this->db->update("t_users", $dataInsert);
		return $this->db->affected_rows();
	}
}