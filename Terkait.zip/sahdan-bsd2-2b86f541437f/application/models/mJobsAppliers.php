<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MJobsAppliers extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
    }
    
    function selectAppliersAndSkills($jobId){
        $select = $this->db
		->select("ja.job_id, ja.applier_id, ja.applied_at, ja.status, js.skill_id required_skill, s.skill_name, IF(us.skill_id IS NULL, 0, 1) is_owned, CONCAT(u.user_first_name,' ',u.user_last_name) full_name")
        ->from('t_jobs_appliers ja')
        ->join('t_jobs_skills js', 'ja.job_id = js.job_id', 'left')
        ->join('t_user_skills us', 'us.skill_id = js.skill_id AND ja.applier_id = us.account_id', 'left')
        ->join('t_users u', 'ja.applier_id = u.user_id')
        ->join('t_skills s', 's.skill_id = js.skill_id', 'left')
        ->where('ja.job_id', $jobId)
        ->order_by('ja.applied_at', 'asc')  
		->get();
		return $select->result();
	}
	
	function selectUserJobApplication($userId,$jobId){
		$select = $this->db
		->select("tja.job_id, tja.applier_id, tja.applied_at, tja.status")
		->from('t_jobs_appliers tja')
		->where('tja.job_id', $jobId)
		->where('tja.applier_id', $userId)
		->get();
		return $select->result_array();
	}

    function insert($data){
        $this->db->insert("t_jobs_appliers", $data);
		return $this->db->affected_rows();
    }

    function update($jobId, $data)
	{
		$this->db->where('job_id', $id);
		$this->db->update("t_jobs_appliers", $data);
		return $this->db->affected_rows();
	}
	
	function delete($jobId)
	{
		$this->db->where('job_id', $jobId);
		$this->db->set('status', "0");
		$this->db->update("t_jobs_appliers");
		return $this->db->affected_rows();
	}

}