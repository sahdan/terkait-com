<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MPost extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	function selectAllPosts()
	{
		$select = $this->db
					->select('p.post_id, p.media_link, p.post_content, p.view_counter, p.account_id, u.user_first_name, u.user_last_name')
					->from("t_posts p")
					->join('t_users u', 'u.user_id = p.account_id')
					->join('t_activities a', 'a.activity_id = p.post_id')
                    ->where("a.status", 1)
					->order_by("post_id", "desc")
					->get();
		return $select->result();
	}
	
	function select10Post($user_id)
	{
		$select = $this->db
					->select('p.post_id, a.created_at, count(like_id) as likes, p.media_link, p.post_content, p.view_counter, p.account_id, u.user_first_name, u.user_last_name, CASE WHEN (SELECT COUNT(*) FROM t_likes WHERE parent_activity_id = a.activity_id AND account_id = '.$user_id.') THEN 1 END AS flag, (SELECT COUNT(*) FROM t_comments tc JOIN t_activities ta ON ta.activity_id = tc.comment_id WHERE parent_activity_id = p.post_id AND ta.status = 1) AS ctrComment, u.photo_url, c.company_name, c.logo_url')
					->from("t_posts p")
					->join('t_users u', 'u.user_id = p.account_id', 'left')
					->join('t_companies c', 'c.company_id = p.account_id', 'left')
					->join('t_activities a', 'a.activity_id = p.post_id')
					->join('t_likes l', 'l.parent_activity_id = a.activity_id', 'left')
                    ->where("a.status", 1)
                    ->where("(p.account_id = $user_id OR p.account_id IN (SELECT account_followed_id FROM t_account_followers WHERE user_following_id = $user_id))")
					->group_by('p.post_id')
					->order_by("post_id", "desc")
					->limit(10)
					->get();
		return $select->result();
	}
	
	function select10PostCompany($user_id)
	{
		$select = $this->db
					->select('p.post_id, count(like_id) as likes, p.media_link, p.post_content, p.view_counter, p.account_id, CASE WHEN (SELECT COUNT(*) FROM t_likes WHERE parent_activity_id = a.activity_id AND account_id = '.$user_id.') THEN 1 END AS flag, (SELECT COUNT(*) FROM t_comments WHERE parent_activity_id = p.post_id) AS ctrComment, company_name, logo_url')
					->from("t_posts p")
					->join('t_companies c', 'c.company_id = p.account_id')
					->join('t_activities a', 'a.activity_id = p.post_id')
					->join('t_likes l', 'l.parent_activity_id = a.activity_id', 'left')
                    ->where("a.status", 1)
                    ->where("(p.account_id = $user_id OR p.account_id IN (SELECT account_followed_id FROM t_account_followers WHERE user_following_id = $user_id))")
					->group_by('p.post_id')
					->order_by("post_id", "desc")
					->limit(10)
					->get();
		return $select->result();
	}
	
	function selectPostById($user_id, $id)
	{
		$select = $this->db
					->select('p.post_id, count(like_id) as likes, p.media_link, p.post_content, p.view_counter, p.account_id, u.user_first_name, u.user_last_name, CASE WHEN (SELECT COUNT(*) FROM t_likes WHERE parent_activity_id = a.activity_id AND account_id = '.$user_id.') THEN 1 END AS flag, (SELECT COUNT(*) FROM t_comments WHERE parent_activity_id = p.post_id) AS ctrComment, u.photo_url')
					->from("t_posts p")
					->join('t_users u', 'u.user_id = p.account_id')
					->join('t_activities a', 'a.activity_id = p.post_id')
					->join('t_likes l', 'l.parent_activity_id = a.activity_id', 'left')
                    ->where("a.status", 1)
                    ->where("p.post_id", $id)
					->group_by('p.post_id')
					->order_by("post_id", "desc")
					->limit(10)
					->get();
		return $select->result();
	}
	
	function select10Post1()
	{
		$select = $this->db
					->select('p.post_id, count(like_id) as likes, p.media_link, p.post_content, p.view_counter, p.account_id, u.user_first_name, u.user_last_name, CASE WHEN (SELECT COUNT(*) FROM t_likes WHERE parent_activity_id = a.activity_id) THEN 1 END AS flag, (SELECT COUNT(*) FROM t_comments WHERE parent_activity_id = p.post_id) AS ctrComment')
					->from("t_posts p")
					->join('t_users u', 'u.user_id = p.account_id')
					->join('t_activities a', 'a.activity_id = p.post_id')
					->join('t_likes l', 'l.parent_activity_id = a.activity_id', 'left')
                    ->where("a.status", 1)
					->group_by('p.post_id')
					->order_by("post_id", "desc")
					->limit(10)
					->get();
		return $select->result();
	}
	
	function selectPostStartEnd($start, $user_id)
	{
		$select = $this->db
					->select('p.post_id, a.created_at, count(like_id) as likes, p.media_link, p.post_content, p.view_counter, p.account_id, u.user_first_name, u.user_last_name, CASE WHEN (SELECT COUNT(*) FROM t_likes WHERE parent_activity_id = a.activity_id) THEN 1 END AS flag, (SELECT COUNT(*) FROM t_comments WHERE parent_activity_id = p.post_id) AS ctrComment, u.photo_url, c.company_name, c.logo_url')
					->from("t_posts p")
					->join('t_users u', 'u.user_id = p.account_id', 'left')
					->join('t_companies c', 'c.company_id = p.account_id', 'left')
					->join('t_activities a', 'a.activity_id = p.post_id')
					->join('t_likes l', 'l.parent_activity_id = a.activity_id', 'left')
                    ->where("a.status", 1)
                    ->where("(p.account_id = $user_id OR p.account_id IN (SELECT account_followed_id FROM t_account_followers WHERE user_following_id = $user_id))")
					->group_by('p.post_id')
					->order_by("post_id", "desc")
					->limit(10, $start)
					->get();
		return $select->result();
	}
	
	function selectMaxId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_posts")
					->get();
		return $select->result();
	}
	
	function selectCountId()
	{
		$select = $this->db
					->select('count(*) as jumlah')
					->from("t_posts")
					->get();
		return $select->row()->jumlah;
	}
	
	function selectByIdPosts($id)
	{
		$select = $this->db
					->select('p.post_id, p.media_link, p.post_content, p.view_counter, p.account_id, u.user_first_name, u.user_last_name')
					->from("t_posts p")
					->join('t_users u', 'u.user_id = p.account_id')
					->where("post_id", $id)
					->get();
		return $select->result();
	}
	
	function insertPosts($dataInsert)
	{
		$this->db->insert("t_posts", $dataInsert);
		return $this->db->affected_rows();
	}
	
	function updatePosts($id, $dataInsert)
	{
		$this->db->where('POST_ID', $id);
		$this->db->update("t_posts", $dataInsert);
		return $this->db->affected_rows();
	}
}