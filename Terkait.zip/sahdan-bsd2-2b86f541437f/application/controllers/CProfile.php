<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CProfile extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mUsers');
		$this->load->model('mUser_Educations');
		$this->load->model('mUniversities');
		$this->load->model('mUser_Positions');
		$this->load->model('mUser_Skills');
		$this->load->model('mSkills');
		$this->load->model('mEndorsement');
		$this->load->model('mUser_Connections');
		$this->load->model('mCompanies');
		$this->load->model('mAccount_Followers');
		$this->load->model('mAccounts');
		$this->load->model('mNotifications');
		$this->load->model('mConversation');
		$this->load->model('mVConnectionsCount');
		$this->load->library('session');
	}
	
	//fungsi untuk melihat profil user dengan parameter user id
	public function index($profileID = FALSE)
	{
		if($_SESSION["user_id"]){
			$loginID = $_SESSION["user_id"];
			//kalau tidak ada param kembali ke home
			if($profileID == FALSE)
			{
				redirect('/CHome');
			}
			//$param["universities"] = $this->mUniversities->selectAllUniversities();
			//$param["skills"] = $this->mSkills->selectAllSkills();
			$param["user_educations"] = $this->mUser_Educations->selectUserEducations($profileID);
			//$param["user_skills"] = $this->mUser_Skills->selectUserSkills($profileID);
			$param["user_skills"] = $this->mUser_Skills->selectUserSkillsEndorsementCount($profileID);
			$param["skill_endorsed"] = $this->mEndorsement->selectSkillEndorsed($loginID, $profileID);
			$param["user_positions"] = $this->mUser_Positions->selectUserPositions($profileID);
			$param["count_user_connections"] = $this->mUser_Connections->countConnection($profileID);
			$param["userProfile"] = $this->mUsers->selectUser($profileID);
			$param["loginID"] = $loginID;
			$param["profileID"] = $profileID;
			$param["connection"] = $this->mUser_Connections->getStatusConnection($loginID,$profileID);
			//kalau ada koneksi ambil status koneksi, kalau belum kasih status "-1", kalau diri sendiri kasih "-2"
			if($param["connection"] != null){
				$param["connection_user_in_action"] = $param["connection"][0]["user_in_action_id"];
				$param["connection_user_affected"] = $param["connection"][0]["user_affected_id"];
				$param["connection_status"] = $param["connection"][0]["status2"];
			}elseif($loginID != $profileID){
				$param["connection_status"] = "-1";
			}else{
				$param["connection_status"] = "-2";
			}
			$param["follow_status"] = $this->mAccount_Followers->isFollowing($loginID, $profileID);

			$temp_array = array();
			foreach($param["skill_endorsed"] as $item){
				$temp_array[] = $item->skill_id;
			}
			$param["skill_endorsed"] = $temp_array;
			//var_dump($param["user"]);
			$this->mAccounts->updateCtrAccount($profileID);
			$param["countMsg"] = $this->loadNotifMsg();
			$param["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$param["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$param["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$param["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$param["ctr_visit"] = $this->mAccounts->selectCtrVisit($profileID);
			$this->load->view('profile', $param);
		}else{
			$this->load->view('profile');
		}
	}

	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}
	
	//fungsi untuk mengembalikan hasil sejarah pendidikan user yang login
	public function getEdukasi()
	{
		$loginID = $_SESSION['user_id'];
		$universityID = $this->input->get_post('universityID');
		$order = $this->input->get_post('order');
		$param = $this->mUser_Educations->selectEducation($loginID, $universityID, $order);
		echo json_encode($param);
	}

	//fungsi untuk mengembalikan hasil pengalaman kerja user yang login
	public function getPengalaman()
	{
		$loginID = $_SESSION['user_id'];
		$companyID = $this->input->get_post('companyID');
		$param = $this->mUser_Positions->selectPosition($loginID, $companyID);
		echo json_encode($param);
	}

	//fungsi untuk mengembalikan profil user
	public function getProfil()
	{
		$profileID = $this->input->get_post('profileID');
		$param = $this->mUsers->selectUser($profileID);
		echo json_encode($param);
	}

	//fungsi untuk mengembalikan skill name yang menyerupai param
	public function getSkill()
	{
		$skillName = $this->input->get_post('skillName');
		$param = $this->mSkills->selectSkill($skillName);
		echo json_encode($param);
	}

	//mengembalikan university id, name yang university namenya menyerupai param
	public function getSekolah(){
		$universityName = $this->input->get_post('universityName');
		$param = $this->mUniversities->selectUniversity($universityName);
		echo json_encode($param);
	}

	//mengembalikan company name menyerupai param
	public function getPerusahaan(){
		$companyName = $this->input->get_post('companyName');
		$param = $this->mCompanies->selectCompany($companyName);
		echo json_encode($param);
	}

	//mendapatkan skill name jika diketahui skill id
	public function getSkillById()
	{
		$skillID = $this->input->get_post('skillID');
		$param = $this->mSkills->getNameById($skillID);
		echo $param;
	}

	//fungsi untuk tambah skill
	public function tambahSkill(){
		$loginID = $_SESSION['user_id'];
		$dataInsertSkillUser["skill_id"] = $this->mSkills->getIdByName($this->input->get_post('edSkill'));
		//kalau skill belumada, buat dulu
		if(empty($dataInsertSkillUser["skill_id"])){
			$dataInsertSkill["skill_name"] = $this->input->get_post('edSkill');
			$this->mSkills->insertSkill($dataInsertSkill);
			$dataInsertSkillUser["skill_id"] = $this->mSkills->getIdByName($this->input->get_post('edSkill'));
		}
		//
		if(empty($this->mUser_Skills->isSkillOwned($dataInsertSkillUser["skill_id"], $loginID))){
			$dataInsertSkillUser["account_id"] = $loginID;
			$dataInsertSkillUser["status"] = '1';
			$this->mUser_Skills->insertSkillUser($dataInsertSkillUser);
		}
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk hapus skill
	public function hapusSkill(){
		$loginID = $_SESSION['user_id'];
		$skillID = $this->input->get_post('edSkillID');
		$this->mUser_Skills->deleteSkillUser($loginID, $skillID);
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk hapus pengalaman kerja
	public function hapusPengalaman(){
		$loginID = $_SESSION['user_id'];
		$companyID = $this->input->get_post('edCompanyID');
		$this->mUser_Positions->deletePosition($loginID, $companyID);
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk hapus sejarah pendidikan
	public function hapusEdukasi(){
		$loginID = $_SESSION['user_id'];
		$orderEdukasi = $this->input->get_post('edOrderEdukasi');
		$this->mUser_Educations->deleteEdukasi($loginID, $orderEdukasi);
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk edit profil
	public function editProfil(){
		$loginID = $_SESSION['user_id'];
		$dataEditProfil["headline"] = $this->input->get_post('edHeadline');
		$dataEditProfil["user_first_name"] = $this->input->get_post('edNamaDepan');
		$dataEditProfil["user_last_name"] = $this->input->get_post('edNamaBelakang');
		$dataEditProfil["user_email"] = $this->input->get_post('edEmail');
		$_SESSION["user_first_name"] = $this->input->get_post('edNamaDepan');
		$_SESSION["user_last_name"] = $this->input->get_post('edNamaBelakang');
		$_SESSION["user_email"] = $this->input->get_post('edEmail');
		$_SESSION["user_headline"] = $this->input->get_post('edHeadline');
		//$dataEditProfil["photo_url"] = $this->input->get_post('edPhotoUrl');
		
		//kalau foto tidak kosong, update
		if($_FILES["edPhotoUrl"]["tmp_name"] != null)
		{
			if($this->ambilGambar("edPhotoUrl", $loginID) != ""){
				$dataEditProfil["photo_url"] = $this->ambilGambar("edPhotoUrl", $loginID);
			}
		}
		$dataEditProfil["zip_code"] = $this->input->get_post('edZipcode');
		$dataEditProfil["summary"] = $this->input->get_post('edRingkasan');
		//$dataEditProfil["password"] = $this->input->get_post('edPassword');
		$this->mUsers->updateUsers($loginID, $dataEditProfil);
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk tambah sejarah pendidikan
	public function tambahEdukasi()
	{
		$loginID = $_SESSION['user_id'];
		$companyName = $this->input->get_post('edSekolah');
		$dataInsertEdukasi["university_id"] = $this->mCompanies->getIdByName($companyName);
		//kalau university belum ada ditabel company, insert dulu
		if(empty($dataInsertEdukasi["university_id"]))
		{
			$this->tambahPerusahaan($companyName);
			$dataInsertEdukasi["university_id"] = $this->mCompanies->getIdByName($companyName);
		}
		$dataInsertEdukasi['university_id'] = $dataInsertEdukasi['university_id'][0]['company_id'];
		$universityExist = $this->mUniversities->checkExist($dataInsertEdukasi['university_id']);
		//kalau university belum ada ditabel insert, insert dulu
		if(empty($universityExist))
		{
			$this->tambahUniversitas($dataInsertEdukasi["university_id"], '0');
		}
		$dataInsertEdukasi["user_id"] = $loginID;
		$dataInsertEdukasi["academic_degree"] = $this->input->get_post('edTingkat');
		$dataInsertEdukasi["grade"] = $this->input->get_post('edNilai');
		$dataInsertEdukasi["field_of_study"] = $this->input->get_post('edJurusan');
		$dataInsertEdukasi["from_year"] = $this->input->get_post('edTahunMulai');
		$dataInsertEdukasi["to_year"] = $this->input->get_post('edTahunSelesai');
		$dataInsertEdukasi["education_description"] = $this->input->get_post('edDeskripsi');
		$dataInsertEdukasi["activities_societies"] = $this->input->get_post('edKegiatan');
		$dataInsertEdukasi["media_url"] = "";//kosong
		//$dataInsertEdukasi["education_order"] = $this->mUser_Educations->selectMaxEducationOrder($loginID, $dataInsertEdukasi["university_id"]);
		$dataInsertEdukasi["education_order"] = $this->mUser_Educations->selectMaxEducationOrder($loginID);
		$dataInsertEdukasi["status"] = "1";
		if($dataInsertEdukasi["university_id"] != "" && $dataInsertEdukasi["field_of_study"] != "" && $dataInsertEdukasi["academic_degree"] != "" && $dataInsertEdukasi["user_id"] != ""){
			$this->mUser_Educations->insertEdukasi($dataInsertEdukasi);
		}
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk tambah pengalaman kerja
	public function tambahPengalaman()
	{
		$loginID = $_SESSION['user_id'];
		$companyName = $this->input->get_post('edPerusahaan');
		$dataInsertPengalaman["company_id"] = $this->mCompanies->getIdByName($companyName);
		//kalau company belum ada ditabel company buat dulu
		if(empty($dataInsertPengalaman["company_id"]))
		{
			$this->tambahPerusahaan($companyName);
			$dataInsertPengalaman["company_id"] = $this->mCompanies->getIdByName($companyName);
		}
		$dataInsertPengalaman["company_id"] = $dataInsertPengalaman['company_id'][0]['company_id'];
		$dataInsertPengalaman["user_id"] = $loginID;
		$dataInsertPengalaman["location"] = $this->input->get_post('edLokasi');
		$dataInsertPengalaman["title"] = $this->input->get_post('edJabatan');
		$dataInsertPengalaman["from_date"] = $this->input->get_post('edMulaiKerja');
		$dataInsertPengalaman["to_date"] = $this->input->get_post('edSelesaiKerja');
		if($this->input->get_post('edSedangBekerja') == 'on'){
			$dataInsertPengalaman["currently_work_here"] = '1';
			$dataInsertPengalaman["to_date"] = 'null';
		}else{
			$dataInsertPengalaman["currently_work_here"] = '0';
		}
		$dataInsertPengalaman["status"] = "1";
		$this->mUser_Positions->insertPosition($dataInsertPengalaman);
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk edit pengalaman kerja
	public function editPengalaman()
	{
		$loginID = $_SESSION['user_id'];
		$companyID = $this->input->get_post('edCompanyID');
		$companyName = $this->input->get_post('edPerusahaan');
		$dataEditPengalaman["company_id"] = $this->mCompanies->getIdByName($companyName);
		//kalau company belum ada ditabel company buat dulu
		if(empty($dataEditPengalaman["company_id"]))
		{
			$this->tambahPerusahaan($companyName);
			$dataEditPengalaman["company_id"] = $this->mCompanies->getIdByName($companyName);
		}
		$dataEditPengalaman["company_id"] = $dataEditPengalaman['company_id'][0]['company_id'];
		$dataEditPengalaman["user_id"] = $loginID;
		$dataEditPengalaman["location"] = $this->input->get_post('edLokasi');
		$dataEditPengalaman["title"] = $this->input->get_post('edJabatan');
		$dataEditPengalaman["from_date"] = $this->input->get_post('edMulaiKerja');
		$dataEditPengalaman["to_date"] = $this->input->get_post('edSelesaiKerja');
		if($this->input->get_post('edSedangBekerja') == 'on'){
			$dataEditPengalaman["currently_work_here"] = '1';
			$dataEditPengalaman["to_date"] = 'null';
		}else{
			$dataEditPengalaman["currently_work_here"] = '0';
		}
		$dataEditPengalaman["status"] = "1";
		$this->mUser_Positions->updatePosition($loginID, $companyID, $dataEditPengalaman);
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk edit sejarah pendidikan
	public function editEdukasi()
	{
		$loginID = $_SESSION['user_id'];
		$companyName = $this->input->get_post('edSekolah');
		$orderEdukasi = $this->input->get_post('edOrderEdukasi');
		$dataEditEdukasi["university_id"] = $this->mCompanies->getIdByName($companyName);
		//kalau universitas belum ada di tabel company, insert dulu
		if(empty($dataEditEdukasi["university_id"]))
		{
			$this->tambahPerusahaan($companyName);
			$dataEditEdukasi["university_id"] = $this->mCompanies->getIdByName($companyName);
		}
		$dataEditEdukasi['university_id'] = $dataEditEdukasi['university_id'][0]['company_id'];
		$universityExist = $this->mUniversities->checkExist($dataEditEdukasi['university_id']);
		//kalau universitas belum ada di tabel university, insert dulu
		if(empty($universityExist))
		{
			$this->tambahUniversitas($dataEditEdukasi["university_id"], '0');
		}
		$dataEditEdukasi["academic_degree"] = $this->input->get_post('edTingkat');
		$dataEditEdukasi["grade"] = $this->input->get_post('edNilai');
		$dataEditEdukasi["field_of_study"] = $this->input->get_post('edJurusan');
		$dataEditEdukasi["from_year"] = $this->input->get_post('edTahunMulai');
		$dataEditEdukasi["to_year"] = $this->input->get_post('edTahunSelesai');
		$dataEditEdukasi["education_description"] = $this->input->get_post('edDeskripsi');
		$dataEditEdukasi["activities_societies"] = $this->input->get_post('edKegiatan');
		$dataEditEdukasi["media_url"] = "";//kosong
		$dataEditEdukasi["status"] = "1";
		if($dataEditEdukasi["university_id"] != "" && $dataEditEdukasi["field_of_study"] != "" && $dataEditEdukasi["academic_degree"] != ""){
			$this->mUser_Educations->updateEdukasi($loginID, $orderEdukasi, $dataEditEdukasi);
		}
		redirect('CProfile/index/'.$loginID);
	}

	//fungsi untuk tambah/batal/terima/hapus/unblokir koneksi
	public function userKoneksi(){
		$dataKoneksi["status2"] = $this->input->get_post('status');
		$loginID = $this->input->get_post('loginID');
		$profileID = $this->input->get_post('profileID');

		//status baru "-1" tidak digunakan diDB hanya penanda untuk hapus koneksi
		if($dataKoneksi["status2"] != "-1"){
			if($dataKoneksi["status2"] != "1"){
				$dataKoneksi["user_in_action_id"] = $loginID;
				$dataKoneksi["user_affected_id"] = $profileID;
				$this->mUser_Connections->insertConnection($dataKoneksi);
			}else{
				$this->mUser_Connections->updateConnection($loginID, $profileID, $dataKoneksi);
			}
		}else{
			$this->mUser_Connections->deleteConnection($loginID, $profileID);
		}
		$param["status"] = $dataKoneksi["status2"];
		$follow_status = $this->mAccount_Followers->isFollowing($loginID, $profileID);
		//return[0]=button koneksi-1 & koneksi-2 yang baru
		//jum koneksi
		//status koneksi yang baru
		//status follow
		$return = array($this->load->view('ajax/ajaxChangeConnection', $param, true), 
						$this->mUser_Connections->countConnection($profileID), 
						$param["status"],
						$follow_status);

		//jika status = 1 -> yaitu terkoneksi maka akan ditambahkan button endorse untuk setiap skill ke return val
		if($param["status"] == 1){
			$buttonArray = array();
			$temp_array = array();
			$skillEndorsed = $this->mEndorsement->selectSkillEndorsed($loginID, $profileID);
			foreach($skillEndorsed as $item){
				$temp_array[] = $item->skill_id;
			}
			$skillEndorsed = $temp_array;
			$listSkill = $this->mUser_Skills->selectUserSkillsId($profileID);
			if(!is_null($listSkill)&&!is_null($skillEndorsed)){
				foreach($listSkill as $item){
					if(in_array($item->skill_id, $skillEndorsed)){
						$buttonArray[$item->skill_id] = '<input type="hidden" name="is-endorsed" value="1"/>
														 <button class="btn-small secondary-content blue darken-4 endorse-skill">
															<i style="margin-right:5px;" class="material-icons left">clear</i>
															Hapus Endorsement
														 </button>';
					}else{
						$buttonArray[$item->skill_id] = '<input type="hidden" name="is-endorsed" value="0"/>
														 <button class="btn-small secondary-content blue darken-4 endorse-skill">
															Endorse
														 </button>';	
					}
				}
				$return[] = $buttonArray;
			}
		}
		$_SESSION["user_jum_koneksi"] = $this->mUser_Connections->countConnection($loginID);
		echo json_encode($return);
	}

	//fungi untuk me-follow/unfollow user
	public function akunFollow(){
		$dataFollow["user_following_id"] = $this->input->get_post('loginID');
		$dataFollow["account_followed_id"] = $this->input->get_post('profileID');
		$dataFollow["status"] = "1";
		$follow_status = $this->input->get_post('status');
		$return = array();
		if($follow_status == 0){
			$this->mAccount_Followers->insertFollow($dataFollow);
			$return = array("UNFOLLOW", 1);
		}else{
			$this->mAccount_Followers->deleteFollow($dataFollow["user_following_id"],$dataFollow["account_followed_id"]);
			$return = array("FOLLOW", 0);
		}
		echo json_encode($return);
	}

	//fungsi untuk mengendorse/batal skill user
	public function endorseSkill(){
		$loginID = $_SESSION['user_id'];
		$is_endorsed = $this->input->get_post('is_endorsed');
		$dataEndorse["user_in_action_id"] = $loginID;
		$dataEndorse["user_affected_id"] = $this->input->get_post('profileID');
		$dataEndorse["skill_id"] = $this->input->get_post('skill_id');
		// $is_endorsed = 0;
		// $dataEndorse["user_in_action_id"] = 6;
		// $dataEndorse["user_affected_id"] = 5;
		// $dataEndorse["skill_id"] = 7;
		$newValue = 0;
		$buttonLabel = 'Endorse';
		if($is_endorsed == 1){
			$this->mEndorsement->deleteEndorsement($dataEndorse["user_in_action_id"], $dataEndorse["user_affected_id"], $dataEndorse["skill_id"]);
		}else{
			$this->mEndorsement->insertEndorsement($dataEndorse);
			$newValue = 1;
			$buttonLabel = '<i style="margin-right:5px;" class="material-icons left">clear</i> Hapus Endorsement';
		}
		$totalEndorsement = $this->mEndorsement->countEndorsement($dataEndorse["user_affected_id"],$dataEndorse["skill_id"]);
		$labelCounter = "";
		if($totalEndorsement > 0){
			$labelCounter = '<a style="font-size:10.5pt;">
								(Di-endorse oleh '.$totalEndorsement.' user)
							 </a>';
		}
		$return = 	array('<input type="hidden" name="is-endorsed" value="'.$newValue.'"/>
					 <button class="btn-small secondary-content blue darken-4 endorse-skill">'.$buttonLabel.'</button>', $labelCounter);
		//var_dump($return);
		echo json_encode($return);
	}

	//fungsi tambah perusahaan hanya dengan nama perusahan yg lainnya 0/""
	function tambahPerusahaan($companyName){
		$dataInsertPerusahaan["company_name"] = $companyName;
		$dataInsertPerusahaan["company_description"] = "";
		$dataInsertPerusahaan["company_size"] = "0";
		$dataInsertPerusahaan["company_type"] = "";
		$dataInsertPerusahaan["cover_url"] = "";
		$dataInsertPerusahaan["logo_url"] = "";
		$dataInsertPerusahaan["website_url"] = "";
		$dataInsertPerusahaan["year_founded"] = "0000";
		$this->mCompanies->insertCompanies($dataInsertPerusahaan);
	}

	//fungsi untuk tambah universitas
	function tambahUniversitas($universityID, $status){
		$dataInsertUniversitas["university_id"] = $universityID;
		$dataInsertUniversitas["status"] = $status;
		$this->mUniversities->insertUniversity($dataInsertUniversitas);
	}

	//fungsi untuk ambil gambar
	function ambilGambar($element_name, $destination_img_name){
		$check = getimagesize($_FILES[$element_name]["tmp_name"]);
			
		//check if an image
		if($check !== false) {
			
			//convert image to base64
			$img_type = explode("/",$check["mime"]);
			$image = explode('"',$check[3]);
			$dataImage = base64_encode(file_get_contents( $_FILES[$element_name]["tmp_name"] ));
			$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
			
			// $source_img = $_FILES[$element_name]["name"];
			$source_img = $imageData;
			$destination_img = $destination_img_name.'.jpg';
			$d = $this->compress($source_img, $destination_img, 40);
			$imageData = base64_encode(file_get_contents($d));
			
			//delete image
			unlink($destination_img);
			$imageData = 'data:image/jpeg;base64,' . $imageData;

			//
			return $imageData;
		} else {
			//echo "File is not an image.";
			return "";
		}
	}

	//fungsi untuk kompress gambar
	function compress($source, $destination, $quality) {

		$info = getimagesize($source);

		if ($info['mime'] == 'image/jpeg') 
			$image = imagecreatefromjpeg($source);

		elseif ($info['mime'] == 'image/gif') 
			$image = imagecreatefromgif($source);

		elseif ($info['mime'] == 'image/png') 
			$image = imagecreatefrompng($source);

		imagejpeg($image, $destination, $quality);
		// imagedestroy($image);
		return $destination;
	}
	
}
