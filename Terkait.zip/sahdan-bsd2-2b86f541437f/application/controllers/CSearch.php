<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CSearch extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mUsers');
        $this->load->model('mCompanies');
        $this->load->model('mConversation');
        $this->load->model('mNotifications');
		$this->load->model('mUser_Connections');
		$this->load->library('session');
    }
    
    public function index($keyword){
        //decode kata kunci
        $keyword = rawurldecode($keyword);
        //split kata kunci menjadi array berdasar spasi
        $keyword = preg_split('/ +/', $keyword);
        $param["search_result_user"] = $this->mUsers->selectSearchUser($keyword);
        $param["search_result_company"] = $this->mCompanies->selectSearchCompany($keyword);
        $param["countMsg"] = $this->loadNotifMsg();
		$param["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
		$param["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
        $param["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
        $param["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
        //var_dump($param["search_result_user"]);
        $this->load->view('search', $param);
    }

    //load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}

    public function redirectPage($name){
        //decode name
        $name = rawurldecode($name);
        $userId = $this->mUsers->selectIdByName($name);
        if(!empty($userId)){
            redirect(base_url('CProfile/index/').$userId[0]['user_id']);
        }else{
            $companyId = $this->mCompanies->getIdByName($name);
            if(!empty($companyId)){
                redirect(base_url('CPerusahaan/index/').$companyId[0]['company_id']);
            }else{
                redirect(base_url('CHome'));
            }
        }
    }

    public function getSuggestion(){
        $keyword = $this->input->get_post('keyword');

        $param = array();
        $param[] = $this->mUsers->selectSearchUsersName($keyword);
        $param[] = $this->mCompanies->selectCompany($keyword);
        echo json_encode($param);
    }
}