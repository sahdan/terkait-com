<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CAdmin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mAccounts');
		$this->load->model('mLikes');
		$this->load->model('mActivities');
		$this->load->model('mAdmin');
		$this->load->library('session');
	}
	
	public function index()
	{
		$data["reportUsers"] = $this->mAccounts->selectReport("user");
		$data["reportCompany"] = $this->mAccounts->selectReport("company");
		$data["reportPost"] = $this->mActivities->selectReportActivity("post");
		$data["reportLike"] = $this->mActivities->selectReportActivity("like");
		$data["reportComment"] = $this->mActivities->selectReportActivity("comment");
		// "0" default
		$data["reportCtrAccount"] = $this->mAccounts->selectReportMontly("0");
		$data["reportCtrWeb"] = $this->mAdmin->selectCtrVisit();
		if($_SESSION["user_id"] == "admin"){
			$this->load->view('admin', $data);
		}
		else
		{
			Redirect(base_url('CLogin/loginAdmin'), false);
		}
	}
	
	public function listAdmin()
	{
		if($_SESSION["user_id"] == "admin"){
			
			$data["listAdmin"] = $this->mAdmin->selectAllAdmin();
			$this->load->view('listAdmin', $data);
		}
		else
		{
			Redirect(base_url('CLogin/loginAdmin'), false);
		}
	}
	
	public function ajaxEdit()
	{
		if($_SESSION["user_id"] == "admin"){
			$id = $this->input->get_post('id');
			$data["listAdmin"] = $this->mAdmin->selectByIdAdmin($id);
			$this->load->view('ajax/ajaxEditAdmin', $data);
		}
		else
		{
			Redirect(base_url('CLogin/loginAdmin'), false);
		}
	}
	
	public function deleteAdmin()
	{
		if($_SESSION["user_id"] == "admin"){
			$id = $this->uri->segment(3);
			$this->mAdmin->deleteAdmin($id);
			Redirect(base_url('CAdmin/listAdmin'), false);
		}
		else
		{
			Redirect(base_url('CLogin/loginAdmin'), false);
		}
	}
	
	public function recoverAdmin()
	{
		if($_SESSION["user_id"] == "admin"){
			$id = $this->uri->segment(3);
			$this->mAdmin->recoverAdmin($id);
			Redirect(base_url('CAdmin/listAdmin'), false);
		}
		else
		{
			Redirect(base_url('CLogin/loginAdmin'), false);
		}
	}
	
	public function addAdmin()
	{
		$dataInsert["admin_first_name"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edFirstName')));
		$dataInsert["admin_last_name"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edLastName')));
		$dataInsert["admin_email"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edEmail')));
		$dataInsert["admin_password"] = md5(str_replace("'","", str_replace('"',"", $this->input->get_post('edPassword'))));
		$dataInsert["status"] = 1;
		$confPassword =  md5(str_replace("'","", str_replace('"',"", $this->input->get_post('edConfPassword'))));
		if($dataInsert["admin_password"] == $confPassword){
			$this->mAdmin->insertAdmin($dataInsert);
		}
		// var_dump($dataInsert);
        Redirect(base_url('CAdmin/listAdmin'), false);
	}
	
	public function editAdmin()
	{
		$id = $this->input->get_post('edId');
		$dataInsert["admin_first_name"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edFirstName')));
		$dataInsert["admin_last_name"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edLastName')));
		$dataInsert["admin_email"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edEmail')));
		$dataInsert["admin_password"] = md5(str_replace("'","", str_replace('"',"", $this->input->get_post('edPassword'))));
		$confPassword =  md5(str_replace("'","", str_replace('"',"", $this->input->get_post('edConfPassword'))));
		if($dataInsert["admin_password"] == $confPassword){
			$this->mAdmin->updateAdmin($id, $dataInsert);
		}
        Redirect(base_url('CAdmin/listAdmin'), false);
	}
	
	
}
