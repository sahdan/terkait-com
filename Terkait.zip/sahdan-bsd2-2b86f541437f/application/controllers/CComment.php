<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CComment extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mPost');
		$this->load->model('mLikes');
		$this->load->model('mActivities');
		$this->load->model('mComments');
		$this->load->library('session');
	}
	
	public function index()
	{
		$data["post"] = $this->mPost->selectAllComment();
		
		
		$this->load->view('dashboard', $data);
	}
	
	public function ajaxLoadComment()
	{
		$idPost = $this->input->get_post('id');
		$data["comments"] = $this->mComments->selectByIdPost($idPost);
		$this->load->view('ajax/ajaxLoadComment', $data);
	}
	
	public function ajaxLoadCommentCompany()
	{
		$idPost = $this->input->get_post('id');
		$data["comments"] = $this->mComments->selectByIdPost($idPost);
		$this->load->view('ajax/ajaxLoadCommentCompany', $data);
	}
	
	public function submit_comment()
	{
		$dataInsert["comment_content"] = $this->input->get_post('edContent');
		$dataInsert["parent_activity_id"] = $this->input->get_post('edIdPost');
		$imageData = "";
		
		foreach($this->mActivities->selectMaxId() as $data){
			$dataInsert["comment_id"] = $data->jumlah;
		}
		
		//check if post image
		if($_FILES["edImage"]["tmp_name"] != null)
		{
			$check = getimagesize($_FILES["edImage"]["tmp_name"]);
			
			//check if an image
			if($check !== false) {
				
				//convert image to base64
				$img_type = explode("/",$check["mime"]);
				$image = explode('"',$check[3]);
				$dataImage = base64_encode(file_get_contents( $_FILES["edImage"]["tmp_name"] ));
				$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
				
				// $source_img = $_FILES["edImage"]["name"];
				$source_img = $imageData;
				$destination_img = $dataInsert["comment_id"].'.jpg';
				$d = $this->compress($source_img, $destination_img, 40);
				$imageData = base64_encode(file_get_contents($d));
				
				//delete image
				unlink($destination_img);
				$imageData = 'data:image/jpeg;base64,' . $imageData;
				
			} else {
				//echo "File is not an image.";
			}
		}
		$dataInsert["image_link"] = $imageData;
		$dataInsert["account_id"] = $_SESSION["user_id"];
		if($dataInsert["comment_content"] != "" || $dataInsert["image_link"] != ""){
			$this->mComments->insertComment($dataInsert);
		}
		
		$idPost = $dataInsert["parent_activity_id"];
		$data1["comments"] = $this->mComments->selectByIdUser($idPost, $_SESSION["user_id"]);
		$this->load->view('ajax/ajaxLoadComment', $data1);
	}
	
	public function submit_comment_company()
	{
		$dataInsert["comment_content"] = $this->input->get_post('edContent');
		$dataInsert["parent_activity_id"] = $this->input->get_post('edIdPost');
		$imageData = "";
		
		foreach($this->mActivities->selectMaxId() as $data){
			$dataInsert["comment_id"] = $data->jumlah;
		}
		
		//check if post image
		if($_FILES["edImage"]["tmp_name"] != null)
		{
			$check = getimagesize($_FILES["edImage"]["tmp_name"]);
			
			//check if an image
			if($check !== false) {
				
				//convert image to base64
				$img_type = explode("/",$check["mime"]);
				$image = explode('"',$check[3]);
				$dataImage = base64_encode(file_get_contents( $_FILES["edImage"]["tmp_name"] ));
				$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
				
				// $source_img = $_FILES["edImage"]["name"];
				$source_img = $imageData;
				$destination_img = $dataInsert["comment_id"].'.jpg';
				$d = $this->compress($source_img, $destination_img, 40);
				$imageData = base64_encode(file_get_contents($d));
				
				//delete image
				unlink($destination_img);
				$imageData = 'data:image/jpeg;base64,' . $imageData;
				
			} else {
				//echo "File is not an image.";
			}
		}
		$dataInsert["image_link"] = $imageData;
		$dataInsert["account_id"] = $this->input->get_post('edIdCompany');
		if($dataInsert["comment_content"] != "" || $dataInsert["image_link"] != ""){
			$this->mComments->insertComment($dataInsert);
		}
		
		$idPost = $dataInsert["parent_activity_id"];
		$data1["comments"] = $this->mComments->selectByIdUser($idPost, $dataInsert["account_id"]);
		$this->load->view('ajax/ajaxLoadCommentCompany', $data1);
	}
	
	//compress image quality
	function compress($source, $destination, $quality) {

		$info = getimagesize($source);

		if ($info['mime'] == 'image/jpeg') 
			$image = imagecreatefromjpeg($source);

		elseif ($info['mime'] == 'image/gif') 
			$image = imagecreatefromgif($source);

		elseif ($info['mime'] == 'image/png') 
			$image = imagecreatefrompng($source);

		imagejpeg($image, $destination, $quality);
		return $destination;
	}
	
	
	//edit comment -> modal-edit-comment
	public function ajaxEditComment()
	{
		$id = $this->input->get_post('id');
		$data["comment"] = $this->mComments->selectByIdComment($id);
		$this->load->view('ajax/ajaxComment', $data);
	}

	//delete comment -> modal-delete-comment
    public function deleteComment($id)
    {
        $this->mActivities->disableActivities($id);
        Redirect(base_url('CHome/dashboard'), false);
	}
	
	public function edit_comment()
	{
		$idComment = $this->input->get_post('edIdComment');
		$dataInsert["comment_content"] = $this->input->get_post('edContent');
		$imageData = "";	//Sebagai penanda image kosong
		
		//check if post image
		if($_FILES["edImage"]["tmp_name"] != null)
		{
			$check = getimagesize($_FILES["edImage"]["tmp_name"]);
			
			//check if an image
			if($check !== false) {
				
				//convert image to base64
				$img_type = explode("/",$check["mime"]);
				$image = explode('"',$check[3]);
				$dataImage = base64_encode(file_get_contents( $_FILES["edImage"]["tmp_name"] ));
				$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
				
				// $source_img = $_FILES["edImage"]["name"];
				$source_img = $imageData;
				$destination_img = $idComment.'.jpg';
				$d = $this->compress($source_img, $destination_img, 40);
				$imageData = base64_encode(file_get_contents($d));
				
				//delete image
				unlink($destination_img);
				$imageData = 'data:image/jpeg;base64,' . $imageData;
				
			} else {
				//echo "File is not an image.";
			}
			
			$dataInsert["image_link"] = $imageData;
			
			//update post
			if($dataInsert["comment_content"] != "" || $dataInsert["image_link"] != ""){
				$this->mComments->updateComment($idComment, $dataInsert);
			}
		}
		else
		{
			//update post
			if($dataInsert["comment_content"] != ""){
				$this->mComments->updateComment($idComment, $dataInsert);
			}
		}
		
		Redirect(base_url('CHome/dashboard'), false);
	}
	
	public function ajaxLoadCommentSub()
	{
		$idPost = $this->input->get_post('id');
		$data["comments"] = $this->mComments->selectByIdUser($idPost, $_SESSION["user_id"]);
		$this->load->view('ajax/ajaxLoadComment', $data);
	}
	
}
