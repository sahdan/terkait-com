<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CPost extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mPost');
		$this->load->model('mLikes');
		$this->load->model('mActivities');
		$this->load->library('session');
	}
	
	public function index()
	{
		$data["post"] = $this->mPost->select10Post();
		$this->load->view('dashboard', $data);
	}
	
	public function like($id)
	{
		$dataInsert["parent_activity_id"] = $id;
		$dataInsert["account_id"] = $_SESSION["user_id"];
		$this->mLikes->insertLikes($dataInsert);
		Redirect(base_url('CHome/dashboard'), false);
	}
	
	function timestampConverter($data) {
		date_default_timezone_set("Asia/Jakarta");
		foreach ($data as $item) {
			$item->created_at = $this->time_elapsed_string($item->created_at);
		}
		return $data;
	}
	
	function time_elapsed_string($datetime, $full = false) {
		date_default_timezone_set("Asia/Jakarta");
		$now = new DateTime;
		$ago = new DateTime($datetime);
		$diff = $now->diff($ago);
	
		$diff->w = floor($diff->d / 7);
		$diff->d -= $diff->w * 7;
	
		$string = array(
			'y' => 'tahun',
			'm' => 'bulan',
			'w' => 'minggu',
			'd' => 'hari',
			'h' => 'jam',
			'i' => 'menit',
			's' => 'detik',
		);
		foreach ($string as $k => &$v) {
			if ($diff->$k) {
				$v = $diff->$k . ' ' . $v;
			} else {
				unset($string[$k]);
			}
		}
	
		if (!$full) $string = array_slice($string, 0, 1);
		return $string ? implode(', ', $string) . ' yang lalu' : 'baru saja';
	}
	
	public function ajaxLoadPost()
	{
		$start = $this->input->get_post('startPost');
		// $end = $this->input->get_post('end');
		$count = $this->mPost->selectCountId();
		if($start<$count){
			// $start = $start+10;
			$start = $start;
		}
		// if($end<$count){
			// $end = $end+1;
		// }
		$data["post"] = $this->timestampConverter($this->mPost->selectPostStartEnd($start, $_SESSION["user_id"]));
		$data["start"] = $start+10;
		$this->load->view('ajax/ajaxLoadPost', $data);
	}
	
	public function submit_post_company()
	{
		$dataInsert["post_content"] = $this->input->get_post('edContent');
		$imageData = "";	//Sebagai penanda image kosong
		
		foreach($this->mActivities->selectMaxId() as $data){
			$dataInsert["post_id"] = $data->jumlah;
		}
		
		//check if post image
		if($_FILES["edImage"]["tmp_name"] != null)
		{
			$check = getimagesize($_FILES["edImage"]["tmp_name"]);
			
			//check if an image
			if($check !== false) {
				
				//convert image to base64
				$img_type = explode("/",$check["mime"]);
				$image = explode('"',$check[3]);
				$dataImage = base64_encode(file_get_contents( $_FILES["edImage"]["tmp_name"] ));
				$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
				
				// $source_img = $_FILES["edImage"]["name"];
				$source_img = $imageData;
				$destination_img = $dataInsert["post_id"].$img_type[1];
				$d = $this->compress($source_img, $destination_img, 40);
				$imageData = base64_encode(file_get_contents($d));
				
				//delete image
				unlink($destination_img);
				$imageData = 'data:image/'.$img_type[1].';base64,' . $imageData;
				
			} else {
				//echo "File is not an image.";
			}
		}
		$dataInsert["media_link"] = $imageData;
		$dataInsert["allow_comment"] = 1;
		$dataInsert["account_id"] = $this->uri->segment(3);//get_post()
		if($dataInsert["post_content"] != "" || $dataInsert["media_link"] != ""){
			$this->mPost->insertPosts($dataInsert);
		}
		
		Redirect(base_url('CCompany/profil/'.$this->uri->segment(3)), false);
	}
	
	//compress image quality
	function compress($source, $destination, $quality) {

		$info = getimagesize($source);

		if ($info['mime'] == 'image/jpeg'){
			$image = imagecreatefromjpeg($source);
			imagejpeg($image, $destination, $quality);
		}elseif ($info['mime'] == 'image/gif'){ 
			$image = imagecreatefromgif($source);
			imagegif($image, $destination, $quality);
		}elseif ($info['mime'] == 'image/png'){
			$image = imagecreatefrompng($source);
			imageAlphaBlending($image, true);
			imageSaveAlpha($image, true);
			$quality = $quality / 10;
			imagepng($image, $destination, $quality);
		}
		return $destination;
	}
}
