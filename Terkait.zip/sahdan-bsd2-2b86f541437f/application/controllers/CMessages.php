<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CMessages extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mMessages');
		$this->load->model('mActivities');
		$this->load->model('mConversation');
		$this->load->model('mUsers');
		$this->load->model('mUser_Connections');
		$this->load->model('mNotifications');
		$this->load->library('session');
	}
	
	//load message
	public function index()
	{
		if($this->uri->segment(3)){
			$data["runConversationId"] = $this->uri->segment(3);
		}
		// var_dump($data["runConversationId"]);
		if($_SESSION["user_id"]){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["conversation"] = $this->mConversation->selectAllConversationByIdUser($_SESSION["user_id"]);
			$data["message"] = $this->mMessages->selectAllMessageByIdUserLastSeen($_SESSION["user_id"]);
			$data["connections"] = $this->mUser_Connections->selectAllConnections($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$this->load->view('message', $data);
		}
		else{
			Redirect(base_url('CLogin'), false);
		}
		
	}
	
	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}
	
	//start conversation
	public function startConversation()
	{
		$id = $this->uri->segment(3);
		date_default_timezone_set("Asia/Jakarta");
		$timestamp=time();
		
		$data = $this->mConversation->selectConversationIfExistByIdUser($_SESSION["user_id"], $id);
		
		if(count($data) != "0"){
			foreach($data as $item){
				Redirect(base_url('CMessages/index/'.$item->conversation_id), false);
			}
		}
		else{
			if(isset($_SESSION["user_id"])){
			//untuk insert activity
			foreach($this->mActivities->selectMaxId() as $data){
				$dataInsertActivity["activity_id"] = $data->jumlah + 1;
			}
			$dataInsertActivity["account_id"] = $_SESSION["user_id"];
			$dataInsertActivity["activity_type"] = "message";
			$dataInsertActivity["created_at"] = date("Y-m-d H:i:s",$timestamp);
			$dataInsertActivity["last_modified"] = date("Y-m-d H:i:s",$timestamp);
			$dataInsertActivity["status"] = 1;
			$result = $this->mActivities->insertActivities($dataInsertActivity);
			
			//add current user to conversation room
			$dataInsert["conversation_id"] = $dataInsertActivity["activity_id"];
			$dataInsert["user_id"] = $_SESSION["user_id"];
			$this->mConversation->insertConversation($dataInsert);
			
			//add other user to conversation room
			$dataInsert["conversation_id"] = $dataInsertActivity["activity_id"];
			$dataInsert["user_id"] = $id;
			$this->mConversation->insertConversation($dataInsert);
			}
			
			$data = $this->mConversation->selectConversationIfExistByIdUser($_SESSION["user_id"], $id);
		
			foreach($data as $item){
				Redirect(base_url('CMessages/index/'.$item->conversation_id), false);
			}
			// Redirect(base_url('CMessages'), false);
		}
	}
	
	//CMessages -> create conversation room
	public function startConv()
	{
		date_default_timezone_set("Asia/Jakarta");
		$timestamp=time();
		$name = $this->input->get_post('edMember');
		
		$user_id = "";
		if($name != ""){
			foreach($this->mUser_Connections->selectAllConnections($_SESSION["user_id"]) as $item){
				if($item->name == $name){
					$user_id = $item->user_id;
				}
			}
		}
		//cek sdh punya conversation room yang sama atau tidak
		if($user_id != ""){
			$data = $this->mConversation->selectConversationIfExistByIdUser($_SESSION["user_id"], $user_id);
		}
		if(count($data) != "0"){
			foreach($data as $item){
				Redirect(base_url('CMessages/index/'.$item->conversation_id), false);
			}
		}
		else{
			if($user_id != ""){
				//untuk insert activity
				foreach($this->mActivities->selectMaxId() as $data){
					$dataInsertActivity["activity_id"] = $data->jumlah + 1;
				}
				$dataInsertActivity["account_id"] = $_SESSION["user_id"];
				$dataInsertActivity["activity_type"] = "message";
				$dataInsertActivity["created_at"] = date("Y-m-d H:i:s",$timestamp);
				$dataInsertActivity["last_modified"] = date("Y-m-d H:i:s",$timestamp);
				$dataInsertActivity["status"] = 1;
				$result = $this->mActivities->insertActivities($dataInsertActivity);
				
				//add current user to conversation room
				$dataInsert["conversation_id"] = $dataInsertActivity["activity_id"];
				$dataInsert["user_id"] = $_SESSION["user_id"];
				$this->mConversation->insertConversation($dataInsert);
				
				//add other user to conversation room
				$dataInsert["user_id"] = $user_id;
				$this->mConversation->insertConversation($dataInsert);
			}
			$data = $this->mConversation->selectConversationIfExistByIdUser($_SESSION["user_id"], $user_id);
		
			foreach($data as $item){
				Redirect(base_url('CMessages/index/'.$item->conversation_id), false);
			}
		}
		Redirect(base_url('CMessages'), false);
	}
	
	//load conversation
	public function loadConversation()
	{
		date_default_timezone_set("Asia/Jakarta");
		$timestamp=time();
		$id = $this->input->get_post('id');
		$idUser = $_SESSION["user_id"];
		$data["message"] = $this->mMessages->selectAllMessageByConversationId($id);
		$dataUpdate["last_seen"] = date("Y-m-d H:i:s",$timestamp);
		$this->mConversation->updateConversationLastSeen($id, $idUser, $dataUpdate);
		$this->load->view('ajax/ajaxMessage', $data);
	}
	
	//submit chat
	public function submit_chat()
	{
		date_default_timezone_set("Asia/Jakarta");
		$timestamp=time();
		$dataInsert["conversation_id"] = $this->input->get_post('edConversationId');
		$dataInsert["message_content"] = $this->input->get_post('edContent');
		$dataInsert["sender_user_id"] = $_SESSION["user_id"];
		$dataInsert["timestamp"] = date("Y-m-d H:i:s",$timestamp);
		$this->mMessages->insertMessage($dataInsert);
		$data["message"] = $this->mMessages->selectByIdUser($dataInsert["conversation_id"], $_SESSION["user_id"]);
		$this->load->view('ajax/ajaxMessage', $data);
	}
	
	//add other user to conversation room
	public function addMmeber()
	{
		date_default_timezone_set("Asia/Jakarta");
		$timestamp=time();
		$dataInsert["conversation_id"] = $this->input->get_post('edConversationId');
		$name = $this->input->get_post('edMember');
		$data["connections"] = $this->mUser_Connections->selectAllConnections($_SESSION["user_id"]);
		
		//cari user yang nama nya sama
		if($name != ""){
			foreach($data["connections"] as $item){
				if($item->name == $name){
					$dataInsert["user_id"] = $item->user_id;
				}
			}
			$checkConversation = $this->mConversation->selectByIdConversationAndUser($dataInsert["conversation_id"], $dataInsert["user_id"]);
			if(count($checkConversation) == 0){
				$this->mConversation->insertConversation($dataInsert);
			}
			else{
				Redirect(base_url('CMessages/index/'.$dataInsert["conversation_id"]), false);
			}
		}
		Redirect(base_url('CMessages'), false);
	}
}
