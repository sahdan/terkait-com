<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CHome extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mPost');
		$this->load->model('mUsers');
		$this->load->model('mConversation');
		$this->load->model('mActivities');
		$this->load->model('mNotifications');
		$this->load->model('mUser_Connections');
		$this->load->library('session');
	}
	
	public function index()
	{
		if($_SESSION["user_id"]){
			$data["post"] = $this->timestampConverter($this->mPost->select10Post($_SESSION["user_id"]));
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["sugestion"] = $this->mUser_Connections->selectSugestionByIdUser($_SESSION["user_id"]);
		}else{
			$data["post"] = $this->mPost->select10Post1();
		}
		$data["total"] = $this->mPost->selectCountId();
		// var_dump($data["total"]);
		$this->load->view('dashboard', $data);
	}
	
	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}
	
	//load home
	public function dashboard()
	{
		if($_SESSION["user_id"]){
			$data["post"] = $this->timestampConverter($this->mPost->select10Post($_SESSION["user_id"]));
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["sugestion"] = $this->mUser_Connections->selectSugestionByIdUser($_SESSION["user_id"]);
		}else{
			$data["post"] = $this->mPost->select10Post1();
		}
		$data["total"] = $this->mPost->selectCountId();
		$this->load->view('dashboard', $data);
	}
	
	//load specific post
	public function getPost()
	{
		$id = $this->uri->segment(3);
		if($_SESSION["user_id"]){
			$data["post"] = $this->mPost->selectPostById($_SESSION["user_id"], $id);
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
		}else{
			$data["post"] = $this->mPost->select10Post1();
		}
		$data["total"] = $this->mPost->selectCountId();
		$this->load->view('post', $data);
	}
	
	//for submit post ( status/article )
	public function submit_post()
	{
		$dataInsert["post_content"] = $this->input->get_post('edContent');
		$imageData = "";	//Sebagai penanda image kosong
		
		foreach($this->mActivities->selectMaxId() as $data){
			$dataInsert["post_id"] = $data->jumlah;
		}
		
		//check if post image
		if($_FILES["edImage"]["tmp_name"] != null)
		{
			$check = getimagesize($_FILES["edImage"]["tmp_name"]);
			
			//check if an image
			if($check !== false) {
				
				//convert image to base64
				$img_type = explode("/",$check["mime"]);
				$image = explode('"',$check[3]);
				$dataImage = base64_encode(file_get_contents( $_FILES["edImage"]["tmp_name"] ));
				$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
				
				// $source_img = $_FILES["edImage"]["name"];
				$source_img = $imageData;
				$destination_img = $dataInsert["post_id"].$img_type[1];
				$d = $this->compress($source_img, $destination_img, 40);
				$imageData = base64_encode(file_get_contents($d));
				
				//delete image
				unlink($destination_img);
				$imageData = 'data:image/'.$img_type[1].';base64,' . $imageData;
				
			} else {
				//echo "File is not an image.";
			}
		}
		$dataInsert["media_link"] = $imageData;
		$dataInsert["allow_comment"] = 1;
		$dataInsert["account_id"] = $_SESSION["user_id"];//get_post()
		if($dataInsert["post_content"] != "" || $dataInsert["media_link"] != ""){
			$this->mPost->insertPosts($dataInsert);
		}
		
		Redirect(base_url('CHome/dashboard'), false);
	}
	
	//compress image quality
	function compress($source, $destination, $quality) {

		$info = getimagesize($source);

		if ($info['mime'] == 'image/jpeg'){
			$image = imagecreatefromjpeg($source);
			imagejpeg($image, $destination, $quality);
		}elseif ($info['mime'] == 'image/gif'){ 
			$image = imagecreatefromgif($source);
			imagegif($image, $destination, $quality);
		}elseif ($info['mime'] == 'image/png'){
			$image = imagecreatefrompng($source);
			imageAlphaBlending($image, true);
			imageSaveAlpha($image, true);
			$quality = $quality / 10;
			imagepng($image, $destination, $quality);
		}
		return $destination;
	}
	
	//edit post -> modal-edit
	public function ajaxEditPost()
	{
		$id = $this->input->get_post('id');
		$data["post"] = $this->mPost->selectByIdPosts($id);
		$this->load->view('ajax/ajaxPost', $data);
	}

	//delete post -> modal-delete
    public function deletePost($id)
    {
        // $id = $this->input->get_post('id');
        // echo "<script>alert('".$id."')</script>";
        $this->mActivities->disableActivities($id);
        Redirect(base_url('CHome/dashboard'), false);
	}
	
	public function render()
	{
		$id = $this->uri->segment(3);
		$data["post"] = $this->mPost->selectByIdPosts($id);
		foreach($data["post"] as $item){
			$img = $item->media_link;
			if($img != ""){
				$image_parts = explode(";base64,", $img);
				$image_type_aux = explode("image/", $image_parts[0]);
				$image_type = $image_type_aux[1];
				$image_base64 = base64_decode($image_parts[1]);
				echo $image_base64;
			}
		}
		
	}
	
	public function edit_post()
	{
		$idPost = $this->input->get_post('edIdPost');
		$dataInsert["post_content"] = $this->input->get_post('edContent');
		$imageData = "";	//Sebagai penanda image kosong
		
		foreach($this->mActivities->selectMaxId() as $data){
			$dataInsert["post_id"] = $data->jumlah;
		}
		
		//check if post image
		if($_FILES["edImage"]["tmp_name"] != null)
		{
			$check = getimagesize($_FILES["edImage"]["tmp_name"]);
			
			//check if an image
			if($check !== false) {
				
				//convert image to base64
				$img_type = explode("/",$check["mime"]);
				$image = explode('"',$check[3]);
				$dataImage = base64_encode(file_get_contents( $_FILES["edImage"]["tmp_name"] ));
				$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
				
				// $source_img = $_FILES["edImage"]["name"];
				$source_img = $imageData;
				$destination_img = $idPost.'.jpg';
				$d = $this->compress($source_img, $destination_img, 40);
				$imageData = base64_encode(file_get_contents($d));
				
				//delete image
				unlink($destination_img);
				$imageData = 'data:image/jpeg;base64,' . $imageData;
				
			} else {
				//echo "File is not an image.";
			}
			
			$dataInsert["media_link"] = $imageData;
			
			//update post
			if($dataInsert["post_content"] != "" || $dataInsert["media_link"] != ""){
				$this->mPost->updatePosts($idPost, $dataInsert);
			}
		}
		else
		{
			//update post
			if($dataInsert["post_content"] != ""){
				$this->mPost->updatePosts($idPost, $dataInsert);
			}
		}
		
		Redirect(base_url('CHome/dashboard'), false);
	}

	function timestampConverter($data) {
		date_default_timezone_set("Asia/Jakarta");
		foreach ($data as $item) {
			$item->created_at = $this->time_elapsed_string($item->created_at);
		}
		return $data;
	}
	
	function time_elapsed_string($datetime, $full = false) {
		date_default_timezone_set("Asia/Jakarta");
		$now = new DateTime;
		$ago = new DateTime($datetime);
		$diff = $now->diff($ago);
	
		$diff->w = floor($diff->d / 7);
		$diff->d -= $diff->w * 7;
	
		$string = array(
			'y' => 'tahun',
			'm' => 'bulan',
			'w' => 'minggu',
			'd' => 'hari',
			'h' => 'jam',
			'i' => 'menit',
			's' => 'detik',
		);
		foreach ($string as $k => &$v) {
			if ($diff->$k) {
				$v = $diff->$k . ' ' . $v;
			} else {
				unset($string[$k]);
			}
		}
	
		if (!$full) $string = array_slice($string, 0, 1);
		return $string ? implode(', ', $string) . ' yang lalu' : 'baru saja';
	}
}
