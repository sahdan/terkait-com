<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CJob extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mConversation');
		$this->load->model('mSkills');
		$this->load->model('mCompanies');
		$this->load->model('mCompanies_users');
		$this->load->model('mAccounts');
		$this->load->model('mJobsSkills');
		$this->load->model('mJobsAppliers');
		$this->load->model('mJobs');
		$this->load->model('mUsers');
		$this->load->model('mNotifications');
		$this->load->model('mUser_Connections');
		$this->load->library('session');
	}
	
	public function index()
	{
		if($_SESSION["user_id"]){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["user_company"]["status"] = -1;
		//	$data["jobs"] = $this->mJobs->selectJobsOrderByOwnedSkills($_SESSION["user_id"]);
			$data["jobs"] = $this->timestampConverter($this->mJobs->selectJobsOrderByOwnedSkills($_SESSION["user_id"]));
			$this->mNotifications->updateLastSeenJob($_SESSION["user_id"]);
			$this->load->view('job', $data);
			// var_dump($data["jobs"]);
		}else{
			$this->load->view('job');
		}
	}
	
	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}
	
	public function detail($jobId = false){
		if($_SESSION["user_id"] && $jobId != false){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["job"] = $this->mJobs->selectJobDetail($_SESSION["user_id"], $jobId);
			if(count($data["job"]) > 0){
				$data["job"] = $data["job"][0];
				$data["job_skill"] = $this->mJobsSkills->selectJobSkillOwnedByUser($_SESSION["user_id"], $jobId);
				$data["job_applier"] = $this->mJobsAppliers->selectAppliersAndSkills($jobId);
				$data["job_application"] = $this->mJobsAppliers->selectUserJobApplication($_SESSION["user_id"], $jobId);
				if(count($data["job_application"]) > 0){
					$data["job_application"] = $data["job_application"][0];
				}else{
					$data["job_application"]["status"] = -1;
				}
			}
			// var_dump($data["job_application"]);
			$this->load->view('job_detail', $data);
		}
	}

	public function dataPekerjaan(){
		$jobId = $this->input->get_post('jobId');
		$job = $this->mJobs->selectByIdJobs($jobId);
		$job_skill = $this->mJobsSkills->selectJobSkillById($jobId);
		if(count($job) > 0){
			echo json_encode(array($job[0],$job_skill));
		}
	}

	public function hapusPekerjaan(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("edCompanyId");
			$jobId = $this->input->get_post("edLowonganId");
			if($this->companyAdminStatus($companyId) == "admin" || $this->companyAdminStatus($companyId) == "super_admin"){
				$this->mJobs->deleteJobs($jobId, $companyId);
				// ajax return value
				$data["job"] = $this->mJobs->selectJobDetail($_SESSION["user_id"], $jobId);
				if(count($data["job"]) > 0){
					$data["job"] = $data["job"][0];
					$data["job_skill"] = $this->mJobsSkills->selectJobSkillOwnedByUser($_SESSION["user_id"], $jobId);
					$data["job_applier"] = $this->mJobsAppliers->selectAppliersAndSkills($jobId);
					$data["job_application"] = $this->mJobsAppliers->selectUserJobApplication($_SESSION["user_id"], $jobId);
					if(count($data["job_application"]) > 0){
						$data["job_application"] = $data["job_application"][0];
					}else{
						$data["job_application"]["status"] = -1;
					}
				}
				echo json_encode(array($this->load->view("ajax/job_detail/main_info", $data, true),$this->load->view("ajax/job_detail/skill_needed", $data, true),$this->load->view("ajax/job_detail/job_appliers", $data, true)));
			}
		}
	}
	
    //fungsi load page untuk buat pekerjaan /CJob/addJob/{company_id}
	public function addJob()
	{
		$accType = $this->mAccounts->selectAccountType($this->uri->segment(3));
		//check account_type
		if($_SESSION["user_id"] && $accType == "company"){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["skills"] = $this->mSkills->selectAllSkills();
			$data["mode"] = "add";
			$data["company"] = $this->uri->segment(3);
			$data["companies"] = $this->mCompanies->getCompanyById($data["company"]);
			$this->load->view('jobAdd', $data);
		}else{
			Redirect(base_url('CJob'), false);
		}
	}
	
	//fungsi untuk load page edit pekerjaan /CJob/editJob/{job_id}
	public function editJob()
	{
		$data["job_id"] = $this->uri->segment(3);
		$dataJob = $this->mJobs->selectByIdJobs($data["job_id"]);
		foreach($dataJob as $item){
			$data["company"] = $item->company_id;
		}
		$accType = $this->mAccounts->selectAccountType($data["company"]);
		if($_SESSION["user_id"] && $accType == "company"){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["skills"] = $this->mSkills->selectAllSkills();
			$data["mode"] = "edit";
			$data["job"] = $this->mJobs->selectByIdJobs($data["job_id"]);
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["companies"] = $this->mCompanies->getCompanyById($data["company"]);
			$data["skill"] = $this->mJobsSkills->selectJobSkillById($data["job_id"]);
			$this->load->view('jobAdd', $data);
		}else{
			Redirect(base_url('CJob'), false);
		}
	}
	
	//fungsi untuk buat pekerjaan /CJob/addJob/{company_id}
	public function submitJob()
	{
		$company_id = $this->uri->segment(3);
		$accType = $this->mAccounts->selectAccountType($company_id);
		$skills = $this->input->get_post('edSkill[]');
		//check account_type
		if($accType == "company"){
			$dataInsert["job_description"] = $this->input->get_post('edDescription');
			$dataInsert["company_id"] = $company_id;
			$dataInsert["job_position"] = $this->input->get_post('edJobPosition');
			$dataInsert["seniority_level"] = $this->input->get_post('edSeniorityLevel');
			$dataInsert["industry"] = $this->input->get_post('edIndustry');
			$dataInsert["employment_type"] = $this->input->get_post('edEmploymentType');
			$dataInsert["job_functions"] = $this->input->get_post('edJobFunction');
			$dataInsert["min_gaji"] = $this->input->get_post('edMinSalary');
			$dataInsert["max_gaji"] = $this->input->get_post('edMaxSalary');
			$dataInsert["expired_at"] = $this->input->get_post('edExpired');
			$dataInsert["status"] = 1;
			$this->mJobs->insertJobs($dataInsert);
			//insert skill requirement
			for($i = 0; $i < count($skills);$i++){
				$dataInsertJobSkill["job_id"] = $this->mJobs->selectMaxId();
				$dataInsertJobSkill["skill_id"] = $skills[$i];
				$this->mJobsSkills->insertJobSkill($dataInsertJobSkill);
			}
			//Membuat Objek Notifikasi
			$notifObjInsert["notif_obj_id"] = $this->mNotifications->selectMaxNotifObjId() + 1;
			$notifObjInsert["object_type"] = "Lowongan Kerja";
			$notifObjInsert["object_id"] = $this->mJobs->selectMaxId();
			$notifObjInsert["object_url"] = "CJob/detail/".$dataInsertJobSkill["job_id"];
			$this->mNotifications->insertNotifObject($notifObjInsert);

			//Membuat Notifikasi untuk tiap user yang memiliki skill yang sama
			$users = $this->mJobsSkills->selectUsersByJobSkills($dataInsertJobSkill["job_id"]);
			foreach ($users as $user) {
				$notifInsert["notification_id"] = $this->mNotifications->selectMaxNotifId() + 1;
				$notifInsert["notif_obj_id"] = $notifObjInsert["notif_obj_id"];
				$notifInsert["user_id"] = $user->user_id;
				$this->mNotifications->insertNotif($notifInsert);
			}

			//Membuat Notifikasi action
			$notifActInsert["notif_act_id"] = $this->mNotifications->selectMaxNotifActId() + 1;
			$notifActInsert["notif_obj_id"] = $notifObjInsert["notif_obj_id"];
			$notifActInsert["actor_user_id"] = $company_id;
			$notifActInsert["action"] = "Memuat";
			$date = new DateTime(); //Waktu dalam UTC
			$date->add(new DateInterval('PT21660S'));	//+6 Jam karena WIB + 60 detik
			$notifActInsert["timestamp2"] = $date->format('Y-m-d H:i:s');
			$this->mNotifications->insertNotifAction($notifActInsert);
		}
		Redirect(base_url('CJob'), false);
	}
	
	//fungsi untuk edit pekerjaan /CJob/editJob/{job_id}
	public function submitEditJob()
	{
		$job_id = $this->uri->segment(3);
		$skills = $this->input->get_post('edSkill[]');
		$dataInsert["job_description"] = $this->input->get_post('edDescription');
		$dataInsert["job_position"] = $this->input->get_post('edJobPosition');
		$dataInsert["seniority_level"] = $this->input->get_post('edSeniorityLevel');
		$dataInsert["industry"] = $this->input->get_post('edIndustry');
		$dataInsert["employment_type"] = $this->input->get_post('edEmploymentType');
		$dataInsert["job_functions"] = $this->input->get_post('edJobFunction');
		$dataInsert["min_gaji"] = $this->input->get_post('edMinSalary');
		$dataInsert["max_gaji"] = $this->input->get_post('edMaxSalary');
		$dataInsert["expired_at"] = $this->input->get_post('edExpired');
		$dataInsert["status"] = 1;
		$this->mJobs->updateJobs($job_id, $dataInsert);
		//delete all skill requirement by job_id
		$this->mJobsSkills->deleteJobSkill($job_id);
		//insert skill requirement
		for($i = 0; $i < count($skills);$i++){
			$dataInsertJobSkill["job_id"] = $job_id;
			$dataInsertJobSkill["skill_id"] = $skills[$i];
			$this->mJobsSkills->insertJobSkill($dataInsertJobSkill);
		}
		Redirect(base_url('CJob'), false);
	}
	
	//fungsi untuk hapus pekerjaan /CJob/deleteJob/{job_id}
	public function deleteJob()
	{
		$job_id = $this->uri->segment(3);
		$this->mJobs->deleteJobs($job_id);
		Redirect(base_url('CJob'), false);
	}

	public function editPekerjaan(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("edCompanyId");
			$dataJob["company_id"] = $companyId;
			if($this->companyAdminStatus($companyId) == "admin" || $this->companyAdminStatus($companyId) == "super_admin"){
				$jobId = $this->input->get_post("edLowonganId");
				$loginID = $_SESSION["user_id"];
				$dataJob["job_description"] = $this->input->get_post('edDescription');
				$dataJob["seniority_level"] = $this->input->get_post('edSeniorityLevel');
				$dataJob["industry"] = $this->input->get_post('edIndustry');
				$dataJob["employment_type"] = $this->input->get_post('edEmploymentType');
				$dataJob["job_functions"] = $this->input->get_post('edJobFunction');
				$dataJob["min_gaji"] = $this->input->get_post('edMinSalary');
				$dataJob["max_gaji"] = $this->input->get_post('edMaxSalary');
				$dataJob["expired_at"] = $this->input->get_post('edExpired');
				$dataJob["status"] = 1;
				$this->mJobs->updateJobs($jobId, $companyId, $dataJob);

				$this->mJobsSkills->deleteJobSkill($jobId);
				$skills = $this->input->get_post('edSkill');
				if(is_array($skills)){
					for($i = 0; $i < count($skills);$i++){
						$dataJobSkills["skill_id"] = $this->mSkills->getIdByName(strtolower($skills[$i]));
						if(empty($dataJobSkills["skill_id"])){
							$dataSkill = array();
							$dataSkill["skill_name"] = $skills[$i];
							$this->mSkills->insertSkill($dataSkill);
							unset($dataSkill);
							$dataJobSkills["skill_id"] = $this->mSkills->getIdByName(strtolower($skills[$i]));
						}
						$dataJobSkills["job_id"] = $jobId;
						$this->mJobsSkills->insertJobSkill($dataJobSkills);
					}
				}

				// ajax return value
				$data["job"] = $this->mJobs->selectJobDetail($_SESSION["user_id"], $jobId);
				if(count($data["job"]) > 0){
					$data["job"] = $data["job"][0];
					$data["job_skill"] = $this->mJobsSkills->selectJobSkillOwnedByUser($_SESSION["user_id"], $jobId);
					$data["job_applier"] = $this->mJobsAppliers->selectAppliersAndSkills($jobId);
					$data["job_application"] = $this->mJobsAppliers->selectUserJobApplication($_SESSION["user_id"], $jobId);
					if(count($data["job_application"]) > 0){
						$data["job_application"] = $data["job_application"][0];
					}else{
						$data["job_application"]["status"] = -1;
					}
				}
				echo json_encode(array($this->load->view("ajax/job_detail/main_info", $data, true),$this->load->view("ajax/job_detail/skill_needed", $data, true),$this->load->view("ajax/job_detail/job_appliers", $data, true)));
			}
		}	
	}

	public function lamarPekerjaan(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post('companyId');
			if($this->companyAdminStatus($companyId) == "user"){
				$data["JOB_ID"] = $this->input->get_post('jobId');
				$data["APPLIER_ID"] = $_SESSION["user_id"];
				$data["STATUS"] = "1";

				$job = $this->mJobs->selectByIdJobs($data["JOB_ID"]);
				if($this->input->get_post('status') == -1 && count($job) > 0 && $job[0]->status == "1" && $job[0]->company_id == $companyId){
					$this->mJobsAppliers->insert($data);
					echo "success";
				}
			}
		}
	}

	public function searchJob(){
		if($this->isRequestMethodPost()){
			$keyword = $this->input->get_post('keyword');
			$data["user_company"]["status"] = -1;
			$data["jobs"] = $this->mJobs->selectJobsOrderByOwnedSkillsWithKeyword($_SESSION["user_id"], $keyword);
			// var_dump($data);
			$this->load->view("ajax/ajaxCompanyJobs", $data);
		}
	}

	function companyAdminStatus($companyId){
		if(isset($_SESSION["user_id"])){
			$userId = $_SESSION["user_id"];
			$temp = $this->mCompanies_users->selectByBothId($userId, $companyId);
			if($temp){
				return "admin";
			}else{
				return "user";
			}
		}else{
			return "no_user";
		}
	}

	function isRequestMethodPost(){
		if($_SERVER["REQUEST_METHOD"] == 'POST'){
			return true;
		}else{
			$this->load->view('dashboard');
		}
	}

	function timestampConverter($data) {
		foreach ($data as $item) {
			$item->created_at = $this->time_elapsed_string($item->created_at);
		}
		return $data;
	}
	
	function time_elapsed_string($datetime, $full = false) {
		$now = new DateTime;
		$ago = new DateTime($datetime);
		$diff = $now->diff($ago);
	
		$diff->w = floor($diff->d / 7);
		$diff->d -= $diff->w * 7;
	
		$string = array(
			'y' => 'tahun',
			'm' => 'bulan',
			'w' => 'minggu',
			'd' => 'hari',
			'h' => 'jam',
			'i' => 'menit',
			's' => 'detik',
		);
		foreach ($string as $k => &$v) {
			if ($diff->$k) {
				$v = $diff->$k . ' ' . $v;
			} else {
				unset($string[$k]);
			}
		}
	
		if (!$full) $string = array_slice($string, 0, 1);
		return $string ? implode(', ', $string) . ' yang lalu' : 'baru saja';
	}
}
