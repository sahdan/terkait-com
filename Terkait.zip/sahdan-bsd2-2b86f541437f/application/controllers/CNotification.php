<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CNotification extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mConversation');
		$this->load->model('mUsers');
		$this->load->model('mNotifications');
		$this->load->model('mUser_Connections');
		$this->load->library('session');
		
	}
	
	public function index()
	{
		$data["countMsg"] = $this->loadNotifMsg();
		$data["countNotif"] = 0;
		$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
		$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
		$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
		$data["newNotifAct"] = $this->timestampConverter($this->mNotifications->selectNewNotifications($_SESSION["user_id"]));
		$data["oldNotifAct"] = $this->timestampConverter($this->mNotifications->selectOldNotifications($_SESSION["user_id"]));
		$this->load->view('notification', $data);
		$this->mNotifications->updateLastSeen($_SESSION["user_id"]);
	}
	
	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}

	function timestampConverter($data) {
		foreach ($data as $item) {
			$item->TIMESTAMP2 = $this->time_elapsed_string($item->TIMESTAMP2);
		}
		return $data;
	}
	
	function time_elapsed_string($datetime, $full = false) {
		$now = new DateTime;
		$ago = new DateTime($datetime);
		$diff = $now->diff($ago);
	
		$diff->w = floor($diff->d / 7);
		$diff->d -= $diff->w * 7;
	
		$string = array(
			'y' => 'tahun',
			'm' => 'bulan',
			'w' => 'minggu',
			'd' => 'hari',
			'h' => 'jam',
			'i' => 'menit',
			's' => 'detik',
		);
		foreach ($string as $k => &$v) {
			if ($diff->$k) {
				$v = $diff->$k . ' ' . $v;
			} else {
				unset($string[$k]);
			}
		}
	
		if (!$full) $string = array_slice($string, 0, 1);
		return $string ? implode(', ', $string) . ' yang lalu' : 'baru saja';
	}
	
}
