<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CNetwork extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mConversation');
		$this->load->model('mUsers');
		$this->load->model('mNotifications');
		$this->load->model('mUser_Connections');
		$this->load->library('session');
	}
	
	public function index()
	{
		if($_SESSION["user_id"]){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["sugestion"] = $this->mUser_Connections->selectAllSugestionByIdUser($_SESSION["user_id"]);
			$data["pending"] = $this->mUser_Connections->selectUsersPendingRequest($_SESSION["user_id"]);
			$this->load->view('network', $data);
		}else{
			$this->load->view('network');
		}
	}
	
	public function NetworkList()
	{
		if($_SESSION["user_id"]){
			$data["countMsg"] = $this->loadNotifMsg();
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["connections"] = $this->mUser_Connections->selectAllConnections($_SESSION["user_id"]);
			$this->load->view('networklist', $data);
		}else{
			$this->load->view('networklist');
		}
	}
	
	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}
	
}
