<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CCompany extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mAccount_Followers');
		$this->load->model('mCity');
		$this->load->model('mCompanies');
		$this->load->model('mCompany_locations');
		$this->load->model('mConversation');
		$this->load->model('mCompanies_users');
		$this->load->model('mNotifications');
		$this->load->model('mProvince');
		$this->load->model('mUsers');
		$this->load->model('mJobs');
		$this->load->model('mPost');
		$this->load->model('mJobsSkills');
		$this->load->model('mSkills');
		$this->load->model('mAccounts');
		$this->load->model('mUser_Connections');
		$this->load->library('session');
	}
	
	public function index()
	{
		if(isset($_SESSION["user_id"])){
			$param["countMsg"] = $this->loadNotifMsg();
			$loginID = $_SESSION["user_id"];
			$param["user_company"] = $this->mCompanies_users->selectByUserId($loginID);
			$param["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$param["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$param["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$param["loginID"] = $loginID;
			$param["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$param["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			// var_dump($param["user_company"]);
			$this->load->view('user_company', $param);
		}else{
			$this->load->view('login');
		}
	}

	public function loadPost(){
		$id = $this->uri->segment(3);
		$data["post"] = $this->mPost->select10PostCompany($id);
		$this->load->view('feedCompany', $data);
		
	}
	
	public function profil($companyId)
	{
		if(isset($_SESSION["user_id"])){
			if($companyId){
				$param["reportJobs"] = $this->mJobs->selectReportJobs($companyId);
				$param["reportApplier"] = $this->mJobs->selectReportJobsAppliers($companyId);
				$param["ctr_visit"] = $this->mAccounts->selectCtrVisit($companyId);
				$param["countMsg"] = $this->loadNotifMsg();
				$loginID = $_SESSION["user_id"];
				$param["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
				$param["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
				$param["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
				$param["loginID"] = $loginID;
				$param["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
				$param["company"] = $this->mCompanies->getCompanyById($companyId);
				$param["user_company"] = $this->mCompanies_users->selectByBothId($loginID, $companyId);
				$param["city"] = $this->mCity->selectAllCities();
				$param["province"] = $this->mProvince->selectAllProvinces();
				$param["followCount"] = $this->mAccount_Followers->followCount($companyId);
				$param["jobs"] = $this->mJobs->selectJobsByCompanyId($loginID, $companyId);
				$param["follow_status"] = $this->mAccount_Followers->isFollowing($loginID, $companyId);
				$id = $this->uri->segment(3);
				$param["post"] = $this->mPost->select10PostCompany($id);
				if(count($param["user_company"]) == 0){
					$param["user_company"]["status"] = "-1";
				}else{
					$param["user_company"] = $param["user_company"][0];
					$param["connections"] = $this->mUser_Connections->selectAllConnections($_SESSION["user_id"]);
					$param["admin_company"] = $this->mCompanies_users->selectAdmin($companyId);
					$param["admin_company_id"] = array();
					foreach($param["admin_company"] as $item){
						$param["admin_company_id"][] = $item["user_id"];
					}
				}

				if(count($param["company"]) == 0){
					$this->load->view('dashboard');
				}else{
					$param["company"] = $param["company"][0];
					$param["company_locations"] = $this->mCompany_locations->selectCompanyLocations($companyId);
				}

				//
				$this->mAccounts->updateCtrAccount($companyId);
				// $param["skills"] = $this->mSkills->selectAllSkills();
				// $param["mode"] = "add";
				//
				// var_dump($param["jobs"]);
				$this->load->view('company', $param);
			}else{
				$this->load->view('dashboard');	
			}
		}else{
			$this->load->view('login');
		}
	}
	
	public function report($companyId)
	{
		
		if($_SESSION["user_id"]){
			$data["reportJobs"] = $this->mJobs->selectReportJobs($companyId);
			$data["reportApplier"] = $this->mJobs->selectReportJobsAppliers($companyId);
			
			$data["countMsg"] = $this->loadNotifMsg();
			$data["user"] = $this->mUsers->selectUser($_SESSION["user_id"]);
			$data["countNotif"] = $this->mNotifications->selectCountNotif($_SESSION["user_id"]);
			$data["countJob"] = $this->mNotifications->selectCountNotifJob($_SESSION["user_id"]);
			$data["countRequest"] = $this->mUser_Connections->getRequestCount($_SESSION["user_id"]);
			$data["company"] = $this->uri->segment(3);
			$data["companies"] = $this->mCompanies->getCompanyById($data["company"]);
			$data["ctr_visit"] = $this->mAccounts->selectCtrVisit($companyId);
			$this->load->view('reportCompany', $data);
		}else{
			$this->load->view('user_company');
		}
	}
	
	public function hapusPekerjaan(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("edCompanyId");
			$jobId = $this->input->get_post("edLowonganId");
			if($this->companyAdminStatus($companyId) == "admin" || $this->companyAdminStatus($companyId) == "super_admin"){
				$this->mJobs->deleteJobs($jobId, $companyId);
				$param["jobs"] = $this->mJobs->selectJobsByCompanyId($_SESSION["user_id"], $companyId);
				$param["user_company"] = $this->mCompanies_users->selectByBothId($_SESSION["user_id"], $companyId);
				if(count($param["user_company"]) == 0){
					$param["user_company"]["status"] = "-1";
				}else{
					$param["user_company"] = $param["user_company"][0];
				}
				$this->load->view("ajax/ajaxCompanyJobs", $param);
			}
		}
	}

	public function tambahAdmin(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("companyId");
			$userId = $this->input->get_post("userId");
			$connectionStatus = $this->mUser_Connections->getStatusConnection($_SESSION["user_id"], $userId);
			//kalau ada koneksi ambil status koneksi, 
			if($connectionStatus != null){
				$connectionStatus = $connectionStatus[0]["status2"];
			}else{
				$connectionStatus = "-1";
			}

			if($this->companyAdminStatus($companyId) == "super_admin" && $connectionStatus == "1"){
				$dataCompaniesUsers["user_id"] = $userId;
				$dataCompaniesUsers["company_id"] = $companyId;
				$dataCompaniesUsers["status"] = "0";
				$this->mCompanies_users->insert($dataCompaniesUsers);
				$param["connections"] = $this->mUser_Connections->selectAllConnections($_SESSION["user_id"]);
				$param["admin_company"] = $this->mCompanies_users->selectAdmin($companyId);
				$param["admin_company_id"] = array();
				foreach($param["admin_company"] as $item){
					$param["admin_company_id"][] = $item["user_id"];
				}
				echo json_encode(array($this->load->view("ajax/company/admin_company", $param, true), $this->load->view("ajax/company/modal_admin_company", $param, true)));
			}
		}
	}

	public function hapusAdmin(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("edCompanyId");
			$userId = $this->input->get_post("edAdminId");
			$connectionStatus = $this->mUser_Connections->getStatusConnection($_SESSION["user_id"], $userId);
			//kalau ada koneksi ambil status koneksi, 
			if($connectionStatus != null){
				$connectionStatus = $connectionStatus[0]["status2"];
			}else{
				$connectionStatus = "-1";
			}

			if($this->companyAdminStatus($companyId) == "super_admin" && $connectionStatus == "1"){
				$this->mCompanies_users->delete($userId, $companyId);
				$param["connections"] = $this->mUser_Connections->selectAllConnections($_SESSION["user_id"]);
				$param["admin_company"] = $this->mCompanies_users->selectAdmin($companyId);
				$param["admin_company_id"] = array();
				foreach($param["admin_company"] as $item){
					$param["admin_company_id"][] = $item["user_id"];
				}
				echo json_encode(array($this->load->view("ajax/company/admin_company", $param, true), $this->load->view("ajax/company/modal_admin_company", $param, true)));
			}
		}
	}

	public function tambahPekerjaan()
	{
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("edCompanyId");
			$dataJob["company_id"] = $companyId;
			if($this->companyAdminStatus($companyId) == "admin" || $this->companyAdminStatus($companyId) == "super_admin"){
				$loginID = $_SESSION["user_id"];
				$dataJob["job_description"] = $this->input->get_post('edDescription');
				$dataJob["seniority_level"] = $this->input->get_post('edSeniorityLevel');
				$dataJob["industry"] = $this->input->get_post('edIndustry');
				$dataJob["employment_type"] = $this->input->get_post('edEmploymentType');
				$dataJob["job_functions"] = $this->input->get_post('edJobFunction');
				$dataJob["min_gaji"] = $this->input->get_post('edMinSalary');
				$dataJob["max_gaji"] = $this->input->get_post('edMaxSalary');
				$dataJob["created_at"] = $this->input->get_post('edCreated');
				$dataJob["expired_at"] = $this->input->get_post('edExpired');
				$dataJob["status"] = 1;
				$this->mJobs->insertJobs($dataJob);

				$skills = $this->input->get_post('edSkill');
				for($i = 0; $i < count($skills);$i++){
					$dataJobSkills["skill_id"] = $this->mSkills->getIdByName(strtolower($skills[$i]));
					if(empty($dataJobSkills["skill_id"])){
						$dataSkill = array();
						$dataSkill["skill_name"] = $skills[$i];
						$this->mSkills->insertSkill($dataSkill);
						unset($dataSkill);
						$dataJobSkills["skill_id"] = $this->mSkills->getIdByName(strtolower($skills[$i]));
					}
					$dataJobSkills["job_id"] = $this->mJobs->selectMaxId();
					$this->mJobsSkills->insertJobSkill($dataJobSkills);
				}

				$param["jobs"] = $this->mJobs->selectJobsByCompanyId($loginID, $companyId);
				$param["user_company"] = $this->mCompanies_users->selectByBothId($loginID, $companyId);
				if(count($param["user_company"]) == 0){
					$param["user_company"]["status"] = "-1";
				}else{
					$param["user_company"] = $param["user_company"][0];
				}
				$this->load->view("ajax/ajaxCompanyJobs", $param);
			}
		}
	}

	public function tambahPerusahaan()
	{
		$loginID = $_SESSION["user_id"];
		$param["COMPANY_NAME"] = $this->input->get_post('edNama');
		$param["COMPANY_DESCRIPTION"] = $this->input->get_post('edDeskripsi');
		$param["COMPANY_SIZE"] = $this->input->get_post('edUkuran');
		$param["COMPANY_TYPE"] = $this->input->get_post('edTipe');
		$param["WEBSITE_URL"] = $this->input->get_post('edWebsiteURL');
		$param["YEAR_FOUNDED"] = $this->input->get_post('edTahunBerdiri');
		$param["STATUS"] = "1";
		if($_FILES["edLogo"]["tmp_name"] != null)
		{
			if($this->ambilGambar("edLogo", "logo") != ""){
				$param["LOGO_URL"] = $this->ambilGambar("edLogo", "logo", true);
			}
		}
		if($_FILES["edCover"]["tmp_name"] != null)
		{
			if($this->ambilGambar("edCover", "cover") != ""){
				$param["COVER_URL"] = $this->ambilGambar("edCover", "cover", false);
			}
		}
		$return = array();
		$return["data"] = $this->mCompanies->getCompanyByName(strtolower($param["COMPANY_NAME"]));
		if(count($return["data"]) > 0){
			$companyId = $return["data"][0]["company_id"];
			$pemilik = $this->mCompanies_users->selectByCompanyId($companyId);
			if(count($pemilik) > 0){
				$return["status"] = "adaPemilik";
				$return["data"] = $pemilik[0];
				if($pemilik[0]["user_id"] == $loginID){
					$return["status"] = "milikSendiri";
				}
			}else{
				$return["status"] = "tidakPunyaPemilik";
				$this->mCompanies->updateCompanies($companyId, $param);
			}
		}else{
			$return["status"] = "tidakTerdaftar";
			$this->mCompanies->insertCompanies($param);
		}

		if($return["status"] == "tidakTerdaftar" || $return["status"] == "tidakPunyaPemilik"){
			$return["data"] = $this->mCompanies->getCompanyByName(strtolower($param["COMPANY_NAME"]))[0];
			$companyId = $return["data"]["company_id"];
			$dataCompaniesUsers["user_id"] = $loginID;
			$dataCompaniesUsers["company_id"] = $companyId;
			$dataCompaniesUsers["status"] = "1";
			$this->mCompanies_users->insert($dataCompaniesUsers);	
		}
		$paramAjax["user_company"] = $this->mCompanies_users->selectByUserId($loginID);
		//var_dump($return[0][0]["company_id"]);
		echo json_encode(array($return, $this->load->view('ajax/company/list_company', $paramAjax, true)));
		// var_dump($param);
	}

	public function dataPerusahaan(){
		$companyId = $this->input->get_post("companyId");
		$company = $this->mCompanies->getCompanyById($companyId)[0];
		echo json_encode($company);
	}

	public function dataKota(){
		$provinceName = $this->input->get_post("provinceName");
		$cities = $this->mCity->selectCities($provinceName);
		echo json_encode($cities);
	}

	public function dataLokasi(){
		$companyLocationId = $this->input->get_post("companyLocationId");
		$location = $this->mCompany_locations->selectCompanyLocation($companyLocationId);
		if($location){
			$location = $location[0];
			$cities = $this->mCity->selectCities($location->state);
			$return["location"] = $location;
			$return["cities"] = $cities;
			echo json_encode($return);
		}
	}

	public function dataPekerjaan(){
		$jobId = $this->input->get_post('jobId');
		$job = $this->mJobs->selectByIdJobs($jobId);
		$job_skill = $this->mJobsSkills->selectJobSkillById($jobId);
		if(count($job) > 0){
			echo json_encode(array($job[0],$job_skill));
		}
	}

	public function tambahLokasi(){
		if($this->isRequestMethodPost()){
			$param["ACCOUNT_ID"] = $this->input->get_post('edCompanyId');
			if($this->companyAdminStatus($param["ACCOUNT_ID"]) == "admin" || $this->companyAdminStatus($param["ACCOUNT_ID"]) == "super_admin"){
				$maxId = $this->mCompany_locations->selectMaxId();
				if(count($maxId) == 0){
					$maxId = 0;
				}else{
					$maxId = $maxId[0]["company_location_id"];
				}

				$param["COMPANY_LOCATION_ID"] = $maxId + 1;
				$param["COMPANY_ADDRESS"] = $this->input->get_post('edAlamat');
				$param["SUITE_APT"] = $this->input->get_post('edApartemen');
				$param["CITY"] = $this->input->get_post('edKota');
				$param["STATE"] = $this->input->get_post('edProvinsi');
				$param["ZIP_CODE2"] = $this->input->get_post('edKodePos');
				$param["BUILDING_NAME"] = $this->input->get_post('edNamaBangunan');

				if(!($this->mCompany_locations->selectCompanyLocations($param["ACCOUNT_ID"]))){
					$param["IS_MAIN_OFFICE"] = "1";
				}elseif($this->input->get_post('edKantorPusat') == 'on'){
					$param["IS_MAIN_OFFICE"] = "1";
					$updateData["IS_MAIN_OFFICE"] = "0";
					$this->mCompany_locations->removeMainOffice($param["ACCOUNT_ID"], $updateData);
				}else{
					$param["IS_MAIN_OFFICE"] = "0";
				}
				$param["STATUS3"] = "1";
				$this->mCompany_locations->insert($param);
				$ajaxData["company_locations"] = $this->mCompany_locations->selectCompanyLocations($param["ACCOUNT_ID"]);
				$mainOffice = $ajaxData["company_locations"][0];
				echo json_encode(array($this->load->view('ajax/ajaxLokasiPerusahaan', $ajaxData, true), $mainOffice));
			}
		}
	}

	public function editPekerjaan(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post("edCompanyId");
			$dataJob["company_id"] = $companyId;
			if($this->companyAdminStatus($companyId) == "admin" || $this->companyAdminStatus($param["ACCOUNT_ID"]) == "super_admin"){
				$jobId = $this->input->get_post("edLowonganId");
				$loginID = $_SESSION["user_id"];
				$dataJob["job_description"] = $this->input->get_post('edDescription');
				$dataJob["seniority_level"] = $this->input->get_post('edSeniorityLevel');
				$dataJob["industry"] = $this->input->get_post('edIndustry');
				$dataJob["employment_type"] = $this->input->get_post('edEmploymentType');
				$dataJob["job_functions"] = $this->input->get_post('edJobFunction');
				$dataJob["min_gaji"] = $this->input->get_post('edMinSalary');
				$dataJob["max_gaji"] = $this->input->get_post('edMaxSalary');
				$dataJob["created_at"] = $this->input->get_post('edCreated');
				$dataJob["expired_at"] = $this->input->get_post('edExpired');
				$dataJob["status"] = 1;
				$this->mJobs->updateJobs($jobId, $companyId, $dataJob);

				$this->mJobsSkills->deleteJobSkill($jobId);
				$skills = $this->input->get_post('edSkill');
				for($i = 0; $i < count($skills);$i++){
					$dataJobSkills["skill_id"] = $this->mSkills->getIdByName(strtolower($skills[$i]));
					if(empty($dataJobSkills["skill_id"])){
						$dataSkill = array();
						$dataSkill["skill_name"] = $skills[$i];
						$this->mSkills->insertSkill($dataSkill);
						unset($dataSkill);
						$dataJobSkills["skill_id"] = $this->mSkills->getIdByName(strtolower($skills[$i]));
					}
					$dataJobSkills["job_id"] = $jobId;
					$this->mJobsSkills->insertJobSkill($dataJobSkills);
				}

				$param["jobs"] = $this->mJobs->selectJobsByCompanyId($loginID, $companyId);
				$param["user_company"] = $this->mCompanies_users->selectByBothId($loginID, $companyId);
				if(count($param["user_company"]) == 0){
					$param["user_company"]["status"] = "-1";
				}else{
					$param["user_company"] = $param["user_company"][0];
				}
				$this->load->view("ajax/ajaxCompanyJobs", $param);
			}
		}	
	}

	public function editLokasi(){
		if($this->isRequestMethodPost()){
			$param["ACCOUNT_ID"] = $this->input->get_post('edCompanyId');
			if($this->companyAdminStatus($param["ACCOUNT_ID"]) == "admin" || $this->companyAdminStatus($param["ACCOUNT_ID"]) == "super_admin"){
				$locationId = $this->input->get_post('edLocationId');
				$param["COMPANY_ADDRESS"] = $this->input->get_post('edAlamat');
				$param["SUITE_APT"] = $this->input->get_post('edApartemen');
				$param["CITY"] = $this->input->get_post('edKota');
				$param["STATE"] = $this->input->get_post('edProvinsi');
				$param["ZIP_CODE2"] = $this->input->get_post('edKodePos');
				$param["BUILDING_NAME"] = $this->input->get_post('edNamaBangunan');
				
				$mainOfficeId = $this->mCompany_locations->mainOfficeId($param["ACCOUNT_ID"])[0]["company_location_id"];
				if($mainOfficeId != $locationId){
					if($this->input->get_post('edKantorPusat') == 'on'){
						$param["IS_MAIN_OFFICE"] = "1";
						$updateData["IS_MAIN_OFFICE"] = "0";
						$this->mCompany_locations->removeMainOffice($param["ACCOUNT_ID"], $updateData);
					}else{	
						$param["IS_MAIN_OFFICE"] = "0";
					}
				}
				
				$param["STATUS3"] = "1";
				$this->mCompany_locations->update($locationId, $param);
				$ajaxData["company_locations"] = $this->mCompany_locations->selectCompanyLocations($param["ACCOUNT_ID"]);
				$mainOffice = $ajaxData["company_locations"][0];
				echo json_encode(array($this->load->view('ajax/ajaxLokasiPerusahaan', $ajaxData, true), $mainOffice));
			}
		}
	}

	public function hapusLokasi(){
		if($this->isRequestMethodPost()){
			$param["ACCOUNT_ID"] = $this->input->get_post('edCompanyId');
			if($this->companyAdminStatus($param["ACCOUNT_ID"]) == "admin" || $this->companyAdminStatus($param["ACCOUNT_ID"]) == "super_admin"){
				$locationId = $this->input->get_post('edLocationId');
				$mainOfficeId = $this->mCompany_locations->mainOfficeId($param["ACCOUNT_ID"])[0]["company_location_id"];
				if($mainOfficeId != $locationId){
					$this->mCompany_locations->deleteLocation($locationId);
					$ajaxData["company_locations"] = $this->mCompany_locations->selectCompanyLocations($param["ACCOUNT_ID"]);
					$this->load->view('ajax/ajaxLokasiPerusahaan', $ajaxData);
				}
			}
		}
	}

	public function editPerusahaan(){
		$companyId = $this->input->get_post('edId');
		$loginID = $_SESSION["user_id"];
		$param["COMPANY_NAME"] = $this->input->get_post('edNama');
		$param["COMPANY_DESCRIPTION"] = $this->input->get_post('edDeskripsi');
		$param["COMPANY_SIZE"] = $this->input->get_post('edUkuran');
		$param["COMPANY_TYPE"] = $this->input->get_post('edTipe');
		$param["WEBSITE_URL"] = $this->input->get_post('edWebsiteURL');
		$param["YEAR_FOUNDED"] = $this->input->get_post('edTahunBerdiri');
		$param["STATUS"] = "1";
		if($_FILES["edLogo"]["tmp_name"] != null)
		{
			if($this->ambilGambar("edLogo", "logo") != ""){
				$param["LOGO_URL"] = $this->ambilGambar("edLogo", "logo");
			}
		}
		if($_FILES["edCover"]["tmp_name"] != null)
		{
			if($this->ambilGambar("edCover", "cover") != ""){
				$param["COVER_URL"] = $this->ambilGambar("edCover", "cover");
			}
		}
		$this->mCompanies->updateCompanies($companyId, $param);
		//
		$paramJob["jobs"] = $this->mJobs->selectJobsByCompanyId($loginID, $companyId);
		$paramJob["user_company"] = $this->mCompanies_users->selectByBothId($loginID, $companyId);
		if(count($paramJob["user_company"]) == 0){
			$paramJob["user_company"]["status"] = "-1";
		}else{
			$paramJob["user_company"] = $paramJob["user_company"][0];
		}
		if(count($paramJob["jobs"]) != 0){
			$paramJob["company"] = $paramJob["company"][0];
			$paramJob["company_locations"] = $this->mCompany_locations->selectCompanyLocations($companyId);
			echo json_encode(array($param, $this->load->view("ajax/ajaxCompanyJobs", $paramJob, true)));
		}else{
			//
			// echo json_encode($param);
		}
	}

	public function hapusPerusahaan(){
		if($this->isRequestMethodPost()){
			$companyId = $this->input->get_post('edCompanyId');
			if($this->companyAdminStatus($companyId) == "super_admin"){
				$this->mAccounts->delete($companyId);
				$this->mCompanies_users->deleteByCompany($companyId);
				$param["user_company"] = $this->mCompanies_users->selectByUserId($_SESSION["user_id"]);
				$this->load->view('ajax/company/list_company', $param);
			}
		}
	}

	//fungi untuk me-follow/unfollow user
	public function akunFollow(){
		if($this->isRequestMethodPost()){
			$dataFollow["user_following_id"] = $_SESSION["user_id"];
			$dataFollow["account_followed_id"] = $this->input->get_post('companyId');
			$dataFollow["status"] = "1";
			$follow_status = $this->input->get_post('status');
			$return = array();
			if($follow_status == 0){
				$this->mAccount_Followers->insertFollow($dataFollow);
				$return = array("UNFOLLOW", 1, $this->mAccount_Followers->followCount($dataFollow["account_followed_id"]));
			}else{
				$this->mAccount_Followers->deleteFollow($dataFollow["user_following_id"],$dataFollow["account_followed_id"]);
				$return = array("FOLLOW", 0, $this->mAccount_Followers->followCount($dataFollow["account_followed_id"]));
			}
			echo json_encode($return);
		}
	}

	function companyAdminStatus($companyId){
		if(isset($_SESSION["user_id"])){
			$userId = $_SESSION["user_id"];
			$temp = $this->mCompanies_users->selectByBothId($userId, $companyId);
			if($temp){
				if($temp[0]["status"] == 0){
					return "admin";
				}else{
					return "super_admin";
				}
			}else{
				return "user";
			}
		}else{
			return "no_user";
		}
	}

	function isRequestMethodPost(){
		if($_SERVER["REQUEST_METHOD"] == 'POST'){
			return true;
		}else{
			$this->load->view('dashboard');
		}
	}
	
	function ambilGambar($element_name, $destination_img_name){
		$check = getimagesize($_FILES[$element_name]["tmp_name"]);
			
		//check if an image
		if($check !== false) {
			
			//convert image to base64
			$img_type = explode("/",$check["mime"]);
			$image = explode('"',$check[3]);
			$dataImage = base64_encode(file_get_contents( $_FILES[$element_name]["tmp_name"] ));
			$imageData = 'data:image/' . $img_type[1] . ';base64,' . $dataImage;
			
			// $source_img = $_FILES[$element_name]["name"];
			$source_img = $imageData;
			$destination_img = $destination_img_name.$img_type[1];
			$d = $this->compress($source_img, $destination_img, 40);
			$imageData = base64_encode(file_get_contents($d));
			// $imageData = base64_encode(file_get_contents($source_img));
			
			//delete image
			unlink($destination_img);
			$imageData = 'data:image/'.$img_type[1].';base64,' . $imageData;
			
			//
			return $imageData;
		} else {
			//echo "File is not an image.";
			return "";
		}
	}

	function compress($source, $destination, $quality) {

		$info = getimagesize($source);

		if ($info['mime'] == 'image/jpeg'){
			$image = imagecreatefromjpeg($source);
			imagejpeg($image, $destination, $quality);
		}elseif ($info['mime'] == 'image/gif'){ 
			$image = imagecreatefromgif($source);
			imagegif($image, $destination, $quality);
		}elseif ($info['mime'] == 'image/png'){
			$image = imagecreatefrompng($source);
			imageAlphaBlending($image, true);
			imageSaveAlpha($image, true);
			$quality = $quality / 10;
			imagepng($image, $destination, $quality);
		}
		return $destination;
	}
	
	
	//load notif msg
	function loadNotifMsg(){
		$countMsg = $this->mConversation->selectCountMsg($_SESSION["user_id"]);
		$ctr = 0;
		foreach($countMsg as $item){
			if($item->last_seen < $item->timestamp){
				$ctr++;
			}
		}
		return $ctr;
	}

	public function getSkill()
	{
		$skillName = $this->input->get_post('skillName');
		$param = $this->mSkills->selectSkill($skillName);
		echo json_encode($param);
	}

}
