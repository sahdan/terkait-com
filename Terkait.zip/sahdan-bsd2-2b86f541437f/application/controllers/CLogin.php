<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CLogin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('mAccounts');
		$this->load->model('mUsers');
		$this->load->model('mVConnectionsCount');
		$this->load->model('mAdmin');
		$this->load->library('session');
		$this->load->model('mUser_Connections');
	}
	
	public function index()
	{
		
		$this->load->view('login');
	}
	
	//login admin
	public function loginAdmin()
	{
		
		$this->load->view('loginAdmin');
	}
	
	public function admin()
	{
		
		$this->load->view('admin');
	}
	
	public function checkLoginAdmin()
	{
		$data["email"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edEmail')));
		$data["password"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edPassword')));
		if(!isset($_SESSION["user_id"])){
			foreach($this->mAdmin->checkLogin($data["email"], md5($data["password"])) as $data){
				$check = true;
			}
			if($check){
				$_SESSION["user_id"] = "admin";
				Redirect(base_url('CAdmin'), false);
			}else{
				Redirect(base_url('CLogin/loginAdmin'), false);
			}
		}
		else{
			if($_SESSION["user_id"] = "admin"){
				Redirect(base_url('CAdmin'), false);
			}else{
				$this->load->view('loginAdmin');
			}
		}
		
		
		
	}
	
	public function loginFail()
	{
        $this->load->view('login');
	}

	public function registered()
	{
        $this->load->view('login');
	}
	
	public function login()
	{
		if(!isset($_SESSION["user_id"])){
			// Pakai str_replace untuk mencegah SQL injection
			$data["email"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edEmail')));
			$data["password"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edPassword')));
			$check = false;
			foreach($this->mUsers->checkLogin($data["email"], md5($data["password"])) as $data){
				$_SESSION["user_id"] = $data->USER_ID;
				$_SESSION["user_first_name"] = $data->USER_FIRST_NAME;
				$_SESSION["user_last_name"] = $data->USER_LAST_NAME;
				$_SESSION["user_email"] = $data->USER_EMAIL;
				$_SESSION["user_headline"] = $data->HEADLINE;
				$check = true;
			}
			if($check){
				// foreach($this->mVConnectionsCount->selectJumKoneksi($_SESSION["user_id"]) as $data){
					// $_SESSION["user_jum_koneksi"] = $data->jum;
				// }
				$_SESSION["user_jum_koneksi"] = $this->mUser_Connections->countConnection($_SESSION["user_id"]);
				
				$this->mAdmin->updateCtrWeb();
				Redirect(base_url('CHome'), false);
				// $this->load->view('home', $data);
			}else{
				Redirect(base_url('CLogin/loginFail'), false);
			}
		}
		else{
			Redirect(base_url('CHome'), false);
		}
		
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('CLogin/index'), false);
	}
	
	public function register()
	{
		foreach($this->mAccounts->selectMaxId() as $data){
			$dataInsert["user_id"] = $data->jumlah;
		}
		
		// Pakai str_replace untuk mencegah SQL injection
		$dataInsert["user_first_name"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edFirstName')));
		$dataInsert["user_last_name"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edLastName')));
		$dataInsert["user_email"] = str_replace("'","", str_replace('"',"", $this->input->get_post('edEmail')));
		$dataInsert["password"] = md5(str_replace("'","", str_replace('"',"", $this->input->get_post('edPassword'))));
		$confPassword =  md5(str_replace("'","", str_replace('"',"", $this->input->get_post('edConfPassword'))));
		if($dataInsert["password"] == $confPassword){
			$this->mUsers->insertUsers($dataInsert);
		}
		// var_dump($dataInsert);
        Redirect(base_url('CLogin/registered'), false);
	}
	
	
}
